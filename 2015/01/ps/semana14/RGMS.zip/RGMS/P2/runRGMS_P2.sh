java -jar RGMS_P2.jar
