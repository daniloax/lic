package base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

public class ListaPublicacoesBibtex implements Lista{
	String titulo;
	String ano;
	String autores;
	@Override
	public void geraLista(Vector vetorPub) {
		String lista = "";
		for(int i = 0; i< vetorPub.size(); i++){
			ArtigoEmConferencia artigo = (ArtigoEmConferencia)vetorPub.elementAt(i);
			lista = lista + this.itemLista(artigo) + "\n\n";
			
		}
		 File arquivo;  
		 arquivo = new File("lista.bib");  
		 FileOutputStream fos;
		 try {
				fos = new FileOutputStream(arquivo);
				 fos.write(lista.getBytes());  
				 fos.close(); 
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	}
	/*@article{mrx05, 
		auTHor = "Mr. X", 
		Title = {Something Great}, 
		publisher = "nob" # "ody"}, 
		YEAR = 2005, 
		}*/
	
	public String itemLista(ArtigoEmConferencia artigo){
		String retorno = "@article{" + this.gerarTag(artigo) +
		",\nauthor = \"" + artigo.autoresNaoMembros +
		"\",\nTitle = {"+ artigo.getTitulo()+ "},\nYEAR = " + artigo.getAno()
		+",\n}";

		return retorno;
	}
	
	public String gerarTag(ArtigoEmConferencia artigo){
		String tag = "";
		if(artigo.getAutoresNaoMembros()!= null){
		for(int i =0; i <3; i++){
			tag = tag + artigo.getAutoresNaoMembros().charAt(i);
		}
		}
		tag = tag + artigo.getAno();
		return tag;
	}
}
