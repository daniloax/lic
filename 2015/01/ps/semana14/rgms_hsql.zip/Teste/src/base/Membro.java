package base;


import java.util.Vector;

import javax.swing.ImageIcon;

public class Membro {

	private String nome; 
	private String tipo;
	private String dpto_univ;
	private String email;
	private String telefone;
	private String website;
	private String cidade;
	private String pais;
	private String status;
	private String login;
	private String senha;
	private String universidade;
	private String urlFoto;
	private ImageIcon foto;
	private int id_membro;
	
	//LINHADEPESQUISA
	private Vector<String> linhasDePesquisa;

	public Vector<String> getLinhasDePesquisa() {
		return linhasDePesquisa;
	}

	public void setLinhasDePesquisa(Vector<String> linhasDePesquisa) {
		this.linhasDePesquisa = linhasDePesquisa;
	}
	//LINHADEPESQUISA
	
	public int getId_membro() {
		return id_membro;
	}

	public void setId_membro(int id_membro) {
		this.id_membro = id_membro;
	}

	public Membro(String nome, String tipo, String dpto_univ, String email,
			String telefone, String website, String cidade, String pais,
			String status, String login, String senha /* xxxx foto */) {

		this.setNome(nome);
		this.setTipo(tipo);
		this.setDpto_univ(dpto_univ);
		this.setEmail(email);
		this.setTelefone(telefone);
		this.setWebsite(website);
		this.setCidade(cidade);
		this.setPais(pais);
		this.setStatus(status);
		this.setSenha(senha);
		this.setLogin(login);
		/* this.setFoto(foto); */

	} // fim do construtor

	//construtor vazio
	public Membro(){}
	


	public String getUrlFoto() {
		return urlFoto;
	}

	public void setUrlFoto(String urlFoto) {
		this.urlFoto = urlFoto;
	}

	public ImageIcon getFoto() {
		return foto;
	}

	public void setFoto(ImageIcon foto) {
		this.foto = foto;
	}

	public String getUniversidade() {
		return universidade;
	}

	public void setUniversidade(String universidade) {
		this.universidade = universidade;
	}
	public String getDpto_univ() {
		return dpto_univ;
	}

	public void setDpto_univ(String dpto_univ) {
		this.dpto_univ = dpto_univ;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getTelefone() {
		return telefone;
	}


	
	public String getNome() {

		return this.nome;

	}

	public String getTipo() {

		return this.tipo;

	}


	public String getEmail() {

		return this.email;

	}

	public String getWebsite() {

		return this.website;

	}

	public String getCidade() {

		return this.cidade;

	}

	public String getPais() {

		return this.pais;

	}

	public String getStatus() {

		return this.status;

	}

	/*
	 * public String getFoto () {
	 * 
	 * return this.foto;
	 * 
	 * }
	 */

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setEmail(String email) {

		this.email = email;

	}

	public void setWebsite(String website) {

		this.website = website;

	}

	public void setCidade(String cidade) {

		this.cidade = cidade;

	}

	public void setPais(String pais) {

		this.pais = pais;

	}

	public void setStatus(String status) {

		this.status = status;

	}

	/*
	 * public void setFoto (xxxx foto) {
	 * 
	 * this.foto = foto;
	 * 
	 * }
	 */

	public void setTelefone(String telefone) {

		this.telefone = telefone;

	}

}// fim da classe