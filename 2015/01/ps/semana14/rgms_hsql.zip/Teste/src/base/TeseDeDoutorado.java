package base;

import java.util.Vector;

public class TeseDeDoutorado extends Publicacao {

	String instituicao;
	String mes;

	public TeseDeDoutorado() {

	}

	public String getAutoresNaoMembros() {

		return this.autoresNaoMembros;

	}

	public void setAutoresNaoMembros(String autores) {
		this.autoresNaoMembros = autores;
	}

	public Vector getLoginAutoresMembros() {

		return this.nomeAutoresMembros;

	}

	public void setLoginAutoresMembros(Vector loginAutores) {
		this.nomeAutoresMembros = loginAutores;
	}

	public String getAutoresMembros() {

		return this.autoresMembros;
	}

	public void setAutoresMembros(String autoresMembros) {
		this.autoresMembros = autoresMembros;
	}

	public String getInstituicao() {
		return this.instituicao;
	}

	public String getMes() {
		return this.mes;
	}

	public String getTitulo() {
		return this.titulo;
	}

	public String getAno() {
		return this.ano;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public void setInstituicao(String instituicao) {
		this.instituicao = instituicao;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

}// fim da classe
