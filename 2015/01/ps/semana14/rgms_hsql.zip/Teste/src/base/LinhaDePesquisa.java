package base;

import java.util.Vector;

public class LinhaDePesquisa {

	String titulo;
	String descricaoBreve;
	String descricaoDetalhada;
	String financiadores;
	String linksRelacionados;
	Vector<String> nomeMembros;
	Vector<String> publicacoes;
	int id_linha;
	
	public LinhaDePesquisa() {
	}
	
	
	public int getId_linha() {
		return id_linha;
	}


	public void setId_linha(int id_linha) {
		this.id_linha = id_linha;
	}


	public String getTitulo() {
		return this.titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescricaoBreve() {
		return descricaoBreve;
	}

	public void setDescricaoBreve(String descricaoBreve) {
		this.descricaoBreve = descricaoBreve;
	}

	public String getDescricaoDetalhada() {
		return descricaoDetalhada;
	}

	public void setDescricaoDetalhada(String descricaoDetalhada) {
		this.descricaoDetalhada = descricaoDetalhada;
	}

	public String getFinanciadores() {
		return financiadores;
	}

	public void setFinanciadores(String financiadores) {
		this.financiadores = financiadores;
	}

	public String getLinksRelacionados() {
		return linksRelacionados;
	}

	public void setLinksRelacionados(String linksRelacionados) {
		this.linksRelacionados = linksRelacionados;
	}

	public Vector<String> getNomeMembros() {
		return nomeMembros;
	}

	public void setNomeMembros(Vector<String> nomeMembros) {
		this.nomeMembros = nomeMembros;
	}

	public Vector<String> getPublicacoes() {
		return publicacoes;
	}

	public void setPublicacoes(Vector<String> publicacoes) {
		this.publicacoes = publicacoes;
	}

}
