package base;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

public class ListaPublicacoesPDF implements Lista {

	@Override
	public void geraLista(Vector vetorPub) {
		// TODO Auto-generated method stub
		Document document = new Document();
		try{
			 PdfWriter.getInstance(document, new FileOutputStream("lista_publica��es.pdf"));
	           document.open();
	           String relatorio = "";
	           for(int i = 0; i < vetorPub.size(); i++){
	        	   ArtigoEmConferencia artigo = (ArtigoEmConferencia) vetorPub.elementAt(i);
	        	   document.add(new Paragraph(relatorio + this.itemRelatorio(artigo)));
	           }

		}
	       catch(DocumentException de) {
	           System.err.println(de.getMessage());
	       }
	       catch(IOException ioe) {
	           System.err.println(ioe.getMessage());
	       }
	       document.close();


	}
	
	public String itemRelatorio(ArtigoEmConferencia artigo){
		String item = "T�tulo: " + artigo.getTitulo() + ".\nAutores: "+
		artigo.getAutoresNaoMembros() + ".\nAno: " + artigo.getAno() + ".\n\n";
		
		return item;
	}

}
