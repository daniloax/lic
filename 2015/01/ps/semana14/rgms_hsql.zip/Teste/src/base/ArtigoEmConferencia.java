package base;

import java.io.File;
import java.util.Vector;

import javax.swing.ImageIcon;

public class ArtigoEmConferencia extends Publicacao {

	private String conferencia;
	private String paginas;
	private String mes;
	

	public ArtigoEmConferencia() {
	}// fim do construtor

	

	public String getConferencia() {
		return this.conferencia;
	}

	public void setConferencia(String conferencia) {
		this.conferencia = conferencia;
	}

	public String getPaginas() {
		return this.paginas;
	}

	public void setPaginas(String paginas) {
		this.paginas = paginas;
	}

	public String getMes() {
		return this.mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public String getAutoresNaoMembros() {

		return this.autoresNaoMembros;

	}

	public void setAutoresNaoMembros(String autores) {
		this.autoresNaoMembros = autores;
	}

	public Vector getLoginAutoresMembros() {

		return this.nomeAutoresMembros;

	}

	public void setLoginAutoresMembros(Vector loginAutores) {
		this.nomeAutoresMembros = loginAutores;
	}

	public String getAutoresMembros() {

		return this.autoresMembros;
	}

	public void setAutoresMembros(String autoresMembros) {
		this.autoresMembros = autoresMembros;
	}

	public String getTitulo() {
		return this.titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAno() {
		return this.ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	

}// fim da classe
