package base;

import java.util.Vector;

public class ArtigoEmPeriodicoERevista extends Publicacao {

	private String jornal;
	private String volume;
	private String numero;
	private String paginas;

	public ArtigoEmPeriodicoERevista() {

	} // fim do construtor

	public String getAutoresNaoMembros() {

		return this.autoresNaoMembros;

	}

	public void setAutoresNaoMembros(String autores) {
		this.autoresNaoMembros = autores;
	}

	public Vector getLoginAutoresMembros() {

		return this.nomeAutoresMembros;

	}

	public void setLoginAutoresMembros(Vector loginAutores) {
		this.nomeAutoresMembros = loginAutores;
	}

	public String getAutoresMembros() {

		return this.autoresMembros;
	}

	public void setAutoresMembros(String autoresMembros) {
		this.autoresMembros = autoresMembros;
	}

	public String getJornal() {
		return this.jornal;
	}

	public String getVolume() {
		return this.volume;
	}

	public String getNumero() {
		return this.numero;
	}

	public String getPaginas() {
		return this.paginas;

	}

	public String getTitulo() {
		return this.titulo;
	}

	public String getAno() {
		return this.ano;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public void setJornal(String jornal) {
		this.jornal = jornal;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public void setPaginas(String paginas) {
		this.paginas = paginas;
	}

}// fim da classe
