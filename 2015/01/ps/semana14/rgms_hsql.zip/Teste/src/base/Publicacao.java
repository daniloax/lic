package base;

import java.io.File;
import java.util.Vector;

public abstract class Publicacao {

	String autoresNaoMembros;
	String autoresMembros;
	Vector<String> nomeAutoresMembros;
	
	//LINHASDEPESQUISA
	private Vector<String> linhasDePesquisa;
	
	public Vector<String> getLinhasDePesquisa() {
		return linhasDePesquisa;
	}


	public void setLinhasDePesquisa(Vector<String> linhasDePesquisa) {
		this.linhasDePesquisa = linhasDePesquisa;
	}


	//LINHASDEPESQUISA
	public Vector<String> getNomeAutoresMembros() {
		return nomeAutoresMembros;
	}
	private int id_publicacao;
	
	

	public int getId_publicacao() {
		return id_publicacao;
	}


	public void setId_publicacao(int id_publicacao) {
		this.id_publicacao = id_publicacao;
	}


	public void setNomeAutoresMembros(Vector<String> nomeAutoresMembros) {
		this.nomeAutoresMembros = nomeAutoresMembros;
	}

	String titulo;
	String ano;
	private String urlPdf;
	private File pdf;
	private String tipoPublicacao;
	
	public Publicacao() {
	}

	
	public String getTipoPublicacao() {
		return tipoPublicacao;
	}


	public void setTipoPublicacao(String tipoPublicacao) {
		this.tipoPublicacao = tipoPublicacao;
	}


	public String getUrlPdf() {
		return urlPdf;
	}

	public void setUrlPdf(String urlPdf) {
		this.urlPdf = urlPdf;
	}

	public File getPdf() {
		return pdf;
	}

	public void setPdf(File pdf) {
		this.pdf = pdf;
	}

	abstract String getAutoresNaoMembros();

	abstract void setAutoresNaoMembros(String autoresNaoMembros);

	abstract String getAutoresMembros();

	abstract void setAutoresMembros(String autoresMembros);

	abstract Vector getLoginAutoresMembros();

	abstract void setLoginAutoresMembros(Vector loginAutoresMembros);

	abstract String getTitulo();

	abstract String getAno();

	abstract void setTitulo(String titulo);

	abstract void setAno(String ano);

}// fim da classe
