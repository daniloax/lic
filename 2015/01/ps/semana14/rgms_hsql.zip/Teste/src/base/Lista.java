package base;

import java.util.Vector;

public interface Lista {

	
	public void geraLista(Vector vetorEntidade);

}
