package repositorio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TesteHsql {
	
	 
public static void main(String[] args) {
	try {
		Connection c = DriverManager.getConnection("jdbc:hsqldb:file:C://Users//Paola//testedb", "SA", "");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
