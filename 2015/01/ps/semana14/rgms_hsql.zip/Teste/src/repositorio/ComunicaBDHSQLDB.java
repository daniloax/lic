package repositorio;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.*;
import java.util.Vector;

import org.hsqldb.jdbc.JDBCBlob;

public class ComunicaBDHSQLDB {

	private String usuario = "sa";
	private String senha = "";
	private String url = "jdbc:hsqldb:file:C://Users//Paola//testedb";
	private String driver = "org.hsqldb.jdbcDriver";

	private Connection conexao = null;
	private Statement stat = null;
	private ResultSet result = null;

	// este metodo � usado para fazer SELECT
	public ResultSet pegaDados(String query) throws SQLException,
			ClassNotFoundException {
		conexao = null;
		stat = null;
		result = null;
		try {
			Class.forName(driver);
		} catch (Exception x) {
			System.out.println("Unable to load the driver class!");
		}
		conexao = DriverManager.getConnection(url, usuario, senha);
		stat = conexao.createStatement();
		result = stat.executeQuery(query);
		return result;
	}

	// este metodo � usado para fazer INSERT, DELETE, UPDATE, CREATE, DROP
	public void modificaTabela(String query) throws SQLException,
			ClassNotFoundException {
		String sql = query;
		this.conexao = null;
		this.stat = null;
		try {
			Class.forName(driver);
		} catch (Exception x) {
			System.out.println("Unable to load the driver class!");
		}

		conexao = DriverManager.getConnection(url, usuario, senha);
		stat = conexao.createStatement();
		stat.executeUpdate(sql);
		stat.execute("SHUTDOWN");
		conexao.commit();
		conexao.close();

	}

	// metodo para inserir em tabela com blob
	public void modificaTabelaComBlob(String query, String urlFile)
			throws IOException, SQLException {

		// carrega array de bytes
		File arq = new File(urlFile);
		byte[] imageDataByteArray = new byte[(int) arq.length()];
		InputStream is = new FileInputStream(arq);
		is.read(imageDataByteArray);
		is.close();

		// cria conex�o
		conexao = null;
		stat = null;
		result = null;
		try {
			Class.forName(driver);
		} catch (Exception x) {
			System.out.println("Unable to load the driver class!");
		}

		conexao = DriverManager.getConnection(url, usuario, senha);
		
		//grava no banco
		JDBCBlob blob = new JDBCBlob(imageDataByteArray);
		PreparedStatement pstmt = conexao.prepareStatement(query);
		pstmt.setBlob(1, blob);
		pstmt.executeUpdate();
		
		//fecha conex�o
		conexao.commit();
		Statement stmt = conexao.createStatement();
		stmt.execute("SHUTDOWN");
		conexao.commit();
		conexao.close();
		

	}

	// fecha conex�o
	public void fecharConexao() throws SQLException {
		conexao.commit();
		stat.execute("SHUTDOWN");
		stat.close();
		result.close();
		conexao.close();

	}

	public void insereBlob() throws IOException, SQLException {

		// prepara array de bytes
		File arq = new File("C://teste.jpg");
		byte[] imageDataByteArray = new byte[(int) arq.length()];
		InputStream is = new FileInputStream(arq);
		is.read(imageDataByteArray);
		is.close();

		// cria conex�o
		conexao = null;
		stat = null;
		result = null;
		try {
			Class.forName(driver);
		} catch (Exception x) {
			System.out.println("Unable to load the driver class!");
		}

		conexao = DriverManager.getConnection(url, usuario, senha);

		JDBCBlob blob = new JDBCBlob(imageDataByteArray);

		// grava no banco
		PreparedStatement pstmt = conexao
				.prepareStatement("INSERT INTO dataobject VALUES (3, ?);");
		pstmt.setBlob(1, blob);
		pstmt.executeUpdate();
		Statement stmt = conexao.createStatement();
		stmt.execute("SHUTDOWN");
		conexao.commit();
		conexao.close();

	}

	public void recuperaBlob() throws SQLException, IOException {

		conexao = null;
		stat = null;
		result = null;
		try {
			Class.forName(driver);
		} catch (Exception x) {
			System.out.println("Unable to load the driver class!");
		}
		conexao = DriverManager.getConnection(url, usuario, senha);
		stat = conexao.createStatement();
		result = stat.executeQuery("SELECT * from dataobject where id = 1");
		result.next();

		int bytesRead = 0;
		File byteFileDb = new File("foto.jpg");
		Blob blob = result.getBlob("data");
		byte[] bbuf = new byte[1024];
		InputStream bin = blob.getBinaryStream();
		OutputStream bout = new FileOutputStream(byteFileDb);
		while ((bytesRead = bin.read(bbuf)) != -1) {
			bout.write(bbuf, 0, bytesRead);
		}
		bin.close();
		bout.close();
	}

	public static void main(String[] args) {
		String query = "insert into TB_MEMBRO (id_membro, login, senha, email, nome) values "
				+ "(DEFAULT, 'testehehe', 'teste123', 'teste@aol.com', 'teste silva3')";

		// String query =
		// "insert into dataobject (object_id, object_value) values('dois', 'dois')";

		ComunicaBDHSQLDB c = new ComunicaBDHSQLDB();
		try {
			// c.modificaTabela(query);
			c.insereBlob();
			c.recuperaBlob();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // ResultSet rs;
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
