package repositorio;

import base.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import oracle.sql.BLOB;

public class RepositorioLinhaDePesquisa {

	private ComunicaBDHSQLDB banco;

	public RepositorioLinhaDePesquisa() {

		this.banco = new ComunicaBDHSQLDB();
	}
	
	public LinhaDePesquisa buscaLinhaDePesquisa(String tituloLinha) throws SQLException, ClassNotFoundException{
		LinhaDePesquisa retorno = new LinhaDePesquisa();
		
		//seta as informacoes da linha de pesquisa
		String query1 = "select p.* from tb_linhadepesquisa p where p.titulo = '" + tituloLinha + "'";
		ResultSet rs1 = this.banco.pegaDados(query1);
		rs1.next();
		retorno.setId_linha(rs1.getInt("id_linha"));
		retorno.setDescricaoBreve(rs1.getString("descricao_breve"));
		retorno.setDescricaoDetalhada(rs1.getString("descricao_detalhada"));
		retorno.setFinanciadores(rs1.getString("financiadores"));
		retorno.setLinksRelacionados(rs1.getString("links"));
		retorno.setTitulo(rs1.getString("titulo"));
		
		//seta os membros da linha de pesquisa
		Vector<String> membro = new Vector();
		String query2 = "select p.* from tb_linha_membro p where p.nome_linha = '" + tituloLinha + "'";
		ResultSet rs2 = this.banco.pegaDados(query2);
		while(rs2.next()){
			String nomeMembro = rs2.getString("nome_membro");
			membro.add(nomeMembro);
		}
		retorno.setNomeMembros(membro);
		
		
		//seta as publica��es da linha de pesquisa
		Vector<String> publicacoes = new Vector();
		String query3 = "select p.* from tb_linha_publicacao p where p.nome_linha = '" + tituloLinha + "'";
		ResultSet rs3 = this.banco.pegaDados(query3);
		while(rs3.next()){
			String tituloPub = rs3.getString("titulo_publicacao");
			publicacoes.add(tituloPub);
		}
		retorno.setPublicacoes(publicacoes);
		
		this.banco.fecharConexao();
		return retorno;
	}
	
	public void inserirLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, IOException {

		// insere na tb_linhadepesquisa
		String query = "insert into tb_linhadepesquisa values (DEFAULT, '" + x.getDescricaoBreve() +
		"' , '" + x.getDescricaoDetalhada() + "' , '" + x.getFinanciadores() + "' , '" + x.getLinksRelacionados() + 
		"' , '" + x.getTitulo() + "')";
		this.banco.modificaTabela(query);

		
		//this.banco.fecharConexao();
	}
	
	public int buscaIdPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		String query = "select p.id_publicacao from tb_publicacoes p where p.titulo = '" + tituloPub + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_publicacao");
		
		return retorno;
		
	}
	
	public int buscaIdLinha(String nomeLinha) throws SQLException, ClassNotFoundException{
		String query = "select p.id_linha from tb_linhadepesquisa p where p.titulo = '" + nomeLinha + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_linha");
		
		return retorno;
		
	}
	
	public int buscaIdMembro(String nomeMembro) throws SQLException, ClassNotFoundException{
		String query = "select p.id_membro from tb_membro p where p.nome = '" + nomeMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_membro");
		
		return retorno;
		
	}
	
	// esse metodo vai retornar o titulo de todas as linhas de pesquisa
	public Vector retornaTodasLinhasDePesquisa() throws SQLException,
			ClassNotFoundException {

		Vector<String> retorno = new Vector();
		 String query = "select p.titulo from tb_linhadepesquisa p"; 
		ResultSet rs = this.banco.pegaDados(query);

		while (rs.next()) {
			String linha = rs.getString("titulo");
			retorno.add(linha);
		}
		
		//this.banco.fecharConexao();
		
		return retorno;
		
		
	}

	public Vector<LinhaDePesquisa> procurarLinhaDePesquisaLike(String nomeLinha)
	throws SQLException, ClassNotFoundException {
	Vector<LinhaDePesquisa> retorno = new Vector();
	
	String query = "select p.titulo from tb_linhadepesquisa p where p.titulo like '%" + nomeLinha + "%'";
	ResultSet result = this.banco.pegaDados(query);
	while(result.next()){
		
		LinhaDePesquisa x = new LinhaDePesquisa();
		x.setTitulo(result.getString("titulo"));
		retorno.add(x);
	}
	
	this.banco.fecharConexao();
	return retorno;
}

	public void removerLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException {
	}

	public void editarLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException {
		
		//da update na tb_linhadepesquisa
		String query1 = "update tb_linhadepesquisa p set p.descricao_breve = '" + x.getDescricaoBreve() + 
		"' , p.descricao_detalhada = '" + x.getDescricaoDetalhada() + "' , p.financiadores = '" +
		x.getFinanciadores() + "' , p.links = '" + x.getLinksRelacionados() + "' , p.titulo = '" +
		x.getTitulo() + "' where p.ID_LINHA = " + x.getId_linha();
		this.banco.modificaTabela(query1);
		
		
		
		//this.banco.fecharConexao();
	}

	public boolean autenticaLinhaDePesquisa(String tituloLinhaDePesquisa)
			throws SQLException, ClassNotFoundException {
		boolean achou = false;

		
		 String query =
		 "select p.titulo from tb_publicacoes p where p.titulo = '" +
		 tituloLinhaDePesquisa + "'";
		 
		ResultSet result = this.banco.pegaDados(query);

		// verifica se resultset eh vazio
		int x = 0;
		while (result.next()) {
			x = x + 1;
		}
		if (x != 0) {

			achou = true;
		}
		this.banco.fecharConexao();
		return achou;
	}
	public Vector<String> retornaMembrosDeUmaLinha(String nomeLinha) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();
		String query = "select p.nome_membro from tb_linha_membro p where p.nome_linha = '" + nomeLinha + "'";
		ResultSet rs = this.banco.pegaDados(query);
		while(rs.next()){
			String nome = rs.getString("nome_membro");
			retorno.add(nome);
		}
		this.banco.fecharConexao();
		return retorno;
	}
	
	public Vector<String> retornaPublicacoesDeUmaLinha(String nomeLinha) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();
		String query = "select p.titulo_publicacao from tb_linha_publicacao p where p.nome_linha = '" + nomeLinha + "'";
		ResultSet rs = this.banco.pegaDados(query);
		while(rs.next()){
			String nome = rs.getString("titulo_publicacao");
			retorno.add(nome);
		}
		this.banco.fecharConexao();
		return retorno;
	}
	
	
	public Vector<String> buscaLinhaPorMembro(Vector<String> autores) throws SQLException, ClassNotFoundException{
		Vector<String> temp = new Vector<String>();
		Vector<String> retorno = new Vector<String>();
		Iterator<String> it = autores.iterator();
		while(it.hasNext()){
			String autor = it.next();
			String query = "select p.nome_linha from tb_linha_membro p where p.nome_membro = '" + autor + "'";
			ResultSet rs = this.banco.pegaDados(query);
			while(rs.next()){
			String tituloLinha = rs.getString("nome_linha");
			temp.add(tituloLinha);
			}
		}
		
		Iterator<String> it2 = temp.iterator();
		while(it2.hasNext()){
			String titulo = it2.next();
			if(!(retorno.contains(titulo))){
				retorno.add(titulo);
			}
		}
		
		return retorno;
	}
	
	public static void main(String[] args) {
	}
}