package repositorio;

import java.sql.*;
import java.util.Vector;

public class ComunicaBD {

	private String usuario = "system";
	private String senha = "password";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String driver = "oracle.jdbc.driver.OracleDriver";
	
	private Connection conexao = null;
	private Statement stat = null;
	private ResultSet result = null;
	
//	este metodo � usado para fazer SELECT
	public ResultSet pegaDados(String query) throws SQLException, ClassNotFoundException{
		conexao = null;
		stat = null;
		result = null;
		try{
			Class.forName(driver);
			}
			catch(Exception x){
				System.out.println( "Unable to load the driver class!" );
			}		
		conexao = DriverManager.getConnection(url,usuario,senha);
		stat = conexao.createStatement();
		result = stat.executeQuery(query);
		return result;
	}
	
//	este metodo � usado para fazer INSERT, DELETE, UPDATE, CREATE, DROP
	public void modificaTabela(String query)throws SQLException, ClassNotFoundException{
		String sql = query;
		this.conexao = null;
		this.stat = null;
		try{
		Class.forName(driver);
		}
		catch(Exception x){
			System.out.println( "Unable to load the driver class!" );
		}
		
		conexao = DriverManager.getConnection(url,usuario,senha);
		stat = conexao.createStatement();
		stat.executeUpdate(sql);
		conexao.commit();
	}
	public void fecharConexao()throws SQLException{
		conexao.commit();
		result.close();
		conexao.close();
		stat.close();
	}		
	
	public void executarBatchs(Vector comandos) throws SQLException, ClassNotFoundException {
		this.conexao = null;
		this.stat = null;
		Class.forName(driver);		
		this.conexao = DriverManager.getConnection(this.url,this.usuario,this.senha);
		this.stat = conexao.createStatement();
		this.conexao.setAutoCommit(false);
		this.stat.clearBatch();
		int x = 0;
		while (x < comandos.size()) {
			this.stat.addBatch((String) comandos.get(x));
			x = x + 1;
		}
		int[] conta = this.stat.executeBatch();
		this.conexao.commit();
		System.out.println(conta[0]);
	}
	
	public static void main(String[] args) {
		//String query = "insert into TB_MEMBRO (id_membro, login, senha, email, nome, foto) values " +
		//"(TB_MEMBRO_SEQ.NEXTVAL, 'teste', 'teste123', 'teste@aol.com', 'teste silva', empty_blob())";
		
		String query = "select login, foto from tb_membro where login = 'teste' for update";
		ComunicaBD c = new ComunicaBD();
		
			try {
				ResultSet rs = c.pegaDados(query);
				rs.next();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	
		
	}
}
