package repositorio;

import java.sql.Connection; 

/* 
* To change this template, choose Tools | Templates 
* and open the template in the editor. 
*/ 
import java.sql.DriverManager; 
import java.sql.ResultSet; 
import java.sql.Statement; 
import javax.swing.JOptionPane; 

/** 
* 
* @author Jacques Nogueira dos Santos 
*/ 
public class Principal { 
public Connection con =null; 
public String url=""; 
public Statement stmt = null; 
public ResultSet res = null; 

public Principal(){ 

url = "jdbc:hsqldb:file:C://Users//Paola//testedb"; 

try { 
Class.forName("org.hsqldb.jdbcDriver" ); 
JOptionPane.showMessageDialog(null,"Identificou o driver"); 
con = DriverManager.getConnection(url, "sa",""); 
JOptionPane.showMessageDialog(null,"Conectou"); 
stmt = con.createStatement();  
res = stmt.executeQuery("select * from customer");  
while(res.next()){ 
System.out.println(res.getString("firstname")); 
stmt.execute("SHUTDOWN");
} 

} catch (Exception e) { 
System.out.println("ERROR: failed to load HSQLDB JDBC driver."); 
e.printStackTrace(); 
return; 
} 


} 
public static void main(String args[]){ 

Principal principal = new Principal(); 


} 
} 