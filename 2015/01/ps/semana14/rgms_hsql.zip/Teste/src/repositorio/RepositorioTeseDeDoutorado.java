package repositorio;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import oracle.sql.BLOB;

import base.*;

public class RepositorioTeseDeDoutorado {
	
	private ComunicaBDHSQLDB banco;
	
	public RepositorioTeseDeDoutorado() {
		this.banco = new ComunicaBDHSQLDB();

	}
	public void inserirTeseDeDoutorado(TeseDeDoutorado x) throws SQLException,
			ClassNotFoundException, IOException {
		
		//carrega as queries
		String query = "insert into TB_PUBLICACOES values ( DEFAULT , '" + x.getTitulo() + "' , '" +
		x.getAno() + "' , '" + x.getAutoresMembros() + "' , ?, 'tesedoutorado')";
		//armazena com blob
		banco.modificaTabelaComBlob(query, x.getUrlPdf());
		
		int idPublicacao = this.retornaIdPublicacao(x.getTitulo());
		String query2 = "insert into TB_TESE_DOUTORADO values ('" + x.getInstituicao() + "' , '"+ 
		x.getMes() + "' , '" + x.getTitulo()+ "' , " + idPublicacao +")";
		

		
		banco.modificaTabela(query2);
		int idMembro = this.buscaIdMembro(x.getAutoresMembros());
		//insere linha na tb_membro_publicacao
		String q = "insert into tb_membro_publicacao values ('" + x.getTitulo() + "' , '" + x.getAutoresMembros() 
		+"' , "+ idMembro + " , " + idPublicacao +")";
		this.banco.modificaTabela(q);
		
		//LINHASDEPESQUISA
		for(int i = 0; i < x.getLinhasDePesquisa().size(); i++){
			String nomeLinha = x.getLinhasDePesquisa().elementAt(i);
			int idLinha = this.buscaIdLinha(nomeLinha);
			String a = "insert into tb_linha_publicacao values ( " + idLinha + " , " + idPublicacao +
			" , '" + nomeLinha + "' , '" + x.getTitulo()+ "')";
			this.banco.modificaTabela(a);
		}	
		//LINHASDEPESQUISA
		

		//this.banco.fecharConexao();
	}
	
	public boolean autenticaArtigo(String tituloArtigo) throws SQLException, ClassNotFoundException{
		boolean achou = false;
		
		String query = "select p.titulo from tb_publicacoes p where p.titulo = '" +
		tituloArtigo + "'";
		ResultSet result = this.banco.pegaDados(query);
		
		//verifica se resultset eh vazio
		int x = 0;
		while(result.next()){
			x = x + 1;
		}
		if(x != 0){
			
			achou = true;
		}
		//this.banco.fecharConexao();
		return achou;
	}

	public Vector procurarTeseDeDoutoradoLike(String tituloTese)
			throws SQLException, ClassNotFoundException {

		return null;
	}
	
	public TeseDeDoutorado buscaTeseDeDoutorado (String tituloTese) throws SQLException, ClassNotFoundException, IOException{
		TeseDeDoutorado retorno = new TeseDeDoutorado();
		//carrega publicacao
		String query = "select p.* from tb_publicacoes p where p.titulo = '" + tituloTese + "'"; 
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		retorno.setTitulo(rs.getString("titulo"));
		retorno.setAno(rs.getString("ano"));
		retorno.setAutoresMembros(rs.getString("autores"));
		retorno.setId_publicacao(rs.getInt("id_publicacao"));
		
		//carrega o pdf
		
		int bytesRead = 0;
		File byteFileDb = new File("artigo.pdf");
		Blob blob = rs.getBlob("pdf_publicacao");
		byte[] bbuf = new byte[8192];
		InputStream bin = blob.getBinaryStream();  
		OutputStream bout = new FileOutputStream(byteFileDb);  
		while ((bytesRead = bin.read(bbuf)) != -1) {  
		  bout.write(bbuf, 0, bytesRead);  
		}  
		bin.close();  
		bout.close();
		
		
		retorno.setPdf(byteFileDb);
		
		//carrega info de tese de doutorado
		String q = "select p.* from tb_tese_doutorado p where p.titulo_publicacao = '" + tituloTese + "'";
		ResultSet rs2 = this.banco.pegaDados(q);
		rs2.next();
		retorno.setInstituicao(rs2.getString("escola"));
		retorno.setMes(rs2.getString("mes"));
		
		//this.banco.fecharConexao();
		return retorno;
	}
	public void removerTeseDeDoutorado(TeseDeDoutorado x) throws SQLException,
			ClassNotFoundException {
	}

	public void editarTeseDeDoutorado(TeseDeDoutorado x)
			throws SQLException, ClassNotFoundException, IOException {
		//removendo as linhas de tb_membro_publicacao
		String query1 = "delete from tb_membro_publicacao a where a.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(query1);
		
		//insere as linhas de tb_membro_publicacao
		int idMembro = this.buscaIdMembro(x.getAutoresMembros());
		String q = "insert into tb_membro_publicacao values ('" + x.getTitulo() + "' , '" + x.getAutoresMembros() 
		 + "' , "+ idMembro + " , " + x.getId_publicacao() +")";
		this.banco.modificaTabela(q);
		
		//da o update na tb_tese_doutorado
		String query4 = "update tb_tese_doutorado p set p.escola = '" + x.getInstituicao() +
		"' , p.mes = '" + x.getMes() + "' , p.titulo_publicacao = '" + x.getTitulo() + "' where p.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(query4);
		
		//adiciona linha em tb_publicacoes
		String query2 = "update tb_publicacoes p set p.titulo = '" + x.getTitulo() + "' , p.ano = '" +
		x.getAno() + "' , p.autores = '" + x.getAutoresMembros() + "' where p.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(query2);
		//LINHASDEPESQUISA
		//d� o update na tb_linha_publicacao
			String a = "delete from tb_linha_publicacao a where a.id_publicacao = " + x.getId_publicacao();
			this.banco.modificaTabela(a);
			
			for(int i = 0; i < x.getLinhasDePesquisa().size(); i++){
				String linha = x.getLinhasDePesquisa().elementAt(i);
				int idLinha = this.buscaIdLinha(linha);
				String b = "insert into tb_linha_publicacao values (" + idLinha + " , " + x.getId_publicacao() +
				" , '" + linha + "' , '" + x.getTitulo() + "')";
				this.banco.modificaTabela(b);
				
			}
			
		//LINHASDEPESQUISA
		if(x.getUrlPdf() != null){
			//insere o blob no bd
			String query3 = "select id_publicacao , pdf_publicacao from tb_publicacoes where id_publicacao = " + x.getId_publicacao() + " for update";
			ResultSet rs = this.banco.pegaDados(query3);
			rs.next();
			
			//copia o stream de bytes pra dentro do blob
			File byteFile = new File(x.getUrlPdf());
	        Blob blob = rs.getBlob("pdf_publicacao");
	        byte[] bbuf = new byte[1024];
	        InputStream bin = new FileInputStream(byteFile);
	        OutputStream bout = ((BLOB) blob).getBinaryOutputStream(); // espec�fico driver oracle
	        int bytesRead = 0;
	        while ((bytesRead = bin.read(bbuf)) != -1) {
	            bout.write(bbuf, 0, bytesRead);
	        }
	        bin.close();
	        bout.close();
		}
		
		
		//this.banco.fecharConexao();
	}
	
	public int retornaIdPublicacao(String tituloPublicacao) throws SQLException, ClassNotFoundException{
		String query = "select p.id_publicacao from tb_publicacoes p where p.titulo = '" + tituloPublicacao + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_publicacao");
		return retorno;
	}
	public int buscaIdMembro(String nomeMembro) throws SQLException, ClassNotFoundException{
		String query = "select p.id_membro from tb_membro p where p.nome = '" + nomeMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_membro");
		
		return retorno;
		
	}
	
	//LINHASDEPESQUISA
	public int buscaIdLinha(String tituloLinha) throws SQLException, ClassNotFoundException{
		String query = "select p.id_linha from tb_linhadepesquisa p where p.titulo = '" + tituloLinha + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_linha");
		//this.banco.fecharConexao();
		
		return retorno;
	}
	//LINHASDEPESQUISA

}
