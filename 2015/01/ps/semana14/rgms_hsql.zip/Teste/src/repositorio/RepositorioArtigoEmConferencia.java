package repositorio;

import base.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import oracle.sql.BLOB;

public class RepositorioArtigoEmConferencia {


	private ComunicaBDHSQLDB banco;

	public RepositorioArtigoEmConferencia() {

		this.banco = new ComunicaBDHSQLDB();
	}
	public Vector<String> retornaMembrosDeUmaPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();

		String query = "select p.nome_membro from tb_membro_publicacao p where p.titulo_publicacao = '" + tituloPub + "'";

		ResultSet rs = this.banco.pegaDados(query);

		while(rs.next()){
			String x = rs.getString("nome_membro");
			retorno.add(x);
		}
		return retorno;
	}

	public String retornaTipoPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		String retorno = "";

		String query = "select p.tipo_publicacao from tb_publicacoes p where p.titulo = '" + tituloPub + "'";

		ResultSet rs = this.banco.pegaDados(query);
		rs.next();

		retorno = rs.getString("tipo_publicacao");

		return retorno;
	}
	public void inserirArtigoEmConferencia(ArtigoEmConferencia x)
	throws SQLException, ClassNotFoundException, IOException {

		//insere TB_PUBLICACOES
		String query = "insert into TB_PUBLICACOES values ( DEFAULT , '" + x.getTitulo() + "' , '" +
		x.getAno() + "' , '" + x.getAutoresNaoMembros() + "' , ? , 'artigoconferencia')";
		//armazena com blob
		banco.modificaTabelaComBlob(query, x.getUrlPdf());

		//insere tb_artigo_conferencia
		int idPublicacao = this.retornaIdPublicacao(x.getTitulo());
		String query2 = "insert into tb_artigo_conferencia values ('" + x.getConferencia() + "' , '" + x.getMes() + "' , '"
		+ x.getPaginas() + "' , '" + x.getTitulo() + "' , " + idPublicacao + ")";
		banco.modificaTabela(query2);

		//insere linhas na tb_membro_publicacao
		int tamanho = x.getNomeAutoresMembros().size();

		for(int i = 0; i < tamanho; i++ ){
			String nomeAutor = x.getNomeAutoresMembros().elementAt(i);
			int idMembro = this.buscaIdMembro(nomeAutor);
			String q = "insert into tb_membro_publicacao values ('" + x.getTitulo() + "' , '" + nomeAutor +
			"' , " + idMembro + " , " + idPublicacao + ")";

			this.banco.modificaTabela(q);
		}

		//LINHASDEPESQUISA
		for(int i = 0; i < x.getLinhasDePesquisa().size(); i++){
			String nomeLinha = x.getLinhasDePesquisa().elementAt(i);
			int idLinha = this.buscaIdLinha(nomeLinha);
			String a = "insert into tb_linha_publicacao values ( " + idLinha + " , " + idPublicacao +
			" , '" + nomeLinha + "' , '" + x.getTitulo()+ "')";
			this.banco.modificaTabela(a);
		}

		//LINHASDEPESQUISA

		//this.banco.fecharConexao();
	}

	//LINHASDEPESQUISA
	public int buscaIdLinha(String tituloLinha) throws SQLException, ClassNotFoundException{
		String query = "select p.id_linha from tb_linhadepesquisa p where p.titulo = '" + tituloLinha + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_linha");
		//this.banco.fecharConexao();

		return retorno;
	}

	public Vector<String> retornaLinhasDeUmaPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector<String>();
		String query = "select p.nome_linha from tb_linha_publicacao p where p.titulo_publicacao = '" + tituloPub + "'" ;
		ResultSet rs = this.banco.pegaDados(query);
		while(rs.next()){
			String nomeLinha = rs.getString("nome_linha");
			retorno.add(nomeLinha);
		}
		return retorno;
	}
	//LINHASDEPESQUISA

	public int retornaIdPublicacao(String tituloPublicacao) throws SQLException, ClassNotFoundException{
		String query = "select p.id_publicacao from tb_publicacoes p where p.titulo = '" + tituloPublicacao + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_publicacao");
		return retorno;
	}
	//esse metodo vai retornar o t�tulo de todas as publica��es 
	public Vector<ArtigoEmConferencia> retornaTodasPublicacoes() throws SQLException, ClassNotFoundException{

		Vector<ArtigoEmConferencia> retorno = new Vector();
		String query = "select p.titulo, p.autores, p.ano from tb_publicacoes p";
		ResultSet rs = this.banco.pegaDados(query);

		while(rs.next()){
			ArtigoEmConferencia artigo = new ArtigoEmConferencia();
			artigo.setTitulo(rs.getString("titulo"));
			artigo.setAutoresNaoMembros(rs.getString("autores"));
			artigo.setAno(rs.getString("ano"));
			retorno.add(artigo);
		}
		return retorno;
	}

	public ArtigoEmConferencia buscaArtigoEmConferencia(String tituloArtigo)
	throws SQLException, ClassNotFoundException, IOException {

		ArtigoEmConferencia retorno = new ArtigoEmConferencia();

		//carrega publicacao
		String query = "select p.* from tb_publicacoes p where p.titulo = '" + tituloArtigo + "'"; 
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		retorno.setTitulo(rs.getString("titulo"));
		retorno.setAno(rs.getString("ano"));
		retorno.setAutoresNaoMembros(rs.getString("autores"));
		retorno.setId_publicacao(rs.getInt("id_publicacao"));

		//carrega o pdf
		Blob blob = rs.getBlob("pdf_publicacao");
		File byteFileDb = null;



		int bytesRead = 0;
		byteFileDb = new File("artigo.pdf");
		byte[] bbuf = new byte[8192];
		InputStream bin = blob.getBinaryStream();  
		OutputStream bout = new FileOutputStream(byteFileDb);  
		while ((bytesRead = bin.read(bbuf)) != -1) {  
			bout.write(bbuf, 0, bytesRead);  
		}  
		bin.close();  
		bout.close();
		retorno.setPdf(byteFileDb);




		//carrega info do artigo em conferencia
		String query2 = "select p.* from tb_artigo_conferencia p where p.titulo_publicacao = '" + tituloArtigo + "'";
		ResultSet rs2 = this.banco.pegaDados(query2);
		rs2.next();
		retorno.setConferencia(rs2.getString("NOME_CONFERENCIA"));
		retorno.setMes(rs2.getString("mes"));
		retorno.setPaginas(rs2.getString("numero_paginas"));

		//this.banco.fecharConexao();
		return retorno;
	}

	public void removerArtigoEmConferencia(ArtigoEmConferencia x)
	throws SQLException, ClassNotFoundException {
	}

	public void editarArtigoEmConferencia(ArtigoEmConferencia x)
	throws SQLException, ClassNotFoundException, IOException {

		//removendo as linhas de tb_membro_publicacao
		String query1 = "delete from tb_membro_publicacao a where a.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(query1);

		//insere as linhas de tb_membro_publicacao
		int tamanho = x.getNomeAutoresMembros().size();

		for(int i = 0; i < tamanho; i++ ){
			String nomeAutor = x.getNomeAutoresMembros().elementAt(i);
			int idMembro = this.buscaIdMembro(nomeAutor);
			String q = "insert into tb_membro_publicacao values ('" + x.getTitulo() + "' , '" + nomeAutor +
			"' , " + idMembro + " , " + x.getId_publicacao() + ")";


			this.banco.modificaTabela(q);
		}

		//d� o update na tb_artigo_conferencia
		String query4 = "update tb_artigo_conferencia p set p.nome_conferencia = '" + x.getConferencia() + 
		"' , p.mes = '" + x.getMes() + "' , p.numero_paginas = '" + x.getPaginas() + "' , p.titulo_publicacao = '" +
		x.getTitulo() + "' where p.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(query4);

		//d� o update na tb_publicacao
		String query2 = "update tb_publicacoes p set p.titulo = '" + x.getTitulo() + "' , p.ano = '" +
		x.getAno() + "' , p.autores = '" + x.getAutoresNaoMembros() + "' where p.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(query2);

		//LINHASDEPESQUISA
		//d� o update na tb_linha_publicacao
		String a = "delete from tb_linha_publicacao a where a.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(a);

		for(int i = 0; i < x.getLinhasDePesquisa().size(); i++){
			String linha = x.getLinhasDePesquisa().elementAt(i);
			int idLinha = this.buscaIdLinha(linha);
			String b = "insert into tb_linha_publicacao values (" + idLinha + " , " + x.getId_publicacao() +
			" , '" + linha + "' , '" + x.getTitulo() + "')";
			this.banco.modificaTabela(b);

		}

		//LINHASDEPESQUISA
		if(x.getUrlPdf() != null){
			//insere o blob no bd
			String query3 = "select id_publicacao , pdf_publicacao from tb_publicacoes where id_publicacao = " + x.getId_publicacao() + " for update";
			ResultSet rs = this.banco.pegaDados(query3);
			rs.next();

			//copia o stream de bytes pra dentro do blob
			File byteFile = new File(x.getUrlPdf());
			Blob blob = rs.getBlob("pdf_publicacao");
			byte[] bbuf = new byte[1024];
			InputStream bin = new FileInputStream(byteFile);
			OutputStream bout = ((BLOB) blob).getBinaryOutputStream(); // espec�fico driver oracle
			int bytesRead = 0;
			while ((bytesRead = bin.read(bbuf)) != -1) {
				bout.write(bbuf, 0, bytesRead);
			}
			bin.close();
			bout.close();
		}



		//this.banco.fecharConexao();
	}

	public boolean autenticaArtigo(String tituloArtigo) throws SQLException, ClassNotFoundException{
		boolean achou = false;

		String query = "select p.titulo from tb_publicacoes p where p.titulo = '" +
		tituloArtigo + "'";
		ResultSet result = this.banco.pegaDados(query);

		//verifica se resultset eh vazio
		int x = 0;
		while(result.next()){
			x = x + 1;
		}
		if(x != 0){

			achou = true;
		}
		//this.banco.fecharConexao();
		return achou;
	}

	public int buscaIdMembro(String nomeMembro) throws SQLException, ClassNotFoundException{
		String query = "select p.id_membro from tb_membro p where p.nome = '" + nomeMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_membro");

		return retorno;

	}

	public Vector<ArtigoEmConferencia> procurarArtigoLike(String tituloPub)
	throws SQLException, ClassNotFoundException {

		Vector<ArtigoEmConferencia> retorno = new Vector();

		String query = "select p.titulo from tb_publicacoes p where p.titulo like '%" + tituloPub + "%'";
		ResultSet result = this.banco.pegaDados(query);
		while(result.next()){

			ArtigoEmConferencia x = new ArtigoEmConferencia();
			x.setTitulo(result.getString("titulo"));
			retorno.add(x);
		}

		//this.banco.fecharConexao();
		return retorno;
	}
	//metodo retorna vector com entradas duplicadas
	public Vector<String> buscaPublicacaoPorMembro(Vector<String> autores) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();
		Iterator<String> it = autores.iterator();
		while(it.hasNext()){
			String autor = it.next();
			String query = "select p.titulo_publicacao from tb_membro_publicacao p where p.nome_membro = '" + autor + "'";
			ResultSet rs = this.banco.pegaDados(query);
			while(rs.next()){
				String tituloPub = rs.getString("titulo_publicacao");
				retorno.add(tituloPub);
			}
		}
		return retorno;
	}



	public static void main(String[] args) {
		ArtigoEmConferencia artigo = new ArtigoEmConferencia();
		artigo.setTitulo("testando repositorio");
		artigo.setAno("1234");
		artigo.setAutoresNaoMembros("hauhsauhsa");
		artigo.setConferencia("conf");
		artigo.setMes("janeiro");
		artigo.setPaginas("123");
		artigo.setTitulo("titulooooo");
		artigo.setUrlPdf("Tutorial_JSP1.pdf");
		RepositorioArtigoEmConferencia r = new RepositorioArtigoEmConferencia();
		try {
			r.inserirArtigoEmConferencia(artigo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}

}
