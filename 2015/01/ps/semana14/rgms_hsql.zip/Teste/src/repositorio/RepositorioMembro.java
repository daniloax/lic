package repositorio;

import base.Membro;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.ImageIcon;

import oracle.sql.BLOB;

import java.util.Iterator;

public class RepositorioMembro {
	
	private ComunicaBDHSQLDB banco;
	
	public RepositorioMembro(){
		banco = new ComunicaBDHSQLDB();
	}
	public void inserirMembro(Membro x) throws SQLException,
			ClassNotFoundException, IOException {
		
		
		
		//insere membro com blob vazio
		String query = "insert into tb_membro values (DEFAULT, '"+ x.getLogin() + "' , '"
		+ x.getSenha() + "' , '" + x.getUniversidade()+ "' ,' " + x.getDpto_univ() + "' , '" + x.getEmail()+ "' , '" + 
		x.getWebsite() + "' , '" + x.getTelefone() + "' , '" + x.getCidade() + "' , '"+ x.getPais() + "' , '"+ x.getStatus() + "' , '"+
		x.getNome() + "' , "+  "?, '" + x.getTipo() + "')";
		
		String urfFoto = x.getUrlFoto();
		
		this.banco.modificaTabelaComBlob(query, urfFoto);
		
		
		//LINHADEPESQUISA
		int idMembro = this.buscaIdMembro(x.getLogin());
		for(int i =0; i < x.getLinhasDePesquisa().size(); i++){
			String nomeLinha = x.getLinhasDePesquisa().elementAt(i);
			int idLinha = this.buscaIdLinha(nomeLinha);
			String query3 = "insert into tb_linha_membro values(" + idLinha + " , " + idMembro + " , '" + nomeLinha +
			"' , '" + x.getNome()+ "')";
			this.banco.modificaTabela(query3);
		}
		//LINHADEPESQUISA
		
		
		
		
	}

	
	public Vector<Membro> retornaTodosMembros() throws SQLException, ClassNotFoundException{
		
		Vector<Membro> retorno = new Vector();
		String query = "select p.nome, p.login, p.tipo from tb_membro p";
		ResultSet rs = this.banco.pegaDados(query);
		while(rs.next()){
			Membro x = new Membro();
			x.setLogin(rs.getString("login"));
			x.setNome(rs.getString("nome"));
			x.setTipo(rs.getString("tipo"));
			retorno.add(x);
		}
		
		this.banco.fecharConexao();
		return retorno;
	}
	
	
	// nomeMembro � o nome da pessoa buscada.
	
	public Vector<Membro> procurarMembroLike(String nomeMembro)
			throws SQLException, ClassNotFoundException {
		Vector<Membro> retorno = new Vector();
		
		String query = "select p.nome from tb_membro p where p.nome like '%" + nomeMembro + "%'";
		ResultSet result = this.banco.pegaDados(query);
		while(result.next()){
			
			Membro x = new Membro();
			x.setNome(result.getString("nome"));
			retorno.add(x);
		}
		
		this.banco.fecharConexao();
		return retorno;
	}
	
	public Membro buscaMembro(String nomeMembro)throws SQLException, ClassNotFoundException, IOException{
		Membro retorno = new Membro();
		
		String query = "select p.* from tb_membro p where p.nome = '" + nomeMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		retorno.setNome(rs.getString("nome"));
		retorno.setUniversidade(rs.getString("nome_universidade"));
		retorno.setDpto_univ(rs.getString("nome_dpto"));
		retorno.setTipo(rs.getString("tipo"));
		retorno.setEmail(rs.getString("email"));
		retorno.setTelefone(rs.getString("telefone"));
		retorno.setStatus(rs.getString("status"));
		retorno.setLogin(rs.getString("login"));
		retorno.setWebsite(rs.getString("website"));
		retorno.setCidade(rs.getString("cidade"));
		retorno.setPais(rs.getString("pais"));
		retorno.setId_membro(rs.getInt("id_membro"));
		//carrega o blob
		int bytesRead = 0;
		File byteFileDb = new File("foto.jpg");
		Blob blob = rs.getBlob("foto");
		byte[] bbuf = new byte[1024];
		InputStream bin = blob.getBinaryStream();  
		OutputStream bout = new FileOutputStream(byteFileDb);  
		while ((bytesRead = bin.read(bbuf)) != -1) {  
		  bout.write(bbuf, 0, bytesRead);  
		}  
		bin.close();  
		bout.close();
		
		ImageIcon imagem = new ImageIcon(byteFileDb.getAbsolutePath());
		Image temp = imagem.getImage();
		Image temp2 = temp.getScaledInstance(127,142, 0);
		retorno.setFoto(new ImageIcon(temp2));
		
		this.banco.fecharConexao();
		
		return retorno;
	}
	
	public Membro buscaMembroLogin(String loginMembro)throws SQLException, ClassNotFoundException, IOException{
		Membro retorno = new Membro();
		
		String query = "select p.* from tb_membro p where p.login = '" + loginMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		retorno.setNome(rs.getString("nome"));
		retorno.setUniversidade(rs.getString("nome_universidade"));
		retorno.setDpto_univ(rs.getString("nome_dpto"));
		retorno.setTipo(rs.getString("tipo"));
		retorno.setEmail(rs.getString("email"));
		retorno.setTelefone(rs.getString("telefone"));
		retorno.setStatus(rs.getString("status"));
		retorno.setLogin(rs.getString("login"));
		retorno.setWebsite(rs.getString("website"));
		retorno.setCidade(rs.getString("cidade"));
		retorno.setPais(rs.getString("pais"));
		retorno.setId_membro(rs.getInt("id_membro"));
		
		
		//carrega o blob
		int bytesRead = 0;
		File byteFileDb = new File("foto.jpg");
		Blob blob = rs.getBlob("foto");
		byte[] bbuf = new byte[1024];
		InputStream bin = blob.getBinaryStream();  
		OutputStream bout = new FileOutputStream(byteFileDb);  
		while ((bytesRead = bin.read(bbuf)) != -1) {  
		  bout.write(bbuf, 0, bytesRead);  
		}  
		bin.close();  
		bout.close();
		
		ImageIcon imagem = new ImageIcon(byteFileDb.getAbsolutePath());
		Image temp = imagem.getImage();
		Image temp2 = temp.getScaledInstance(127,142, 0);
		retorno.setFoto(new ImageIcon(temp2));
		
		this.banco.fecharConexao();
		
		return retorno;
	}
	public void removerMembro(Membro x) throws SQLException,
			ClassNotFoundException {
	}

	public void editarMembro(Membro x) throws SQLException,
			ClassNotFoundException, IOException {
		String query = "update tb_membro p set p.login = '" + x.getLogin() + "' , p.senha = '"+ x.getSenha()
		+ "' , p.nome_universidade = '" + x.getUniversidade() + "' , p.nome_dpto = '"+ x.getDpto_univ() 
		+"' , p.email = '" + x.getEmail() + "' , p.website = '" + x.getWebsite() + "' , p.telefone = '" + x.getTelefone()
		+ "' , p.cidade = '" + x.getCidade() + "' , p.pais = '" + x.getPais() + "' , p.status = '" + x.getStatus()
		+ "' , p.nome = '" + x.getNome() + "' , p.tipo = '"+ x.getTipo() + "' where p.id_membro = '"+ x.getId_membro() + "'";
		
		this.banco.modificaTabela(query);
		
		//modifica tb_membro_publicacao
		String q = "update tb_membro_publicacao p set p.nome_membro = '" + x.getNome() + "' where p.id_membro = " + x.getId_membro();
		this.banco.modificaTabela(q);
		
		//LINHASDEPESQUISA
		String a = "delete from tb_linha_membro a where a.id_membro = " + x.getId_membro();
		this.banco.modificaTabela(a);
		for(int i = 0; i< x.getLinhasDePesquisa().size(); i++){
		String nomeLinha = x.getLinhasDePesquisa().elementAt(i);
		int idLinha = this.buscaIdLinha(nomeLinha);
		String b = "insert into tb_linha_membro values(" + idLinha + " , " + x.getId_membro() + " , '"+ nomeLinha +
		"' , '" + x.getNome()+"')";
		this.banco.modificaTabela(b);
		}
		//LINHASDEPESQUISA
		
		if(x.getUrlFoto()!= null){
		//insere o blob no bd
		String query2 = "select login , foto from tb_membro where login = '" + x.getLogin() + "' for update";
		ResultSet rs = this.banco.pegaDados(query2);
		rs.next();
		
		//copia o stream de bytes pra dentro do blob
		File byteFile = new File(x.getUrlFoto());
        Blob blob = rs.getBlob("foto");
        byte[] bbuf = new byte[1024];
        InputStream bin = new FileInputStream(byteFile);
        OutputStream bout = ((BLOB) blob).getBinaryOutputStream(); // espec�fico driver oracle
        int bytesRead = 0;
        while ((bytesRead = bin.read(bbuf)) != -1) {
            bout.write(bbuf, 0, bytesRead);
        }
        bin.close();
        bout.close();
		}
		
		
		//this.banco.fecharConexao();
		
		
	}
	
	
	public int buscaIdMembro(String loginMembro) throws SQLException, ClassNotFoundException{
		String query = "select p.id_membro from tb_membro p where p.login = '" + loginMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_membro");
		this.banco.fecharConexao();
		
		return retorno;
	}
	
	public int buscaIdLinha(String tituloLinha) throws SQLException, ClassNotFoundException{
		String query = "select p.id_linha from tb_linhadepesquisa p where p.titulo = '" + tituloLinha + "'";
		ResultSet rs = this.banco.pegaDados(query);
		rs.next();
		int retorno = rs.getInt("id_linha");
		this.banco.fecharConexao();
		
		return retorno;
	}
	
	public boolean autenticarMembro(String login, String senha)throws SQLException,
			ClassNotFoundException {
		
		//busca usuario no banco
		boolean autenticado = false;
		String query = "select p.* from tb_membro p where p.login = '" + login + "' and p.senha = '" + senha + "'";
		ResultSet result = this.banco.pegaDados(query);
		
		//verifica se resultset eh vazio
		int x = 0;
		while(result.next()){
			x = x + 1;
		}
		if(x != 0){
			
			autenticado = true;
		}
		this.banco.fecharConexao();
		return autenticado;
	}
	
	public Vector<String> retornaPublicacoes(String nomeMembro) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();
		String query = "select p.* from tb_membro_publicacao p where p.nome_membro = '" + nomeMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		while(rs.next()){
			String nome = rs.getString("TITULO_PUBLICACAO");
			retorno.add(nome);
		}
		return retorno;
	}
	public Vector<String> retornaLinhas(String nomeMembro) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();
		String query = "select p.nome_linha from tb_linha_membro p where p.nome_membro = '" + nomeMembro + "'";
		ResultSet rs = this.banco.pegaDados(query);
		while(rs.next()){
			String nome = rs.getString("nome_linha");
			retorno.add(nome);
		}
		return retorno;
	}
	public static void main(String[] args) {
		RepositorioMembro r = new RepositorioMembro();
		try {
			int x = r.buscaIdMembro("PAOLA123");
			System.out.println(x);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
