package repositorio;

import base.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import oracle.sql.BLOB;



public class RepositorioArtigoEmPeriodicoERevista {
	
	private ComunicaBDHSQLDB banco ;
	
	
	public RepositorioArtigoEmPeriodicoERevista(){
		this.banco = new ComunicaBDHSQLDB();
	}
	public void inserirArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x) throws SQLException,
	ClassNotFoundException, IOException {
		
		//carrega as queries
		String query = "insert into TB_PUBLICACOES values ( DEFAULT , '" + x.getTitulo() + "' , '" +
		x.getAno() + "' , '" + x.getAutoresNaoMembros() + "' , ? , 'artigoperiodico')";
		//insere a linha com blob
		this.banco.modificaTabelaComBlob(query, x.getUrlPdf());
		
		//insere tb_artigo_periodico_revista
		int idPublicacao = this.retornaIdPublicacao(x.getTitulo());
		String query2 = "insert into tb_artigo_periodico_revista values('" + x.getJornal() + "' , '" +
		 x.getVolume() + "' , '" + x.getNumero() + "' , '" + x.getPaginas() + "' , '" + x.getTitulo() + "' ,"+ idPublicacao + ")";
		
		
		this.banco.modificaTabela(query2);
		
		//insere linhas na tb_membro_publicacao
		int tamanho = x.getNomeAutoresMembros().size();
		
		for(int i = 0; i < tamanho; i++ ){
			String nomeAutor = x.getNomeAutoresMembros().elementAt(i);
			int idMembro = this.buscaIdMembro(nomeAutor);
			String q = "insert into tb_membro_publicacao values ('" + x.getTitulo() + "' , '" + nomeAutor +
			"' , "+ idMembro + " , "+ idPublicacao + ")";
			
			this.banco.modificaTabela(q);
		}
		
		//LINHASDEPESQUISA
		for(int i = 0; i < x.getLinhasDePesquisa().size(); i++){
			String nomeLinha = x.getLinhasDePesquisa().elementAt(i);
			int idLinha = this.buscaIdLinha(nomeLinha);
			String a = "insert into tb_linha_publicacao values ( " + idLinha + " , " + idPublicacao +
			" , '" + nomeLinha + "' , '" + x.getTitulo()+ "')";
			this.banco.modificaTabela(a);
		}	
		//LINHASDEPESQUISA
		

		//this.banco.fecharConexao();
	}

	public boolean autenticaArtigo(String tituloArtigo) throws SQLException, ClassNotFoundException{
		boolean achou = false;
		
		String query = "select p.titulo from tb_publicacoes p where p.titulo = '" +
		tituloArtigo + "'";
		ResultSet result = this.banco.pegaDados(query);
		
		//verifica se resultset eh vazio
		int x = 0;
		while(result.next()){
			x = x + 1;
		}
		if(x != 0){
			
			achou = true;
		}
		//this.banco.fecharConexao();
		return achou;
	}
public Vector procurarArtigoEmPeriodicoERevista (String tituloArtigo)
	throws SQLException, ClassNotFoundException {

return null;
}

public ArtigoEmPeriodicoERevista buscaArtigoEmPeriodicoRevista (String tituloArtigo) throws SQLException, ClassNotFoundException, IOException{
	
	ArtigoEmPeriodicoERevista retorno = new ArtigoEmPeriodicoERevista();
	
	//carrega publicacao
	String query = "select p.* from tb_publicacoes p where p.titulo = '" + tituloArtigo + "'"; 
	ResultSet rs = this.banco.pegaDados(query);
	rs.next();
	retorno.setTitulo(rs.getString("titulo"));
	retorno.setAno(rs.getString("ano"));
	retorno.setAutoresMembros(rs.getString("autores"));
	retorno.setId_publicacao(rs.getInt("id_publicacao"));
	
	//carrega o pdf
	
	int bytesRead = 0;
	File byteFileDb = new File("artigo.pdf");
	Blob blob = rs.getBlob("pdf_publicacao");
	byte[] bbuf = new byte[8192];
	InputStream bin = blob.getBinaryStream();  
	OutputStream bout = new FileOutputStream(byteFileDb);  
	while ((bytesRead = bin.read(bbuf)) != -1) {  
	  bout.write(bbuf, 0, bytesRead);  
	}  
	bin.close();  
	bout.close();
	
	
	retorno.setPdf(byteFileDb);
	
	//carrega info do artigo de periodico ou revista
	String q = "select p.* from tb_artigo_periodico_revista p where p.titulo_publicacao = '" + tituloArtigo +"'";
	ResultSet rs2 = this.banco.pegaDados(q);
	rs2.next();
	retorno.setJornal(rs2.getString("nome_revista"));
	retorno.setVolume(rs2.getString("volume"));
	retorno.setNumero(rs2.getString("numero"));
	retorno.setPaginas(rs2.getString("numero_paginas"));
	return retorno;
}

public void removerArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x) throws SQLException,
	ClassNotFoundException {
}

public void editarArtigoEmPeriodicoERevista (ArtigoEmPeriodicoERevista x) throws SQLException,
	ClassNotFoundException, IOException {
	

	//removendo as linhas de tb_membro_publicacao
	String query1 = "delete from tb_membro_publicacao a where a.id_publicacao = " + x.getId_publicacao();
	this.banco.modificaTabela(query1);
	
	//insere as linhas de tb_membro_publicacao
	int tamanho = x.getNomeAutoresMembros().size();
	
	for(int i = 0; i < tamanho; i++ ){
		String nomeAutor = x.getNomeAutoresMembros().elementAt(i);
		int idMembro = this.buscaIdMembro(nomeAutor);
		String q = "insert into tb_membro_publicacao values ('" + x.getTitulo() + "' , '" + nomeAutor +
		"' , " + idMembro + " , " + x.getId_publicacao() + ")";
	
	
		this.banco.modificaTabela(q);
	}

	//adiciona linha em tb_artigo_periodico_revista
	String query4 = "update tb_artigo_periodico_revista p set p.nome_revista = '" + x.getJornal() + "' , p.volume = '" +
	x.getVolume() + "' , p.numero = '" + x.getNumero() + "' , p.numero_paginas = '" + x.getPaginas() 
	+ "' , p.titulo_publicacao = '" + x.getTitulo() + "' where p.id_publicacao = " + x.getId_publicacao();
	
	this.banco.modificaTabela(query4);
	
	//this.banco.fecharConexao();
	
	//adiciona linha em tb_publicacoes
	String query2 = "update tb_publicacoes p set p.titulo = '" + x.getTitulo() + "' , p.ano = '" +
	x.getAno() + "' , p.autores = '" + x.getAutoresNaoMembros() + "' where p.id_publicacao = " + x.getId_publicacao();
	this.banco.modificaTabela(query2);
	//this.banco.fecharConexao();
	
	//LINHASDEPESQUISA
	//d� o update na tb_linha_publicacao
		String a = "delete from tb_linha_publicacao a where a.id_publicacao = " + x.getId_publicacao();
		this.banco.modificaTabela(a);
		
		for(int i = 0; i < x.getLinhasDePesquisa().size(); i++){
			String linha = x.getLinhasDePesquisa().elementAt(i);
			int idLinha = this.buscaIdLinha(linha);
			String b = "insert into tb_linha_publicacao values (" + idLinha + " , " + x.getId_publicacao() +
			" , '" + linha + "' , '" + x.getTitulo() + "')";
			this.banco.modificaTabela(b);
			
		}
		
	//LINHASDEPESQUISA
	if(x.getUrlPdf() != null){
		//insere o blob no bd
		String query3 = "select id_publicacao , pdf_publicacao from tb_publicacoes where id_publicacao = " + x.getId_publicacao() + " for update";
		ResultSet rs = this.banco.pegaDados(query3);
		rs.next();
		
		//copia o stream de bytes pra dentro do blob
		File byteFile = new File(x.getUrlPdf());
        Blob blob = rs.getBlob("pdf_publicacao");
        byte[] bbuf = new byte[1024];
        InputStream bin = new FileInputStream(byteFile);
        OutputStream bout = ((BLOB) blob).getBinaryOutputStream(); // espec�fico driver oracle
        int bytesRead = 0;
        while ((bytesRead = bin.read(bbuf)) != -1) {
            bout.write(bbuf, 0, bytesRead);
        }
        bin.close();
        bout.close();
	}
	
	//this.banco.fecharConexao();
}

public int retornaIdPublicacao(String tituloPublicacao) throws SQLException, ClassNotFoundException{
	String query = "select p.id_publicacao from tb_publicacoes p where p.titulo = '" + tituloPublicacao + "'";
	ResultSet rs = this.banco.pegaDados(query);
	rs.next();
	int retorno = rs.getInt("id_publicacao");
	return retorno;
}
public int buscaIdMembro(String nomeMembro) throws SQLException, ClassNotFoundException{
	String query = "select p.id_membro from tb_membro p where p.nome = '" + nomeMembro + "'";
	ResultSet rs = this.banco.pegaDados(query);
	rs.next();
	int retorno = rs.getInt("id_membro");
	
	return retorno;
	
}

//LINHASDEPESQUISA
public int buscaIdLinha(String tituloLinha) throws SQLException, ClassNotFoundException{
	String query = "select p.id_linha from tb_linhadepesquisa p where p.titulo = '" + tituloLinha + "'";
	ResultSet rs = this.banco.pegaDados(query);
	rs.next();
	int retorno = rs.getInt("id_linha");
	//this.banco.fecharConexao();
	
	return retorno;
}
//LINHASDEPESQUISA
	
}

