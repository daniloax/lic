package fachada;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.ImageIcon;

import negocio.*;
import base.*;
import excecoes.*;

public class Fachada {
	private NegocioArtigoEmConferencia negocioArtigoEmConferencia = new NegocioArtigoEmConferencia();
	private NegocioArtigoEmPeriodicoERevista negocioArtigoEmPeriodicoERevista = new NegocioArtigoEmPeriodicoERevista();
	private NegocioDissertacaoDeMestrado negocioDissertacaoDeMestrado = new NegocioDissertacaoDeMestrado();
	private NegocioTeseDeDoutorado negocioTeseDeDoutorado = new NegocioTeseDeDoutorado();
	private NegocioMembro negocioMembro = new NegocioMembro();
	private NegocioLinhaDePesquisa negocioLinha = new NegocioLinhaDePesquisa();

	

	/*
	 * INICIO => GETS AND SETS
	 */

	public NegocioLinhaDePesquisa getNegocioLinhaDePesquisa() {
		return negocioLinha;
	}

	public void setnegocioLinhaDePesquisa(NegocioLinhaDePesquisa negociolinha) {
		this.negocioLinha = negociolinha;
	}

	public NegocioArtigoEmConferencia getNegocioArtigoEmConferencia() {
		return negocioArtigoEmConferencia;
	}

	public void setNegocioArtigoEmConferencia(
			NegocioArtigoEmConferencia negocioArtigoEmConferencia) {
		this.negocioArtigoEmConferencia = negocioArtigoEmConferencia;
	}

	public NegocioArtigoEmPeriodicoERevista getNegocioArtigoEmPeriodicoERevista() {
		return negocioArtigoEmPeriodicoERevista;
	}

	public void setNegocioArtigoEmPeriodicoERevista(
			NegocioArtigoEmPeriodicoERevista negocioArtigoEmPeriodicoERevista) {
		this.negocioArtigoEmPeriodicoERevista = negocioArtigoEmPeriodicoERevista;
	}

	public NegocioDissertacaoDeMestrado getNegocioDissertacaoDeMestrado() {
		return negocioDissertacaoDeMestrado;
	}

	public void setNegocioDissertacaoDeMestrado(
			NegocioDissertacaoDeMestrado negocioDissertacaoDeMestrado) {
		this.negocioDissertacaoDeMestrado = negocioDissertacaoDeMestrado;
	}

	public NegocioTeseDeDoutorado getNegocioTeseDeDoutorado() {
		return negocioTeseDeDoutorado;
	}

	public void setNegocioTeseDeDoutorado(
			NegocioTeseDeDoutorado negocioTeseDeDoutorado) {
		this.negocioTeseDeDoutorado = negocioTeseDeDoutorado;
	}

	public NegocioMembro getNegocioMembro() {
		return negocioMembro;
	}

	public void setNegocioMembro(NegocioMembro negocioMembro) {
		this.negocioMembro = negocioMembro;
	}

	/*
	 * FIM => GETS AND SETS
	 */
	/*
	 * NEGOCIOMEMBRO
	 */

	public Membro buscaMembroLogin(String loginMembro) throws SQLException,
			ClassNotFoundException, IOException {
		Membro retorno = this.negocioMembro.buscaMembroLogin(loginMembro);

		return retorno;
	}

	public Membro buscaMembro(String nomeMembro) throws SQLException,
			ClassNotFoundException, IOException {

		Membro retorno = this.negocioMembro.buscaMembro(nomeMembro);

		return retorno;
	}

	public Vector<String> retornaPublicacoesDeUmMembro(String nomeMembro)
			throws SQLException, ClassNotFoundException {
		Vector<String> retorno = this.negocioMembro
				.retornaPublicacoes(nomeMembro);

		return retorno;
	}

	public Vector<String> retornaLinhasDeUmMembro(String nomeMembro)
			throws SQLException, ClassNotFoundException {
		Vector<String> retorno = this.negocioMembro.retornaLinhas(nomeMembro);

		return retorno;
	}

	public Vector<Membro> retornaTodosMembros() throws SQLException,
			ClassNotFoundException {
		Vector<Membro> retorno = this.negocioMembro.retornaTodosMembros();

		return retorno;
	}

	public boolean autenticarMembro(String login, String senha)
			throws SQLException, ClassNotFoundException {
		return this.negocioMembro.autenticarMembro(login, senha);
	}

	public void inserirMembro(Membro x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			MembroJaExistenteException, IOException {

		this.negocioMembro.inserirMembro(x);
	}

	public Vector<Membro> procurarMembroLike(String nomeMembro)
			throws SQLException, ClassNotFoundException,
			ParametroVazioException, MembroNaoEncontradoException {
		return this.negocioMembro.procurarMembroLike(nomeMembro);
	}

	public void removerMembro(Membro x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, MembroNaoEncontradoException {
		this.negocioMembro.removerMembro(x);
	}

	public void editarMembro(Membro x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, MembroNaoEncontradoException, IOException {
		this.negocioMembro.editarMembro(x);
	}

	/*
	 * NEGOCIOARTIGOEMCONFERENCIA
	 */

	// LINHASDEPESQUISA
	public Vector<String> retornaLinhasDeUmaPublicacao(String tituloPub)
			throws SQLException, ClassNotFoundException {
		return this.negocioArtigoEmConferencia
				.retornaLinhasDeUmaPublicacao(tituloPub);
	}

	// LINHASDEPESQUISA

	public Vector<String> buscaPublicacaoPorMembro(Vector<String> autores)
			throws SQLException, ClassNotFoundException {
		return this.negocioArtigoEmConferencia
				.buscaPublicacaoPorMembro(autores);
	}

	public ArtigoEmConferencia buscaArtigoEmConferencia(String tituloArtigo)
			throws SQLException, ClassNotFoundException, IOException {
		ArtigoEmConferencia retorno = this.negocioArtigoEmConferencia
				.buscaArtigoEmConferencia(tituloArtigo);

		return retorno;
	}

	public Vector<String> retornaMembrosDeUmaPublicacao(String tituloPub)
			throws SQLException, ClassNotFoundException {

		Vector<String> retorno = this.negocioArtigoEmConferencia
				.retornaMembrosDeUmaPublicacao(tituloPub);

		return retorno;
	}

	public String retornaTipoPublicacao(String tituloPub) throws SQLException,
			ClassNotFoundException {
		String retorno = this.negocioArtigoEmConferencia
				.retornaTipoPublicacao(tituloPub);

		return retorno;
	}

	public Vector<ArtigoEmConferencia> retornaTodasPublicacoes()
			throws SQLException, ClassNotFoundException {

		return this.negocioArtigoEmConferencia.retornaTodasPublicacoes();
	}

	public void inserirArtigoEmConferencia(ArtigoEmConferencia x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {
		this.negocioArtigoEmConferencia.inserirArtigoEmConferencia(x);
	}

	public Vector<ArtigoEmConferencia> procurarArtigoLike(String tituloPub)
			throws SQLException, ClassNotFoundException {
		return this.negocioArtigoEmConferencia.procurarArtigoLike(tituloPub);
	}

	public void removerArtigoEmConferencia(ArtigoEmConferencia x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		this.negocioArtigoEmConferencia.removerArtigoEmConferencia(x);
	}

	public void editarArtigoEmConferencia(ArtigoEmConferencia x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException,
			IOException {
		this.negocioArtigoEmConferencia.editarArtigoEmConferencia(x);
	}

	/*
	 * NEGOCIOARTIGOEMPERIODICOEREVISTA
	 */

	public ArtigoEmPeriodicoERevista buscaArtigoEmPeriodicoRevista(
			String tituloArtigo) throws SQLException, ClassNotFoundException,
			IOException {

		ArtigoEmPeriodicoERevista retorno = this.negocioArtigoEmPeriodicoERevista
				.buscaArtigoEmPeriodicoRevista(tituloArtigo);

		return retorno;
	}

	public void inserirArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {

		this.negocioArtigoEmPeriodicoERevista
				.inserirArtigoEmPeriodicoERevista(x);
	}

	public Vector procurarArtigoEmPeriodicoERevista(
			String tituloArtigoEmPeriodicoERevista) throws SQLException,
			ClassNotFoundException, ParametroVazioException,
			PublicacaoNaoEncontradaException {
		return this.negocioArtigoEmPeriodicoERevista
				.procurarArtigoEmPeriodicoERevista(tituloArtigoEmPeriodicoERevista);
	}

	public void removerArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		this.negocioArtigoEmPeriodicoERevista
				.removerArtigoEmPeriodicoERevista(x);
	}

	public void editarArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException,
			IOException {
		this.negocioArtigoEmPeriodicoERevista
				.editarArtigoEmPeriodicoERevista(x);
	}

	/*
	 * NEGOCIOARTIGOEMPERIODICOEREVISTA
	 */

	/*
	 * NEGOCIODISSERTACAODEMESTRADO
	 */
	public DissertacaoDeMestrado buscaDissertacaoDeMestrado(String tituloArtigo)
			throws SQLException, ClassNotFoundException, IOException {
		DissertacaoDeMestrado retorno = this.negocioDissertacaoDeMestrado
				.buscaDissertacaoDeMestrado(tituloArtigo);

		return retorno;
	}

	public void inserirDissertacaoDeMestrado(DissertacaoDeMestrado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {
		this.negocioDissertacaoDeMestrado.inserirDissertacaoDeMestrado(x);
	}

	public Vector procurarDissertacaoDeMestrado(
			String tituloDissertacaoDeMestrado) throws SQLException,
			ClassNotFoundException, ParametroVazioException,
			PublicacaoNaoEncontradaException {
		return this.negocioDissertacaoDeMestrado
				.procurarDissertacaoDeMestrado(tituloDissertacaoDeMestrado);
	}

	public void removerDissertacaoDeMestrado(DissertacaoDeMestrado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		this.negocioDissertacaoDeMestrado.removerDissertacaoDeMestrado(x);
	}

	public void editarDissertacaoDeMestrado(DissertacaoDeMestrado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException,
			IOException {
		this.negocioDissertacaoDeMestrado.editarDissertacaoDeMestrado(x);
	}

	/*
	 * NEGOCIOTESEDEDOUTORADO
	 */
	public TeseDeDoutorado buscaTeseDeDoutorado(String tituloTese)
			throws SQLException, ClassNotFoundException, IOException {
		TeseDeDoutorado retorno = this.negocioTeseDeDoutorado
				.buscaTeseDeDoutorado(tituloTese);

		return retorno;
	}

	public void inserirTeseDeDoutorado(TeseDeDoutorado x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {
		this.negocioTeseDeDoutorado.inserirTeseDeDoutorado(x);
	}

	public Vector procurarTeseDeDoutorado(String tituloTeseDeDoutorado)
			throws SQLException, ClassNotFoundException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		return this.negocioTeseDeDoutorado
				.procurarTeseDeDoutorado(tituloTeseDeDoutorado);
	}

	public void removerTeseDeDoutorado(TeseDeDoutorado x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		this.negocioTeseDeDoutorado.removerTeseDeDoutorado(x);
	}

	public void editarTeseDeDoutorado(TeseDeDoutorado x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException,
			IOException {
		this.negocioTeseDeDoutorado.editarTeseDeDoutorado(x);
	}

	/*
	 * NEGOCIOLINHADEPESQUISA
	 */

	public Vector<String> retornaMembrosDeUmaLinha(String nomeLinha)
			throws SQLException, ClassNotFoundException {
		Vector<String> retorno = this.negocioLinha
				.retornaMembrosDeUmaLinha(nomeLinha);

		return retorno;
	}

	public Vector<String> retornaPublicacoesDeUmaLinha(String nomeLinha)
			throws SQLException, ClassNotFoundException {
		Vector<String> retorno = this.negocioLinha
				.retornaPublicacoesDeUmaLinha(nomeLinha);

		return retorno;
	}

	public Vector<String> retornaTodasLinhasDePesquisa() throws SQLException,
			ClassNotFoundException {
		Vector<String> retorno = this.negocioLinha
				.retornaTodasLinhasDePesquisa();

		return retorno;
	}

	public void inserirLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			LinhaDePesquisaJaExistenteException, IOException {
		this.negocioLinha.inserirLinhaDePesquisa(x);
	}

	public Vector<LinhaDePesquisa> procurarLinhaDePesquisaLike(String nomeLinha)
			throws SQLException, ClassNotFoundException {
		return this.negocioLinha.procurarLinhaDePesquisaLike(nomeLinha);
	}

	public void removerLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, LinhaDePesquisaNaoEncontradaException {
		this.negocioLinha.removerLinhaDePesquisa(x);
	}

	public void editarLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, LinhaDePesquisaNaoEncontradaException {
		this.negocioLinha.editarLinhaDePesquisa(x);
	}

	public LinhaDePesquisa buscaLinhaDePesquisa(String tituloLinha)
			throws SQLException, ClassNotFoundException {
		LinhaDePesquisa retorno = this.negocioLinha
				.buscaLinhaDePesquisa(tituloLinha);

		return retorno;
	}
	
	public Vector<String> buscaLinhaPorMembro(Vector<String> autores) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.negocioLinha.buscaLinhaPorMembro(autores);
		return retorno;
	}

}