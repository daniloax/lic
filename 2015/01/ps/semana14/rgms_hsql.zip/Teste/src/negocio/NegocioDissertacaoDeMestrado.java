package negocio;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import base.DissertacaoDeMestrado;

import repositorio.RepositorioDissertacaoDeMestrado;

import excecoes.*;

public class NegocioDissertacaoDeMestrado {

	public RepositorioDissertacaoDeMestrado repDisMes;

	public NegocioDissertacaoDeMestrado() {
		this.repDisMes = new RepositorioDissertacaoDeMestrado();
	}
	public DissertacaoDeMestrado buscaDissertacaoDeMestrado(String tituloArtigo) throws SQLException, ClassNotFoundException, IOException{
		DissertacaoDeMestrado retorno = this.repDisMes.buscaDissertacaoDeMestrado(tituloArtigo);
		
		return retorno;
	}
	public void inserirDissertacaoDeMestrado(DissertacaoDeMestrado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {

		if (!(x == null)) {

			boolean achou = this.repDisMes.autenticaArtigo(x.getTitulo());
			if(!achou){
				this.repDisMes.inserirDissertacaoDeMestrado(x);
			}else{
				throw new PublicacaoJaExistenteException();
			}
			

		} else {

			throw new ObjetoVazioException();
		}
	}// fim do m�todo inserirArtigoEmConferencia.

	public Vector procurarDissertacaoDeMestrado(String tituloDissertacao)
			throws SQLException, ClassNotFoundException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		Vector retorno = new Vector();
		if (tituloDissertacao != null) {
			retorno = this.repDisMes
					.procurarDissertacaoDeMestradoLike(tituloDissertacao);
			if (retorno.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			}
		} else {
			throw new ParametroVazioException();
		}
		return retorno;
	} // fim do m�todo procurarArtigoEmConferencia.

	public void removerDissertacaoDeMestrado(DissertacaoDeMestrado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		if (x != null) {
			Vector controle = this.procurarDissertacaoDeMestrado(x.getTitulo());
			if (controle.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			} else {
				this.repDisMes.removerDissertacaoDeMestrado(x);
			}
		} else {
			throw new ObjetoVazioException();

		}
	}

	public void editarDissertacaoDeMestrado(DissertacaoDeMestrado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException, IOException {

		
				this.repDisMes.editarDissertacaoDeMestrado(x);
			}


	

}
