package negocio;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import repositorio.RepositorioLinhaDePesquisa;
import repositorio.RepositorioMembro;
import base.LinhaDePesquisa;
import base.Membro;
import excecoes.*;

public class NegocioLinhaDePesquisa {

	public RepositorioLinhaDePesquisa repLinhaPesq;

	public NegocioLinhaDePesquisa() {
		this.repLinhaPesq = new RepositorioLinhaDePesquisa();
	}

	public Vector retornaTodasPublicacoes() throws SQLException,
			ClassNotFoundException {

		Vector retorno = this.repLinhaPesq.retornaTodasLinhasDePesquisa();

		return retorno;
	}

	public void inserirLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			LinhaDePesquisaJaExistenteException, IOException {

		if (!(x == null)) {

			boolean achou = this.repLinhaPesq.autenticaLinhaDePesquisa(x.getTitulo());
			if (!achou) {
				this.repLinhaPesq.inserirLinhaDePesquisa(x);
			} else {
				throw new LinhaDePesquisaJaExistenteException();
			}

		} else {

			throw new ObjetoVazioException();

		}

	}// fim do metodo inserirLinhaDePesquisa.

	public Vector<LinhaDePesquisa> procurarLinhaDePesquisaLike(String nomeLinha) throws SQLException, ClassNotFoundException{
		return this.repLinhaPesq.procurarLinhaDePesquisaLike(nomeLinha);
	}

	public void removerLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, LinhaDePesquisaNaoEncontradaException {
		if (x != null) {
			Vector controle = new Vector();
			if (controle.size() == 0) {
				throw new LinhaDePesquisaNaoEncontradaException();
			} else {
				this.repLinhaPesq.removerLinhaDePesquisa(x);
			}
		} else {
			throw new ObjetoVazioException();

		}
	}

	public void editarLinhaDePesquisa(LinhaDePesquisa x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, LinhaDePesquisaNaoEncontradaException {

		
				this.repLinhaPesq.editarLinhaDePesquisa(x);

	}
	public Vector<String> retornaTodasLinhasDePesquisa() throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.repLinhaPesq.retornaTodasLinhasDePesquisa();
		return retorno;
	}
	
	public LinhaDePesquisa buscaLinhaDePesquisa(String tituloLinha) throws SQLException, ClassNotFoundException {
		LinhaDePesquisa retorno = this.repLinhaPesq.buscaLinhaDePesquisa(tituloLinha);
		
		return retorno;
	}
	
	public Vector<String> retornaMembrosDeUmaLinha(String nomeLinha) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.repLinhaPesq.retornaMembrosDeUmaLinha(nomeLinha);
		
		return retorno;
	}
	
	public Vector<String> retornaPublicacoesDeUmaLinha(String nomeLinha) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.repLinhaPesq.retornaPublicacoesDeUmaLinha(nomeLinha);
		return retorno;
	}
	
	public Vector<String> buscaLinhaPorMembro(Vector<String> autores) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.repLinhaPesq.buscaLinhaPorMembro(autores);
		
		return retorno;
	}

}