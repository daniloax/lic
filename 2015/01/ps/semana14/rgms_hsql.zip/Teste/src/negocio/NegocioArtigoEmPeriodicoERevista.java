package negocio;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JOptionPane;

import repositorio.RepositorioArtigoEmConferencia;
import repositorio.RepositorioArtigoEmPeriodicoERevista;
import repositorio.RepositorioMembro;
import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.Membro;
import excecoes.*;
import gui.PainelCadastroArtigoPeriodicoRevista;
import gui.PainelPublicacoes;

public class NegocioArtigoEmPeriodicoERevista {

	public RepositorioArtigoEmPeriodicoERevista repArtEmPerERev;

	public NegocioArtigoEmPeriodicoERevista() {
		this.repArtEmPerERev = new RepositorioArtigoEmPeriodicoERevista();
	}
	public ArtigoEmPeriodicoERevista buscaArtigoEmPeriodicoRevista (String tituloArtigo) throws SQLException, ClassNotFoundException, IOException{
		
		ArtigoEmPeriodicoERevista retorno = this.repArtEmPerERev.buscaArtigoEmPeriodicoRevista(tituloArtigo);
		
		return retorno;
	}
	public void inserirArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {

		if (!(x == null)) {

			boolean achou = this.repArtEmPerERev.autenticaArtigo(x.getTitulo());
			if(!achou){
				this.repArtEmPerERev.inserirArtigoEmPeriodicoERevista(x);
			}else{
				JOptionPane.showMessageDialog(null,
						"Esse artigo nao p�de ser cadastrado porque j� existe um artigo com este nome!", "Aten��o",
						JOptionPane.ERROR_MESSAGE);
				throw new PublicacaoJaExistenteException();
				
				
				
			}
			

		} else {

			throw new ObjetoVazioException();

		}
	}// fim do m�todo inserirArtigoEmConferencia.

	public Vector procurarArtigoEmPeriodicoERevista(String tituloArtigo)
			throws SQLException, ClassNotFoundException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		Vector retorno = new Vector();
		if (tituloArtigo != null) {
			retorno = this.repArtEmPerERev
					.procurarArtigoEmPeriodicoERevista(tituloArtigo);
			if (retorno.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			}
		} else {
			throw new ParametroVazioException();
		}
		return retorno;
	} // fim do m�todo procurarArtigoEmConferencia.

	public void removerArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		if (x != null) {
			Vector controle = this.procurarArtigoEmPeriodicoERevista(x
					.getTitulo());
			if (controle.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			} else {
				this.repArtEmPerERev.removerArtigoEmPeriodicoERevista(x);
			}
		} else {
			throw new ObjetoVazioException();

		}
	}

	public void editarArtigoEmPeriodicoERevista(ArtigoEmPeriodicoERevista x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException, IOException {

		
				this.repArtEmPerERev.editarArtigoEmPeriodicoERevista(x);
		

	}

}
