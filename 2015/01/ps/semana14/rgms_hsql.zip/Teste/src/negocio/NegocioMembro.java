package negocio;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import repositorio.RepositorioMembro;
import base.Membro;
import excecoes.*;

public class NegocioMembro {

	public RepositorioMembro repMembro;

	public NegocioMembro() {
		this.repMembro = new RepositorioMembro();
	}
	
	public Vector<Membro> retornaTodosMembros() throws SQLException, ClassNotFoundException{
		Vector<Membro> retorno = new Vector();
		
		retorno = this.repMembro.retornaTodosMembros();
		return retorno;
	}
	public void inserirMembro(Membro x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			MembroJaExistenteException, IOException {

		if (!(x == null)) {

			Vector result = this.repMembro.procurarMembroLike(x.getNome());
			boolean achou = false;
			Iterator it = result.iterator();
			while (it.hasNext() && achou == false) {
				Membro temp = (Membro)it.next();
				if (x.getLogin().equals(temp.getLogin())) {
					achou = true;
					throw new MembroJaExistenteException();
				}
			}
			if (achou == false) {
				this.repMembro.inserirMembro(x);
			}

		} else {

			throw new ObjetoVazioException();

		}

	}// fim do m�todo inserirMembro.

	public Vector<Membro> procurarMembroLike(String nomeMembro) throws SQLException,
			ClassNotFoundException, ParametroVazioException,
			MembroNaoEncontradoException {
		Vector<Membro> retorno = new Vector();
		if (nomeMembro != null) {
			retorno = this.repMembro.procurarMembroLike(nomeMembro);
			if (retorno.size() == 0) {
				throw new MembroNaoEncontradoException();
			}
		} else {
			throw new ParametroVazioException();
		}
		return retorno;
	} // fim do m�todo procurarMembro.

	public void removerMembro(Membro x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, MembroNaoEncontradoException {
		if (x != null) {
			Vector controle = this.procurarMembroLike("" + x.getNome());
			if (controle.size() == 0) {
				throw new MembroNaoEncontradoException();
			} else {
				this.repMembro.removerMembro(x);
			}
		} else {
			throw new ObjetoVazioException();

		}
	}

	public void editarMembro(Membro x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, MembroNaoEncontradoException, IOException {

		if (x != null) {
			
				this.repMembro.editarMembro(x);
			}
		

	}
	
	public boolean autenticarMembro (String login, String senha) throws SQLException, ClassNotFoundException{
		
		boolean resultado = this.repMembro.autenticarMembro(login, senha);
		
		return resultado;
	}
	
	public Membro buscaMembro(String nomeMembro) throws SQLException, ClassNotFoundException, IOException{
		
		Membro retorno = this.repMembro.buscaMembro(nomeMembro);
		
		return retorno;
	}
	public Membro buscaMembroLogin(String loginMembro) throws SQLException, ClassNotFoundException, IOException{
		Membro retorno = this.repMembro.buscaMembroLogin(loginMembro);
		
		return retorno;
	}
	public Vector<String> retornaPublicacoes(String nomeMembro) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.repMembro.retornaPublicacoes(nomeMembro);
		
		return retorno;
	}
	
	public Vector<String> retornaLinhas(String nomeMembro) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = this.repMembro.retornaLinhas(nomeMembro);
		
		return retorno;
	}
	public int buscaIdMembro(String loginMembro) throws SQLException, ClassNotFoundException{
		int retorno = this.repMembro.buscaIdMembro(loginMembro);
		
		return retorno;
	}
}
