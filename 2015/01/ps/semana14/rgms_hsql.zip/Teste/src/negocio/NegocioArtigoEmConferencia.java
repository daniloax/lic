package negocio;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import repositorio.RepositorioArtigoEmConferencia;
import repositorio.RepositorioMembro;
import base.ArtigoEmConferencia;
import base.Membro;
import excecoes.*;

public class NegocioArtigoEmConferencia {

	public RepositorioArtigoEmConferencia repArtEmConf;

	public NegocioArtigoEmConferencia() {
		this.repArtEmConf = new RepositorioArtigoEmConferencia();
	}
	
	public Vector<String> retornaMembrosDeUmaPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		
		Vector<String> retorno = this.repArtEmConf.retornaMembrosDeUmaPublicacao(tituloPub);
		
		return retorno;
		
	}
	
	public String retornaTipoPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		
		String retorno = this.repArtEmConf.retornaTipoPublicacao(tituloPub);
		
		return retorno;
	}
	
	public Vector<ArtigoEmConferencia> retornaTodasPublicacoes() throws SQLException, ClassNotFoundException{
		
		Vector<ArtigoEmConferencia> retorno = this.repArtEmConf.retornaTodasPublicacoes();
		
		return retorno;
	}
	public void inserirArtigoEmConferencia(ArtigoEmConferencia x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {

		if (!(x == null)) {

			boolean achou = this.repArtEmConf.autenticaArtigo(x.getTitulo());
			if(!achou){
				this.repArtEmConf.inserirArtigoEmConferencia(x);
			}else{
				throw new PublicacaoJaExistenteException();
			}
			

		} else {

			throw new ObjetoVazioException();

		}

	}// fim do m�todo inserirArtigoEmConferencia.

	
	
	public ArtigoEmConferencia buscaArtigoEmConferencia(String tituloArtigo) throws SQLException, ClassNotFoundException, IOException{
		
		ArtigoEmConferencia retorno = this.repArtEmConf.buscaArtigoEmConferencia(tituloArtigo);
		
		return retorno;
	}
	public void removerArtigoEmConferencia(ArtigoEmConferencia x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		if (x != null) {
			Vector controle = new Vector();
			//this.procurarArtigoEmConferenciaLike(x.getTitulo());
			if (controle.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			} else {
				this.repArtEmConf.removerArtigoEmConferencia(x);
			}
		} else {
			throw new ObjetoVazioException();

		}
	}

	public void editarArtigoEmConferencia(ArtigoEmConferencia x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException, IOException {

		
				this.repArtEmConf.editarArtigoEmConferencia(x);
	}

	public Vector<ArtigoEmConferencia> procurarArtigoLike(String tituloPub) throws SQLException, ClassNotFoundException{
		return this.repArtEmConf.procurarArtigoLike(tituloPub);
	}
	
	public Vector<String> buscaPublicacaoPorMembro(Vector<String> autores) throws SQLException, ClassNotFoundException{
		Vector<String> retorno = new Vector();
		Vector<String> duplicado = this.repArtEmConf.buscaPublicacaoPorMembro(autores);
		Iterator<String> it = duplicado.iterator();
		while(it.hasNext()){
			String titulo = it.next();
			if(!(retorno.contains(titulo))){
				retorno.add(titulo);
			}
		}
		return retorno;
	}
	
	//LINHASDEPESQUISA
	public Vector<String> retornaLinhasDeUmaPublicacao(String tituloPub) throws SQLException, ClassNotFoundException{
		return this.repArtEmConf.retornaLinhasDeUmaPublicacao(tituloPub);
	}
	//LINHASDEPESQUISA
}
