package negocio;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import base.TeseDeDoutorado;

import repositorio.RepositorioTeseDeDoutorado;

import excecoes.*;

public class NegocioTeseDeDoutorado {

	public RepositorioTeseDeDoutorado repTesDout;

	public NegocioTeseDeDoutorado() {
		this.repTesDout = new RepositorioTeseDeDoutorado();
	}
	public TeseDeDoutorado buscaTeseDeDoutorado (String tituloTese) throws SQLException, ClassNotFoundException, IOException{
		TeseDeDoutorado retorno = this.repTesDout.buscaTeseDeDoutorado(tituloTese);
		
		return retorno;
	}
	public void inserirTeseDeDoutorado(TeseDeDoutorado x) throws SQLException,
			ClassNotFoundException, ObjetoVazioException,
			PublicacaoJaExistenteException, IOException {

		if (!(x == null)) {

			boolean achou = this.repTesDout.autenticaArtigo(x.getTitulo());
			if(!achou){
				this.repTesDout.inserirTeseDeDoutorado(x);
			}else{
				throw new PublicacaoJaExistenteException();
			}
			

		} else {

			throw new ObjetoVazioException();
		}

	}// fim do m�todo inserirArtigoEmConferencia.

	public Vector procurarTeseDeDoutorado(String tituloTese)
			throws SQLException, ClassNotFoundException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		Vector retorno = new Vector();
		if (tituloTese != null) {
			retorno = this.repTesDout.procurarTeseDeDoutoradoLike(tituloTese);
			if (retorno.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			}
		} else {
			throw new ParametroVazioException();
		}
		return retorno;
	} // fim do m�todo procurarArtigoEmConferencia.

	public void removerTeseDeDoutorado(TeseDeDoutorado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException {
		if (x != null) {
			Vector controle = this.procurarTeseDeDoutorado(x.getTitulo());
			if (controle.size() == 0) {
				throw new PublicacaoNaoEncontradaException();
			} else {
				this.repTesDout.removerTeseDeDoutorado(x);
			}
		} else {
			throw new ObjetoVazioException();

		}
	}

	public void editarTeseDeDoutorado(TeseDeDoutorado x)
			throws SQLException, ClassNotFoundException, ObjetoVazioException,
			ParametroVazioException, PublicacaoNaoEncontradaException, IOException {

		
				this.repTesDout.editarTeseDeDoutorado(x);
		

	}

}
