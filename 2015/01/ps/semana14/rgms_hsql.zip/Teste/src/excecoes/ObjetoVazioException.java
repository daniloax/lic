package excecoes;

public class ObjetoVazioException extends Exception{
	private static final long serialVersionUID = 1L;
	public ObjetoVazioException() {
		super("O objeto passado est� vazio.");
	}
}
