package excecoes;

public class PublicacaoJaExistenteException extends Exception{

	private static final long serialVersionUID = 1L;

	public PublicacaoJaExistenteException() {
		super("O membro j� existe.");
	}

}
