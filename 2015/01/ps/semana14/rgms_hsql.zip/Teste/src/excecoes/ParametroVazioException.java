package excecoes;

public class ParametroVazioException extends Exception{
	private static final long serialVersionUID = 1L;
	public ParametroVazioException() {
		super("O par�metro passado est� vazio.");
	}
}