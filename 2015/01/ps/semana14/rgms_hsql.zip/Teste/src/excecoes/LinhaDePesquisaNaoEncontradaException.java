package excecoes;

public class LinhaDePesquisaNaoEncontradaException extends Exception {
	private static final long serialVersionUID = 1L;

	public LinhaDePesquisaNaoEncontradaException() {
		super("A linha de pesquisa n�o foi encontrada.");
	}
}
