package excecoes;

public class LinhaDePesquisaJaExistenteException extends Exception {

	private static final long serialVersionUID = 1L;

	public LinhaDePesquisaJaExistenteException() {
		super("A linha de pesquisa j� existe.");
	}
}
