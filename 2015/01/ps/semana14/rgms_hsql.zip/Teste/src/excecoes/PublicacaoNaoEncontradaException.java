package excecoes;

public class PublicacaoNaoEncontradaException extends Exception{
	private static final long serialVersionUID = 1L;
	public PublicacaoNaoEncontradaException() {
		super("A publicacao n�o existe.");
	}
}
