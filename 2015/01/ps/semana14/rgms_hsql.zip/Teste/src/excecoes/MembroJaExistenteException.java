package excecoes;

public class MembroJaExistenteException extends Exception {

	private static final long serialVersionUID = 1L;

	public MembroJaExistenteException() {
		super("O membro j� existe.");
	}
}
