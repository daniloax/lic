package excecoes;

public class MembroNaoEncontradoException extends Exception{
	private static final long serialVersionUID = 1L;
	public MembroNaoEncontradoException () {
		super("O membro n�o foi encontrado.");
	}
}
