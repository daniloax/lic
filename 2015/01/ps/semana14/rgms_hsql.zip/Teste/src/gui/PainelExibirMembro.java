package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.Membro;
import base.TeseDeDoutorado;

import java.lang.String;
import javax.swing.JPasswordField;
import java.awt.Point;
import javax.swing.JToolBar;

public class PainelExibirMembro extends JPanel {

	private Membro membro ; // @jve:decl-index=0:

	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;
	private JScrollPane scrollBusca = null;
	private JLabel labelTitulo1 = null;
	private JLabel labelAno = null;
	private JLabel labelAno2 = null;
	private JTextField exibirNome = null;
	private JTextField exibirTipo = null;
	private JTextField departamento = null;
	private JTextField exibirEmail = null;
	private Vector<String> todasPublicacoes;
	private JLabel labelTelefone = null;

	private JTextField exibirTelefone = null;

	private JLabel labelSite = null;

	private JTextField exibirSite = null;

	private JLabel labelCidade = null;

	private JTextField exibirCidade = null;

	private JLabel labelPais = null;

	private JTextField exibirPais = null;

	private JLabel labelStatus = null;

	private JTextField exibirStatus = null;

	private JLabel labelLogin = null;

	private JTextField exibirLogin = null;

	private JLabel labelFoto = null;

	private JToolBar jToolBarPaginaInicial = null;

	private JButton jButtonVoltarInicial = null;

	private JLabel labelSite1 = null;

	private JList jListPublicacoes = null;

	private JLabel labelAno1 = null;

	

	private JTextField jTextFieldUniversidade = null;
	
	//LINHASDEPESQUISA
	private JLabel labelSite11 = null;

	private JList jListLinhas = null;
	
	private JScrollPane scrollLinhas = null;
	//LINHASDEPESQUISA

	/**
	 * This is the default constructor
	 */
	public PainelExibirMembro(FramePrincipal frame, Membro m) {
		super();
		this.frame = frame;
		this.membro = m;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		labelSite11 = new JLabel();
		labelSite11.setBounds(new Rectangle(18, 450, 118, 19));
		labelSite11.setText("Linhas de Pesquisa:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(189, 108, 82, 19));
		labelAno1.setText("Universidade:");
		labelSite1 = new JLabel();
		labelSite1.setBounds(new Rectangle(18, 351, 82, 19));
		labelSite1.setText("Publica��es:");
		labelFoto = new JLabel();
		labelFoto.setText("JLabel");
		labelFoto.setSize(new Dimension(127, 142));
		labelFoto.setLocation(new Point(18, 54));
		labelFoto.setIcon(this.membro.getFoto());
		labelLogin = new JLabel();
		labelLogin.setBounds(new Rectangle(288, 261, 50, 20));
		labelLogin.setText("  Login:");
		labelStatus = new JLabel();
		labelStatus.setBounds(new Rectangle(18, 261, 53, 20));
		labelStatus.setText(" Status:");
		labelPais = new JLabel();
		labelPais.setBounds(new Rectangle(468, 261, 45, 20));
		labelPais.setText(" Pa�s:");
		labelCidade = new JLabel();
		labelCidade.setBounds(new Rectangle(288, 306, 53, 19));
		labelCidade.setText(" Cidade:");
		labelSite = new JLabel();
		labelSite.setBounds(new Rectangle(18, 306, 59, 20));
		labelSite.setText(" Website:");
		labelTelefone = new JLabel();
		labelTelefone.setBounds(new Rectangle(468, 216, 58, 18));
		labelTelefone.setText(" Telefone:");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 216, 44, 19));
		labelAno2.setText(" E-mail:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(189, 162, 90, 19));
		labelAno.setText(" Departamento: ");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(468, 306, 36, 19));
		labelTitulo1.setText(" Tipo:");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(189, 54, 45, 19));
		labelTitulo.setText(" Nome:");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 125, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Perfil do membro");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelTitulo1, null);
		this.add(labelAno, null);
		this.add(labelAno2, null);

		this.add(getExibirNome(), null);
		this.add(getExibirTipo(), null);
		this.add(getExibirDepartamento(), null);
		this.add(getEmail(), null);
		this.add(labelTelefone, null);
		this.add(getExibirTelefone(), null);
		this.add(labelSite, null);
		this.add(getExibirSite(), null);
		this.add(labelCidade, null);
		this.add(getExibirCidade(), null);
		this.add(labelPais, null);
		this.add(getExibirPais(), null);
		this.add(labelStatus, null);
		this.add(getExibirStatus(), null);
		this.add(labelLogin, null);
		this.add(getExibirLogin(), null);
		this.add(labelFoto, null);
		this.add(getJToolBarPaginaInicial(), null);
		this.add(labelSite1, null);
		this.add(getJListPublicacoes(), null);
		this.scrollBusca = new JScrollPane(this.jListPublicacoes);
		this.scrollBusca.setBounds(new Rectangle(18, 369, 370, 73));
		this.scrollBusca.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollBusca.setVisible(true);
		this.add(scrollBusca);
		this.add(labelAno1, null);
		this.add(getJTextFieldUniversidade(), null);
		this.add(labelSite11, null);
		//LINHASDEPESQUISA
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 468, 370, 73));
		this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		//LINHASDEPESQUISA
	}

	public void carregaPdf() {

		// incluir trecho de c�digo para abrir pdf com visualizar padr�o em java
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirNome() {
		if (exibirNome == null) {
			exibirNome = new JTextField();
			exibirNome.setBounds(new Rectangle(189, 81, 440, 19));
			// preenche com o valor
			String titulo = this.membro.getNome();
			exibirNome.setText(titulo);
			exibirNome.setEnabled(false);
		}
		return exibirNome;
	}

	/**
	 * This method initializes exibirInstituicao
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTipo() {
		if (exibirTipo == null) {
			exibirTipo = new JTextField();
			exibirTipo.setBounds(new Rectangle(468, 324, 209, 20));
			// preenche com o valor
			String instituicao = this.membro.getTipo();
			exibirTipo.setText(instituicao);
			exibirTipo.setEnabled(false);

		}
		return exibirTipo;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirDepartamento() {
		if (departamento == null) {
			departamento = new JTextField();
			departamento.setBounds(new Rectangle(189, 189, 342, 20));
			// preenche com o valor
			String ano = this.membro.getDpto_univ();
			departamento.setText(ano);
			departamento.setEnabled(false);
		}
		return departamento;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getEmail() {
		if (exibirEmail == null) {
			exibirEmail = new JTextField();
			exibirEmail.setBounds(new Rectangle(18, 234, 386, 20));
			// preencher com o valor
			String autor = this.membro.getEmail();
			exibirEmail.setText(autor);
			exibirEmail.setEnabled(false);
		}
		return exibirEmail;
	}

	/**
	 * This method initializes exibirTelefone
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTelefone() {
		if (exibirTelefone == null) {
			exibirTelefone = new JTextField();
			exibirTelefone.setBounds(new Rectangle(468, 234, 141, 20));
			exibirTelefone.setEnabled(false);
			
			// preencher com o valor
			String autor = this.membro.getTelefone();
			exibirTelefone.setText(autor);
		}
		return exibirTelefone;
	}

	/**
	 * This method initializes exibirSite
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirSite() {
		if (exibirSite == null) {
			exibirSite = new JTextField();
			exibirSite.setBounds(new Rectangle(18, 324, 208, 20));
			String x = this.membro.getWebsite();
			exibirSite.setText(x);
			exibirSite.setEnabled(false);
		}
		return exibirSite;
	}

	/**
	 * This method initializes exibirCidade
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirCidade() {
		if (exibirCidade == null) {
			exibirCidade = new JTextField();
			exibirCidade.setBounds(new Rectangle(288, 324, 142, 20));
			String x = this.membro.getCidade();
			exibirCidade.setText(x);
			exibirCidade.setEnabled(false);
		}
		return exibirCidade;
	}

	/**
	 * This method initializes exibirPais
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirPais() {
		if (exibirPais == null) {
			exibirPais = new JTextField();
			exibirPais.setBounds(new Rectangle(468, 279, 126, 20));
			String x = this.membro.getPais();
			exibirPais.setText(x);
			exibirPais.setEnabled(false);
		}
		return exibirPais;
	}

	/**
	 * This method initializes exibirStatus
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirStatus() {
		if (exibirStatus == null) {
			exibirStatus = new JTextField();
			exibirStatus.setBounds(new Rectangle(18, 279, 207, 20));
			String x = this.membro.getStatus();
			exibirStatus.setText(x);
			exibirStatus.setEnabled(false);
		}
		return exibirStatus;
	}

	/**
	 * This method initializes exibirLogin
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirLogin() {
		if (exibirLogin == null) {
			exibirLogin = new JTextField();
			exibirLogin.setBounds(new Rectangle(288, 279, 139, 20));
			String x = this.membro.getLogin();
			exibirLogin.setText(x);
			exibirLogin.setEnabled(false);
		}
		return exibirLogin;
	}

	public Membro getMembro() {
		return membro;
	}

	public void setMembro(Membro membro) {
		this.membro = membro;
	}

	/**
	 * This method initializes jToolBarPaginaInicial	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarPaginaInicial() {
		if (jToolBarPaginaInicial == null) {
			jToolBarPaginaInicial = new JToolBar();
			jToolBarPaginaInicial.setBounds(new Rectangle(621, 27, 64, 19));
			jToolBarPaginaInicial.add(getJButtonVoltarInicial());
		}
		return jToolBarPaginaInicial;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelExibirMembro.this.frame.setContentPane(new PainelMembros(PainelExibirMembro.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jListPublicacoes	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListPublicacoes() {
		if (jListPublicacoes == null) {
			DefaultListModel listaPublicacoes = new DefaultListModel();
			jListPublicacoes = new JList(listaPublicacoes);
			jListPublicacoes.setBounds(new Rectangle(18, 405, 370, 73));
			
			try {
				this.todasPublicacoes = this.frame.getFachada().retornaPublicacoesDeUmMembro(this.membro.getNome());
				Iterator<String> it = this.todasPublicacoes.iterator();
				while(it.hasNext()){
					String x = (String) it.next();
					listaPublicacoes.addElement(x);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListPublicacoes;
	}

	

	/**
	 * This method initializes jTextFieldUniversidade	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldUniversidade() {
		if (jTextFieldUniversidade == null) {
			jTextFieldUniversidade = new JTextField();
			jTextFieldUniversidade.setBounds(new Rectangle(189, 135, 343, 19));
			// preenche com o valor
			String universidade = this.membro.getUniversidade();
			jTextFieldUniversidade.setText(universidade);
			jTextFieldUniversidade.setEnabled(false);
			
		}
		return jTextFieldUniversidade;
	}
	
	//LINHASDEPESQUISA
	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			
			DefaultListModel listModelLinhas = new DefaultListModel();
			jListLinhas = new JList(listModelLinhas);
			jListLinhas.setBounds(new Rectangle(18, 495, 370, 73));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmMembro(this.membro.getNome());
				for(int i = 0 ; i < linhas.size(); i++){
					listModelLinhas.addElement(linhas.elementAt(i));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListLinhas;
	}
	//LINHASDEPESQUISA
	
}  //  @jve:decl-index=0:visual-constraint="10,10"