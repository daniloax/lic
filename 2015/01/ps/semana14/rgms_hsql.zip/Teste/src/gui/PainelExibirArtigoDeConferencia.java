package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;

import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.Membro;
import javax.swing.JToolBar;

public class PainelExibirArtigoDeConferencia extends JPanel {

	private ArtigoEmConferencia artigo; // @jve:decl-index=0:

	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;

	private JLabel labelTitulo1 = null;
	private JLabel labelAno = null;
	private JButton jButtonCarregaPdf = null;
	private JLabel labelAno1 = null;
	private JLabel labelAno11 = null;
	private JLabel labelAno2 = null;
	private JButton jButtonRemover = null;
	private JButton jButtonEditar = null;
	private JTextField exibirTitulo = null;
	private JTextField exibirConferencia = null;
	private JTextField exibirAno = null;
	private JTextField exibirMes = null;
	private JTextField exibirPaginas = null;
	private JTextField exibirAutores = null;
	private JScrollPane scrollBusca = null;
	private JLabel labelAno21 = null;

	private JList jListMembros = null;

	private JToolBar jToolBarPaginaInicial = null;

	private JButton jButtonVoltarInicial = null;
	
	//LINHASDEPESQUISA
	private JLabel jLabel1 = null;

	private JList jListLinhas = null;
	
	private JScrollPane scrollLinhas = null;
	//LINHASDEPESQUISA
	/**
	 * This is the default constructor
	 */
	public PainelExibirArtigoDeConferencia(FramePrincipal frame, ArtigoEmConferencia artigo) {
		super();
		this.frame = frame;
		this.artigo = artigo;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(18, 387, 208, 19));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelAno21 = new JLabel();
		labelAno21.setBounds(new Rectangle(18, 225, 253, 19));
		labelAno21.setText("Autores integrantes do grupo de pesquisa:");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 333, 100, 19));
		labelAno2.setText(" Demais autores:");
		labelAno11 = new JLabel();
		labelAno11.setBounds(new Rectangle(279, 171, 64, 19));
		labelAno11.setText(" P�ginas:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(135, 171, 46, 19));
		labelAno1.setText(" M�s:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(18, 171, 46, 19));
		labelAno.setText(" Ano: ");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(18, 108, 136, 19));
		labelTitulo1.setText(" Nome da confer�ncia: ");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 54, 91, 19));
		labelTitulo.setText(" Titulo Artigo: ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 137, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Detalhes do artigo");
		this.setSize(723, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelTitulo1, null);
		this.add(labelAno, null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(labelAno1, null);
		this.add(labelAno11, null);
		this.add(labelAno2, null);

		this.add(getJButtonRemover(), null);
		this.add(getJButtonEditar(), null);
		this.add(getExibirTitulo(), null);
		this.add(getExibirConferencia(), null);
		this.add(getExibirAno(), null);
		this.add(getExibirMes(), null);
		this.add(getExibirPaginas(), null);
		this.add(getExibirAutores(), null);
		this.add(labelAno21, null);
		
		this.add(getJListMembros(), null);
		this.scrollBusca = new JScrollPane(this.jListMembros);
		this.scrollBusca.setBounds(new Rectangle(18, 252, 361, 73));
		this.scrollBusca.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollBusca.setVisible(true);
		this.add(scrollBusca);
		this.add(getJToolBarPaginaInicial(), null);
		this.add(jLabel1, null);
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 414, 361, 73));
		//this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		
	}

	/**
	 * This method initializes jButtonCarregaPdf
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(468, 198, 190, 19));
			jButtonCarregaPdf.setText("Visualizar artigo em pdf");
			jButtonCarregaPdf.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							PainelExibirArtigoDeConferencia.this.carregaPdf();
						}
					});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf() {
		try {
			if(this.artigo.getPdf()!=null){
				Desktop.getDesktop().open(this.artigo.getPdf());
			}else{
				JOptionPane.showMessageDialog(null,
						"N�o existe pdf cadastrado!", "INFORMA��O",
						JOptionPane.INFORMATION_MESSAGE);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// incluir trecho de c�digo para abrir pdf com visualizar padr�o em java
	}

	/**
	 * This method initializes jButtonCadastrar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonRemover() {
		if (jButtonRemover == null) {
			jButtonRemover = new JButton();
			jButtonRemover.setBounds(new Rectangle(423, 495, 109, 28));
			jButtonRemover.setText("Remover");
			jButtonRemover
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							// chamar m�todo para remover artigo do bd
							// n�o � preciso carregar outra tela, apenas exibir
							// uma msg de confirma��o da remo��o

							JOptionPane.showMessageDialog(null,
									"Publica��o removida!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);

						}
					});
		}
		return jButtonRemover;
	}

	/**
	 * This method initializes jButtonCancelar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonEditar() {
		if (jButtonEditar == null) {
			jButtonEditar = new JButton();
			jButtonEditar.setBounds(new Rectangle(567, 495, 109, 28));
			jButtonEditar.setText("Editar");

			jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							PainelExibirArtigoDeConferencia.this.frame.setContentPane(new PainelEditarArtigoConferencia(PainelExibirArtigoDeConferencia.this.frame,PainelExibirArtigoDeConferencia.this.artigo ));
							
							// chamar tela de edi��o (tela de cadastro s� que
							// com os campos preenchidos)

						}
					});
			
		}
		return jButtonEditar;
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTitulo() {
		if (exibirTitulo == null) {
			exibirTitulo = new JTextField();
			exibirTitulo.setBounds(new Rectangle(18, 81, 609, 20));
			// preenche com o valor
			String titulo = this.artigo.getTitulo();
			exibirTitulo.setText(titulo);
			exibirTitulo.setEnabled(false);
		}
		return exibirTitulo;
	}

	/**
	 * This method initializes exibirConferencia
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirConferencia() {
		if (exibirConferencia == null) {
			exibirConferencia = new JTextField();
			exibirConferencia.setBounds(new Rectangle(18, 135, 608, 20));
			// preenche com o valor
			String conferencia = this.artigo.getConferencia();
			exibirConferencia.setText(conferencia);
			exibirConferencia.setEnabled(false);

		}
		return exibirConferencia;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAno() {
		if (exibirAno == null) {
			exibirAno = new JTextField();
			exibirAno.setBounds(new Rectangle(18, 198, 41, 20));
			// preenche com o valor
			String ano = this.artigo.getAno();
			exibirAno.setText(ano);
			exibirAno.setEnabled(false);
		}
		return exibirAno;
	}

	/**
	 * This method initializes exibirMes
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirMes() {
		if (exibirMes == null) {
			exibirMes = new JTextField();
			exibirMes.setBounds(new Rectangle(135, 198, 100, 20));
			// preenche com o valor
			String mes = this.artigo.getMes();
			exibirMes.setText(mes);
			exibirMes.setEnabled(false);
		}
		return exibirMes;
	}

	/**
	 * This method initializes exibirPaginas
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirPaginas() {
		if (exibirPaginas == null) {
			exibirPaginas = new JTextField();
			exibirPaginas.setBounds(new Rectangle(279, 198, 100, 20));
			// preenche com o valor
			String paginas = this.artigo.getPaginas();
			exibirPaginas.setText(paginas);
			exibirPaginas.setEnabled(false);
		}
		return exibirPaginas;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAutores() {
		if (exibirAutores == null) {
			exibirAutores = new JTextField();
			exibirAutores.setBounds(new Rectangle(18, 360, 605, 20));
			// preencher com o valor
			// verificar formato de inser��o dos autores no objeto
			String autores = this.artigo.getAutoresNaoMembros();
			exibirAutores.setText(autores);
			exibirAutores.setEnabled(false);
		}
		return exibirAutores;
	}

	public ArtigoEmConferencia getArtigo() {
		return artigo;
	}

	public void setArtigo(ArtigoEmConferencia artigo) {
		this.artigo = artigo;
	}

	/**
	 * This method initializes jListMembros	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListMembros() {
		if (jListMembros == null) {
			
			DefaultListModel listaMembros = new DefaultListModel();
			jListMembros = new JList(listaMembros);
			jListMembros.setBounds(new Rectangle(18, 270, 361, 73));
			try {
				Vector<String> membros = this.frame.getFachada().retornaMembrosDeUmaPublicacao(this.artigo.getTitulo());
				Iterator<String> it = membros.iterator();
				while(it.hasNext()){
					String x = it.next();
					listaMembros.addElement(x);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListMembros;
	}

	/**
	 * This method initializes jToolBarPaginaInicial	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarPaginaInicial() {
		if (jToolBarPaginaInicial == null) {
			jToolBarPaginaInicial = new JToolBar();
			jToolBarPaginaInicial.setBounds(new Rectangle(621, 27, 64, 19));
			jToolBarPaginaInicial.add(getJButtonVoltarInicial());
		}
		return jToolBarPaginaInicial;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelExibirArtigoDeConferencia.this.frame.setContentPane(new PainelPublicacoes(PainelExibirArtigoDeConferencia.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			DefaultListModel listmodelLinhas = new DefaultListModel();
			jListLinhas = new JList(listmodelLinhas);
			jListLinhas.setBounds(new Rectangle(18, 414, 361, 73));
			
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmaPublicacao(this.artigo.getTitulo());
				for(int i = 0; i< linhas.size(); i++){
					listmodelLinhas.addElement(linhas.elementAt(i));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListLinhas;
	}

} // @jve:decl-index=0:visual-constraint="10,10"