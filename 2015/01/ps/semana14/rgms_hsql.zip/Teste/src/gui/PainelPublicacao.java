package gui;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.Dimension;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import java.awt.Rectangle;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;

import base.*;

public class PainelPublicacao extends JPanel {

	private JPanel painelExibirPublicacoes = null; // @jve:decl-index=0:visual-constraint="-79,26"
	private JLabel labelTipoPublicacao = null;
	private Vector teses = new Vector(); // @jve:decl-index=0:
	private Vector dissertacoes = new Vector(); // @jve:decl-index=0:
	private Vector artigosConferencias = new Vector(); // @jve:decl-index=0:
	private Vector artigosPeriodicos = new Vector(); // @jve:decl-index=0:
	private JButton botaoRemover = null;
	private JButton botaoEditar = null;

	/**
	 * This method initializes
	 * 
	 */
	public PainelPublicacao() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 */
	private void initialize() {
		this.setSize(new Dimension(29, 16));

	}

	/**
	 * This method initializes painelExibirPublicacoes
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getPainelExibirPublicacoes() {
		if (painelExibirPublicacoes == null) {
			labelTipoPublicacao = new JLabel();
			labelTipoPublicacao.setBounds(new Rectangle(31, 40, 300, 16));
			labelTipoPublicacao
					.setText("Selecione o tipo de publica��o que deseja cadastrar");
			painelExibirPublicacoes = new JPanel();
			painelExibirPublicacoes.setLayout(null);
			painelExibirPublicacoes.setSize(new Dimension(688, 340));
			painelExibirPublicacoes.add(getBotaoRemover(), null);
			painelExibirPublicacoes.add(getBotaoEditar(), null);
		}
		return painelExibirPublicacoes;
	}

	/**
	 * This method initializes resultadoBusca
	 * 
	 * @return javax.swing.JList
	 */

	/**
	 * This method initializes botaoRemover
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBotaoRemover() {
		if (botaoRemover == null) {
			botaoRemover = new JButton();
			botaoRemover.setBounds(new Rectangle(31, 149, 91, 34));
			botaoRemover.setText("Remover");
			botaoRemover.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {

					// buscar publica��o no bd e remov�-la.
					// 

					JOptionPane.showMessageDialog(null, "Publica��o removida!",
							"INFORMA��O", JOptionPane.INFORMATION_MESSAGE);

				}
			});
		}
		return botaoRemover;
	}

	/**
	 * This method initializes botaoEditar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBotaoEditar() {
		if (botaoEditar == null) {
			botaoEditar = new JButton();
			botaoEditar.setBounds(new Rectangle(31, 105, 91, 35));
			botaoEditar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {

					// passar o atributo publicacao como par�metro para o m�todo
					// do painel de cadastro a ser setado (que aqui funcionar�
					// como painel de edi��o, com todos os campos setados com
					// valores do objeto passado).

				}
			});
			botaoEditar.setText("Editar");
		}
		return botaoEditar;
	}

} // @jve:decl-index=0:visual-constraint="601,4"
