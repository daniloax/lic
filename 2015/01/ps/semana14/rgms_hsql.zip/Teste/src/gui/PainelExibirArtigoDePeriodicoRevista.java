package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;

import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.Membro;
import java.lang.String;
import javax.swing.JToolBar;

public class PainelExibirArtigoDePeriodicoRevista extends JPanel {

	private ArtigoEmPeriodicoERevista artigo; // @jve:decl-index=0:

	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;

	private JLabel labelTitulo1 = null;
	private JLabel labelAno = null;
	private JButton jButtonCarregaPdf = null;
	private JLabel labelAno1 = null;
	private JLabel labelAno11 = null;
	private JLabel labelAno2 = null;
	private JButton jButtonRemover = null;
	private JButton jButtonCancelar = null;
	private JTextField exibirTitulo = null;
	private JTextField exibirPeriodicoOuRevista = null;
	private JTextField exibirAno = null;
	private JTextField exibirVolume = null;
	private JTextField exibirPaginas = null;
	private JTextField exibirAutores = null;
	private JScrollPane scrollBusca = null;
	private JLabel labelAno21 = null;

	private JList jListMembros = null;

	private JLabel labelAno111 = null;

	private ArtigoEmConferencia artigo1 = null;

	private JTextField jTextFieldNumero = null;

	private JToolBar jToolBarPaginaInicial = null;

	private JButton jButtonVoltarInicial = null;
	
	//LINHASDEPESQUISA
	private JLabel jLabel1 = null;

	private JList jListLinhas = null;
	
	private JScrollPane scrollLinhas = null;
	//LINHASDEPESQUISA

	/**
	 * This is the default constructor
	 */
	public PainelExibirArtigoDePeriodicoRevista(FramePrincipal frame, ArtigoEmPeriodicoERevista artigo) {
		super();
		this.frame = frame;
		this.artigo = artigo;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(27, 378, 199, 19));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelAno111 = new JLabel();
		labelAno111.setBounds(new Rectangle(198, 162, 55, 19));
		labelAno111.setText("N�mero:");
		labelAno21 = new JLabel();
		labelAno21.setBounds(new Rectangle(18, 216, 253, 19));
		labelAno21.setText("Autores integrantes do grupo de pesquisa:");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(27, 324, 100, 19));
		labelAno2.setText(" Demais autores:");
		labelAno11 = new JLabel();
		labelAno11.setBounds(new Rectangle(324, 162, 64, 19));
		labelAno11.setText(" P�ginas:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(81, 162, 55, 19));
		labelAno1.setText("Volume:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(18, 162, 46, 19));
		labelAno.setText(" Ano: ");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(18, 99, 178, 19));
		labelTitulo1.setText("Nome do Peri�dico ou Revista:");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 45, 91, 19));
		labelTitulo.setText(" Titulo Artigo: ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(18, 27, 137, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Detalhes do artigo");
		this.setSize(723, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelTitulo1, null);
		this.add(labelAno, null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(labelAno1, null);
		this.add(labelAno11, null);
		this.add(labelAno2, null);

		this.add(getJButtonRemover(), null);
		this.add(getJButtonEditar(), null);
		this.add(getExibirTitulo(), null);
		this.add(getExibirPeriodicoOuRevista(), null);
		this.add(getExibirAno(), null);
		this.add(getExibirVolume(), null);
		this.add(getExibirPaginas(), null);
		this.add(getExibirAutores(), null);
		this.add(labelAno21, null);
		
		this.add(getJListMembros(), null);
		this.scrollBusca = new JScrollPane(this.jListMembros);
		this.scrollBusca.setBounds(new Rectangle(18, 243, 361, 73));
		this.scrollBusca.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollBusca.setVisible(true);
		this.add(scrollBusca);
		
		this.add(labelAno111, null);
		this.add(getJTextFieldNumero(), null);
		this.add(getJToolBarPaginaInicial(), null);
		
		//LINHASDEPESQUISA
		this.add(jLabel1, null);
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(27, 405, 352, 73));
		//this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		//LINHASDEPESQUISA
	}

	/**
	 * This method initializes jButtonCarregaPdf
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(468, 189, 190, 19));
			jButtonCarregaPdf.setText("Visualizar artigo em pdf");
			jButtonCarregaPdf.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							PainelExibirArtigoDePeriodicoRevista.this.carregaPdf();
						}
					});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf() {
		try {
			Desktop.getDesktop().open(this.artigo.getPdf());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// incluir trecho de c�digo para abrir pdf com visualizar padr�o em java
	}

	/**
	 * This method initializes jButtonCadastrar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonRemover() {
		if (jButtonRemover == null) {
			jButtonRemover = new JButton();
			jButtonRemover.setBounds(new Rectangle(432, 486, 109, 28));
			jButtonRemover.setText("Remover");
			jButtonRemover
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							// chamar m�todo para remover artigo do bd
							// n�o � preciso carregar outra tela, apenas exibir
							// uma msg de confirma��o da remo��o

							JOptionPane.showMessageDialog(null,
									"Publica��o removida!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);

						}
					});
		}
		return jButtonRemover;
	}

	/**
	 * This method initializes jButtonCancelar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonEditar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(567, 486, 109, 28));
			jButtonCancelar.setText("Editar");

			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {   
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					PainelExibirArtigoDePeriodicoRevista.this.frame.setContentPane(new PainelEditarArtigoPeriodicoRevista(PainelExibirArtigoDePeriodicoRevista.this.frame, PainelExibirArtigoDePeriodicoRevista.this.artigo));
				}
			
					});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTitulo() {
		if (exibirTitulo == null) {
			exibirTitulo = new JTextField();
			exibirTitulo.setBounds(new Rectangle(18, 63, 609, 20));
			// preenche com o valor
			String titulo = this.artigo.getTitulo();
			exibirTitulo.setText(titulo);
			exibirTitulo.setEnabled(false);
		}
		return exibirTitulo;
	}

	/**
	 * This method initializes exibirConferencia
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirPeriodicoOuRevista() {
		if (exibirPeriodicoOuRevista == null) {
			exibirPeriodicoOuRevista = new JTextField();
			exibirPeriodicoOuRevista.setBounds(new Rectangle(18, 126, 608, 20));
			// preenche com o valor
			String jornal = this.artigo.getJornal();
			exibirPeriodicoOuRevista.setText(jornal);
			exibirPeriodicoOuRevista.setEnabled(false);

		}
		return exibirPeriodicoOuRevista;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAno() {
		if (exibirAno == null) {
			exibirAno = new JTextField();
			exibirAno.setBounds(new Rectangle(18, 189, 41, 20));
			// preenche com o valor
			String ano = this.artigo.getAno();
			exibirAno.setText(ano);
			exibirAno.setEnabled(false);
		}
		return exibirAno;
	}

	/**
	 * This method initializes exibirMes
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirVolume() {
		if (exibirVolume == null) {
			exibirVolume = new JTextField();
			exibirVolume.setBounds(new Rectangle(81, 189, 100, 20));
			// preenche com o valor
			String volume = this.artigo.getVolume();
			exibirVolume.setText(volume);
			exibirVolume.setEnabled(false);
		}
		return exibirVolume;
	}

	/**
	 * This method initializes exibirPaginas
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirPaginas() {
		if (exibirPaginas == null) {
			exibirPaginas = new JTextField();
			exibirPaginas.setBounds(new Rectangle(324, 189, 100, 20));
			// preenche com o valor
			String paginas = this.artigo.getPaginas();
			exibirPaginas.setText(paginas);
			exibirPaginas.setEnabled(false);
		}
		return exibirPaginas;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAutores() {
		if (exibirAutores == null) {
			exibirAutores = new JTextField();
			exibirAutores.setBounds(new Rectangle(27, 351, 605, 20));
			// preencher com o valor
			// verificar formato de inser��o dos autores no objeto
			String autores = this.artigo.getAutoresNaoMembros();
			exibirAutores.setText(autores);
			exibirAutores.setEnabled(false);
		}
		return exibirAutores;
	}

	public ArtigoEmPeriodicoERevista getArtigo() {
		return artigo;
	}

	public void setArtigo(ArtigoEmPeriodicoERevista artigo) {
		this.artigo = artigo;
	}

	/**
	 * This method initializes jListMembros	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListMembros() {
		if (jListMembros == null) {
			
			DefaultListModel listaMembros = new DefaultListModel();
			jListMembros = new JList(listaMembros);
			jListMembros.setBounds(new Rectangle(18, 270, 361, 73));
			try {
				Vector<String> membros = this.frame.getFachada().retornaMembrosDeUmaPublicacao(this.artigo.getTitulo());
				Iterator<String> it = membros.iterator();
				while(it.hasNext()){
					String x = it.next();
					listaMembros.addElement(x);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListMembros;
	}

	/**
	 * This method initializes jTextFieldNumero	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNumero() {
		if (jTextFieldNumero == null) {
			jTextFieldNumero = new JTextField();
			jTextFieldNumero.setBounds(new Rectangle(198, 189, 109, 19));
			// preenche com o valor
			String numero = this.artigo.getNumero();
			jTextFieldNumero.setText(numero);
			jTextFieldNumero.setEnabled(false);
			
		}
		return jTextFieldNumero;
	}

	/**
	 * This method initializes jToolBarPaginaInicial	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarPaginaInicial() {
		if (jToolBarPaginaInicial == null) {
			jToolBarPaginaInicial = new JToolBar();
			jToolBarPaginaInicial.setBounds(new Rectangle(630, 27, 64, 19));
			jToolBarPaginaInicial.add(getJButtonVoltarInicial());
		}
		return jToolBarPaginaInicial;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelExibirArtigoDePeriodicoRevista.this.frame.setContentPane(new PainelPublicacoes(PainelExibirArtigoDePeriodicoRevista.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			DefaultListModel listModelLinhas = new DefaultListModel();
			jListLinhas = new JList(listModelLinhas);
			jListLinhas.setBounds(new Rectangle(27, 405, 352, 73));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmaPublicacao(this.artigo.getTitulo());
				for(int i = 0; i< linhas.size(); i++){
					listModelLinhas.addElement(linhas.elementAt(i));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhas;
	}

} // @jve:decl-index=0:visual-constraint="10,10"