package gui;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.Dimension;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import java.awt.Rectangle;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;

import base.*;
import java.awt.Point;
import java.awt.Font;
import javax.swing.JToolBar;

public class PainelLinhasDePesquisa extends JPanel {

	public FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private Vector<String> linhasDePesquisa = new Vector<String>(); // @jve:decl-index=0:
	private Vector<String> todasAsLinhas = new Vector<String>(); // @jve:decl-index=0:

	private JButton cadastrarLinhaDePesquisa = null;
	private JTextField campoBusca = null;
	private JButton buscar = null;

	private JList listaLinhasDePesquisa = null;
	private JScrollPane painelScroll = null;
	private DefaultListModel listModelLinhasDePesquisa = new DefaultListModel();

	private JButton botaoVisualizar = null;
	private JLabel jLabel = null;
	private JToolBar jToolBarTeste = null;
	private JButton jButtonVoltarInicial = null;
	private JLabel jLabel1 = null;
	private JLabel jLabel11 = null;
	
	/**
	 * This method initializes
	 * 
	 */
	public PainelLinhasDePesquisa(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 */
	private void initialize() {
		jLabel11 = new JLabel();
		jLabel11.setBounds(new Rectangle(45, 63, 217, 19));
		jLabel11.setText("nova Linha de Pesquisa:");
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(45, 45, 217, 19));
		jLabel1.setText("Clique abaixo para cadastrar uma ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(225, 162, 262, 28));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 18));
		jLabel.setText("Filtro de Linhas de Pesquisa:");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(getExibirLinhaDePesquisa(), null);
		this.add(getCampoBusca(), null);
		this.add(getBuscar(), null);
		this.add(getBotaoVisualizar(), null);

		this.add(getListaLinhasDePesquisa(), null);
		this.painelScroll = new JScrollPane(this.listaLinhasDePesquisa);
		this.painelScroll
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		painelScroll.setLocation(new Point(108, 234));
		painelScroll.setSize(new Dimension(496, 172));
		this.painelScroll.setVisible(true);
		this.add(painelScroll);

		this.add(jLabel, null);
		this.add(getJToolBarTeste(), null);
		this.add(jLabel1, null);
		this.add(jLabel11, null);
	
	}

	/**
	 * This method initializes painelExibirPublicacoes
	 * 
	 * @return javax.swing.JPanel
	 */

	/**
	 * This method initializes cadastrarPublicacao
	 * 
	 * @return javax.swing.JButton
	 */

	private JList getListaLinhasDePesquisa() {
		if (this.listaLinhasDePesquisa == null) {

			this.listModelLinhasDePesquisa = new DefaultListModel();
			this.listaLinhasDePesquisa = new JList(
					this.listModelLinhasDePesquisa);
			listaLinhasDePesquisa.setBounds(new Rectangle(75, 172, 588, 236));

			try {
				// criar m�todo na Fachada
				this.linhasDePesquisa = this.frame.getFachada().retornaTodasLinhasDePesquisa();
				this.todasAsLinhas = (Vector<String>) this.linhasDePesquisa
						.clone();
				Iterator<String> it = todasAsLinhas.iterator();
				while (it.hasNext()) {
					String linhaDePesquisa = (String) it.next();
					listModelLinhasDePesquisa.addElement(linhaDePesquisa);
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return listaLinhasDePesquisa;
	}

	private JButton getExibirLinhaDePesquisa() {
		if (cadastrarLinhaDePesquisa == null) {
			cadastrarLinhaDePesquisa = new JButton();
			cadastrarLinhaDePesquisa.setBounds(new Rectangle(45, 90, 217, 37));
			cadastrarLinhaDePesquisa.setText("Cadastro de Linha de Pesquisa");
			cadastrarLinhaDePesquisa.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
			PainelLinhasDePesquisa.this.frame.setContentPane(new PainelCadastrarLinhaDePesquisa(PainelLinhasDePesquisa.this.frame));
							
						}
					});
		}
		return cadastrarLinhaDePesquisa;
	}

	/**
	 * This method initializes campoBusca
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getCampoBusca() {
		if (campoBusca == null) {
			campoBusca = new JTextField();
			campoBusca.setBounds(new Rectangle(108, 207, 406, 22));

		}
		return campoBusca;
	}

	/**
	 * This method initializes buscar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBuscar() {
		if (buscar == null) {
			buscar = new JButton();
			buscar.setBounds(new Rectangle(522, 207, 82, 19));

			//buscar.setIcon(new ImageIcon(getClass().getResource("/lupa.jpg")));
			buscar.setText("Buscar");
			buscar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String busca = PainelLinhasDePesquisa.this.campoBusca.getText().trim().toUpperCase();
					
					if(!(busca.equals(""))){
						try {
							Vector<LinhaDePesquisa> linhas = PainelLinhasDePesquisa.this.frame.getFachada().procurarLinhaDePesquisaLike(busca);
							PainelLinhasDePesquisa.this.listModelLinhasDePesquisa.clear();
							Iterator<LinhaDePesquisa> it = linhas.iterator();
							while(it.hasNext()){
								String nome = it.next().getTitulo();
								PainelLinhasDePesquisa.this.listModelLinhasDePesquisa.addElement(nome);
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(PainelLinhasDePesquisa.this,
							    "Campo de busca n�o preenchido",
							    "Aviso",
							    JOptionPane.WARNING_MESSAGE);
					}
				}
			});
			
		}
		return buscar;
	}

	/**
	 * This method initializes resultadoBusca
	 * 
	 * @return javax.swing.JList
	 */

	/**
	 * This method initializes painelScroll
	 * 
	 * @return javax.swing.JScrollPane
	 */

	/**
	 * This method initializes botaoVisualizar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBotaoVisualizar() {
		if (botaoVisualizar == null) {
			botaoVisualizar = new JButton();
			botaoVisualizar.setBounds(new Rectangle(297, 414, 145, 35));
			botaoVisualizar.setText("Visualizar");
			botaoVisualizar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							String nomeLinha = PainelLinhasDePesquisa.this.retornarLinhaSelecionada();
							try {
								
								LinhaDePesquisa linha = PainelLinhasDePesquisa.this.frame.getFachada().buscaLinhaDePesquisa(nomeLinha);
								PainelLinhasDePesquisa.this.frame.setContentPane(new PainelExibirLinhaDePesquisa(PainelLinhasDePesquisa.this.frame , linha));
								
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (ClassNotFoundException e2) {
								// TODO Auto-generated catch block
								e2.printStackTrace();
							}
							
						}
					});
		}
		return botaoVisualizar;
	}

	public String retornarLinhaSelecionada() {

		String linha = "";

		linha = (String) this.listaLinhasDePesquisa.getSelectedValue();

		return linha;
	}

	/**
	 * This method initializes jToolBarTeste	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarTeste() {
		if (jToolBarTeste == null) {
			jToolBarTeste = new JToolBar();
			jToolBarTeste.setBounds(new Rectangle(540, 36, 136, 19));
			jToolBarTeste.add(getJButtonVoltarInicial());
		}
		return jToolBarTeste;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar a p�gina inicial");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelLinhasDePesquisa.this.frame.setContentPane(new PainelPrincipal(PainelLinhasDePesquisa.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	

}  //  @jve:decl-index=0:visual-constraint="586,1"
