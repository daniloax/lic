package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JButton;
import java.awt.Rectangle;
import javax.swing.JInternalFrame;
import java.awt.BorderLayout;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JTextField;
import javax.swing.JList;
import java.awt.Font;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JLabel;

import excecoes.MembroNaoEncontradoException;
import excecoes.ParametroVazioException;

import base.Membro;

public class PainelMembros extends JPanel {
	
	private DefaultListModel listaMembros;
	private static final long serialVersionUID = 1L;
	private FramePrincipal frame = null;
	private Vector<Membro> membros = null;
	private JButton jButtonVoltarInicial = null;
	private JToolBar jToolBarTeste = null;
	private JButton jButtonEditarPerfil = null;
	private JButton jButtonBuscarMembro = null;
	private JTextField jTextFieldNome = null;
	private JList jListMembros = null;
	private JScrollPane scrollBusca = null;
	private JButton jButtonVisualizar = null;
	private JLabel jLabelTitulo = null;
	private DefaultListModel listModelMembros = null;
	/**
	 * This is the default constructor
	 */
	public PainelMembros(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabelTitulo = new JLabel();
		jLabelTitulo.setBounds(new Rectangle(279, 81, 145, 37));
		jLabelTitulo.setText("Busca de Membros");
		jLabelTitulo.setFont(new Font("Calibri", Font.BOLD, 18));
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(getJToolBarTeste(), null);
		this.add(getJButtonBuscarMembro(), null);
		this.add(getJTextFieldNome(), null);
		
		this.add(getJListMembros(), null);
		this.scrollBusca = new JScrollPane(this.jListMembros);
		this.scrollBusca.setBounds(new Rectangle(81, 216, 496, 172));
		this.scrollBusca.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollBusca.setVisible(true);
		this.add(scrollBusca);
		this.add(getJButtonVisualizar(), null);
		this.add(jLabelTitulo, null);
		
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setText("Voltar a p�gina inicial");
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelMembros.this.frame.setContentPane(new PainelPrincipal(PainelMembros.this.frame));
				}
			});
			
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jToolBarTeste	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarTeste() {
		if (jToolBarTeste == null) {
			jToolBarTeste = new JToolBar();
			jToolBarTeste.setBounds(new Rectangle(450, 27, 235, 19));
			jToolBarTeste.add(getJButtonEditarPerfil());
			jToolBarTeste.add(getJButtonVoltarInicial());
		}
		return jToolBarTeste;
	}

	/**
	 * This method initializes jButtonEditarPerfil	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonEditarPerfil() {
		if (jButtonEditarPerfil == null) {
			jButtonEditarPerfil = new JButton();
			jButtonEditarPerfil.setText("Editar meu perfil");
			jButtonEditarPerfil.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonEditarPerfil.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String login = PainelMembros.this.frame.getMembro().getLogin();
					try {
						Membro x = PainelMembros.this.frame.getFachada().buscaMembroLogin(login);
						PainelMembros.this.frame.getMembro().setId_membro(x.getId_membro());
						PainelMembros.this.frame.setContentPane(new PainelEditarMembro(PainelMembros.this.frame, x));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
		}
		return jButtonEditarPerfil;
	}

	/**
	 * This method initializes jButtonBuscarMembro	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBuscarMembro() {
		if (jButtonBuscarMembro == null) {
			jButtonBuscarMembro = new JButton();
			jButtonBuscarMembro.setBounds(new Rectangle(468, 153, 136, 28));
			jButtonBuscarMembro.setText("Buscar membro ");
			jButtonBuscarMembro.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String busca = PainelMembros.this.jTextFieldNome.getText().trim().toUpperCase();
					if(!(busca.equals(""))){
						try {
							Vector<Membro> membros = PainelMembros.this.frame.getFachada().procurarMembroLike(busca);
							Iterator<Membro> it = membros.iterator();
							PainelMembros.this.listaMembros.clear();
							while(it.hasNext()){
								String nome = it.next().getNome();
								PainelMembros.this.listaMembros.addElement(nome);
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ParametroVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (MembroNaoEncontradoException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(PainelMembros.this,
							    "Campo de busca n�o preenchido",
							    "Aviso",
							    JOptionPane.WARNING_MESSAGE);
					}
				}
			});
			
		}
		return jButtonBuscarMembro;
	}

	/**
	 * This method initializes jTextFieldNome	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNome() {
		if (jTextFieldNome == null) {
			jTextFieldNome = new JTextField();
			jTextFieldNome.setBounds(new Rectangle(108, 153, 343, 28));
		}
		return jTextFieldNome;
	}

	/**
	 * This method initializes jListMembros	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListMembros() {
		if (jListMembros == null) {
			this.listaMembros = new DefaultListModel();
			jListMembros = new JList(listaMembros);
			jListMembros.setBounds(new Rectangle(108, 216, 496, 172));
			
			try {
				this.membros = this.frame.getFachada().retornaTodosMembros();
				
				//adiciona aluno de inicia��o
				
				listaMembros.addElement("Inicia��o Cient�fica:");
				listaMembros.addElement("-----------------------------------------------");
				Iterator<Membro> itIniciacao = membros.iterator();
				while(itIniciacao.hasNext()){
					Membro x = (Membro) itIniciacao.next();
					if(x.getTipo().equalsIgnoreCase("Inicia��o Cient�fica")){
						listaMembros.addElement(x.getNome());
					}
				
				}
				listaMembros.addElement("-----------------------------------------------\n");
				
				//adiciona aluno de mestrado
				listaMembros.addElement("Mestrado:");
				listaMembros.addElement("-----------------------------------------------");
				Iterator<Membro> itMestrado = membros.iterator();
				while(itMestrado.hasNext()){
					Membro x = (Membro) itMestrado.next();
					if(x.getTipo().equalsIgnoreCase("Mestrado")){
						listaMembros.addElement(x.getNome());
					}
				
				}
				listaMembros.addElement("-----------------------------------------------\n");
				
				//adiciona aluno de doutorado
				listaMembros.addElement("Doutorado:");
				listaMembros.addElement("-----------------------------------------------");
				Iterator<Membro> itDoutorado = membros.iterator();
				while(itDoutorado.hasNext()){
					Membro x = (Membro) itDoutorado.next();
					if(x.getTipo().equalsIgnoreCase("Doutorado")){
				listaMembros.addElement(x.getNome());
					}
				}
				listaMembros.addElement("-----------------------------------------------\n");
				
				//adiciona Professor
				listaMembros.addElement("Professor:");
				listaMembros.addElement("-----------------------------------------------");
				Iterator<Membro> itProfessor = membros.iterator();
				while(itProfessor.hasNext()){
					Membro x = (Membro) itProfessor.next();
					if(x.getTipo().equalsIgnoreCase("Professor")){
				listaMembros.addElement(x.getNome());
					}
				}
				listaMembros.addElement("-----------------------------------------------\n");
				
				//adiciona outros
				listaMembros.addElement("Outros:");
				listaMembros.addElement("-----------------------------------------------");
				Iterator<Membro> itOutros = membros.iterator();
				while(itProfessor.hasNext()){
					Membro x = (Membro) itProfessor.next();
					if(x.getTipo().equalsIgnoreCase("Outro")|| x.getTipo().equals("") ){
				listaMembros.addElement(x.getNome());
					}
				}
				listaMembros.addElement("-----------------------------------------------\n");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			/*for(int i = 0; i < 30 ; i++){
				listaMembros.addElement(""+i);
			}*/

			
			
		}
		return jListMembros;
	}
	
	
	
	
	/**
	 * This method initializes jButtonVisualizar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVisualizar() {
		if (jButtonVisualizar == null) {
			jButtonVisualizar = new JButton();
			jButtonVisualizar.setBounds(new Rectangle(261, 396, 136, 31));
			jButtonVisualizar.setText("Visualizar");
			jButtonVisualizar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					int retorno = PainelMembros.this.jListMembros.getSelectedIndex();
					if(retorno != -1){
						String nomeMembro = (String) PainelMembros.this.jListMembros.getSelectedValue();
						try {
							Membro membro = PainelMembros.this.frame.getFachada().buscaMembro(nomeMembro);
							//chamar painel exibir membro passando membro
							PainelMembros.this.frame.setContentPane(new PainelExibirMembro(PainelMembros.this.frame, membro));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						//Membro membro = PainelMembros.this.frame.getFachada().procurarMembro(nomeMembro);
					}
				}
			});
		}
		return jButtonVisualizar;
	}

}  //  @jve:decl-index=0:visual-constraint="21,8"
