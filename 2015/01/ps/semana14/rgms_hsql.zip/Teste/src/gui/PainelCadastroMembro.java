package gui;


import java.awt.Image;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.awt.Rectangle;
import javax.swing.JButton;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JComboBox;

import excecoes.MembroJaExistenteException;
import excecoes.ObjetoVazioException;
import base.Membro;
import java.awt.Dimension;
import javax.swing.JList;

public class PainelCadastroMembro extends JPanel {

	private static final long serialVersionUID = 1L;
	private JButton jButtonCarregaFoto = null;
	private JLabel jLabelFoto = null;
	private ImageIcon img = null;  //  @jve:decl-index=0:
	private JLabel jLabel = null;
	private JTextField jTextFieldNome = null;
	private JLabel jLabel1 = null;
	private JTextField jTextFieldLogin = null;
	private JLabel jLabel2 = null;
	private JPasswordField jPasswordFieldSenha = null;
	private JLabel jLabel3 = null;
	private JLabel jLabel31 = null;
	private JTextField jTextFieldUniversidade = null;
	private JLabel jLabel4 = null;
	private JLabel jLabel21 = null;
	private JTextField jTextFieldEmail = null;
	private JLabel jLabel211 = null;
	private JTextField jTextFieldWebsite = null;
	private JLabel jLabelObrigatorio = null;
	private JLabel jLabelObrigatorio1 = null;
	private JLabel jLabelObrigatorio11 = null;
	private JLabel jLabelObrigatorio111 = null;
	private JTextField jTextFieldDepartamento = null;
	private JLabel jLabel41 = null;
	private JLabel jLabel411 = null;
	private JLabel jLabel4111 = null;
	private JTextField jTextFieldTelefone = null;
	private JTextField jTextFieldCidade = null;
	private JTextField jTextFieldPais = null;
	private JLabel jLabelObrigatorio12 = null;
	private JButton jButtonCadastrar = null;
	private JButton jButtonCancelar = null;
	private JLabel jLabel41111 = null;
	private JComboBox jComboBoxTipoMembro = null;
	
	private FramePrincipal frame = null;
	private Membro membro = null;  //  @jve:decl-index=0:
	private String enderecoFoto = "";  //  @jve:decl-index=0:
	private JLabel jLabel5 = null;
	private JList jListLinhas = null;
	private JList jListLinhasSelecionadas = null;
	private JButton jButtonEntrar = null;
	private JButton jButtonSair = null;
	private DefaultListModel listModelLinhas;
	private DefaultListModel listModelLinhasSelecionadas;
	private JScrollPane scrollLinhas;
	private JScrollPane scrollLinhasSelecionadas;
	public String getEnderecoFoto() {
		return enderecoFoto;
	}

	public void setEnderecoFoto(String enderecoFoto) {
		this.enderecoFoto = enderecoFoto;
	}

	/**
	 * This is the default constructor
	 */
	public PainelCadastroMembro(FramePrincipal frame) {
		super();
		this.frame = frame;
		
		initialize();
	}
	
	public void inicializarMembro(){
		
		this.membro = new Membro();
		this.membro.setNome(this.jTextFieldNome.getText().trim().toUpperCase());
		this.membro.setLogin(this.jTextFieldLogin.getText().trim().toUpperCase());
		this.membro.setSenha(this.jPasswordFieldSenha.getText().toUpperCase());
		this.membro.setEmail(this.jTextFieldEmail.getText().trim().toUpperCase());
		this.membro.setWebsite(this.jTextFieldWebsite.getText().trim().toUpperCase());
		this.membro.setTelefone(this.jTextFieldTelefone.getText().trim().toUpperCase());
		this.membro.setCidade(this.jTextFieldCidade.getText().trim().toUpperCase());
		this.membro.setPais(this.jTextFieldPais.getText().trim().toUpperCase());
		this.membro.setUniversidade(this.jTextFieldUniversidade.getText().trim().toUpperCase());
		this.membro.setDpto_univ(this.jTextFieldDepartamento.getText().trim().toUpperCase());
		String tipoMembro = (String) (this.jComboBoxTipoMembro.getSelectedItem());
		this.membro.setTipo(tipoMembro.toUpperCase());
		this.membro.setUrlFoto(this.enderecoFoto);
		this.membro.setStatus("ATIVO");
		//LINHADEPESQUISA
		Vector<String> linhas = new Vector();
		for(int i = 0; i < this.listModelLinhasSelecionadas.getSize(); i++){
			String linha = (String) this.listModelLinhasSelecionadas.getElementAt(i);
			linhas.add(linha);
		}
		this.membro.setLinhasDePesquisa(linhas);
		//LINHADEPESQUISA
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
 
        jLabel5 = new JLabel();
        jLabel5.setBounds(new Rectangle(180, 351, 190, 19));
        jLabel5.setText("Linhas de Pesquisa associadas:");
        jLabel41111 = new JLabel();
        jLabel41111.setBounds(new Rectangle(180, 324, 100, 19));
        jLabel41111.setText("Tipo de Membro:");
        jLabelObrigatorio12 = new JLabel();
        jLabelObrigatorio12.setBounds(new Rectangle(198, 513, 127, 19));
        jLabelObrigatorio12.setText("*Campos Obrigat�rios");
        jLabelObrigatorio12.setFont(new Font("Dialog", Font.BOLD, 12));
        jLabel4111 = new JLabel();
        jLabel4111.setBounds(new Rectangle(180, 297, 91, 19));
        jLabel4111.setText("Departamento:");
        jLabel411 = new JLabel();
        jLabel411.setBounds(new Rectangle(180, 270, 91, 19));
        jLabel411.setText("Universidade:");
        jLabel41 = new JLabel();
        jLabel41.setBounds(new Rectangle(180, 243, 55, 19));
        jLabel41.setText("Pa�s:");
        jLabelObrigatorio111 = new JLabel();
        jLabelObrigatorio111.setBounds(new Rectangle(414, 135, 10, 19));
        jLabelObrigatorio111.setText("*");
        jLabelObrigatorio111.setFont(new Font("Dialog", Font.BOLD, 18));
        jLabelObrigatorio11 = new JLabel();
        jLabelObrigatorio11.setBounds(new Rectangle(411, 108, 13, 19));
        jLabelObrigatorio11.setText("*");
        jLabelObrigatorio11.setFont(new Font("Dialog", Font.BOLD, 18));
        jLabelObrigatorio1 = new JLabel();
        jLabelObrigatorio1.setBounds(new Rectangle(414, 81, 19, 19));
        jLabelObrigatorio1.setText("*");
        jLabelObrigatorio1.setFont(new Font("Dialog", Font.BOLD, 18));
        jLabelObrigatorio = new JLabel();
        jLabelObrigatorio.setBounds(new Rectangle(549, 45, 19, 19));
        jLabelObrigatorio.setFont(new Font("Dialog", Font.BOLD, 18));
        jLabelObrigatorio.setText("*");
        jLabel211 = new JLabel();
        jLabel211.setBounds(new Rectangle(180, 162, 55, 19));
        jLabel211.setText("Website:");
        jLabel21 = new JLabel();
        jLabel21.setBounds(new Rectangle(180, 135, 46, 19));
        jLabel21.setText("Email:");
        jLabel4 = new JLabel();
        jLabel4.setBounds(new Rectangle(180, 216, 55, 19));
        jLabel4.setText("Cidade:");
        jLabel31 = new JLabel();
        jLabel31.setBounds(new Rectangle(180, 189, 55, 19));
        jLabel31.setText("Telefone:");
        jLabel3 = new JLabel();
        jLabel3.setBounds(new Rectangle(180, 27, 145, 19));
        jLabel3.setText("Formul�rio de Cadastro:");
        jLabel2 = new JLabel();
        jLabel2.setBounds(new Rectangle(180, 108, 46, 19));
        jLabel2.setText("Senha:");
        jLabel1 = new JLabel();
        jLabel1.setBounds(new Rectangle(180, 81, 37, 19));
        jLabel1.setText("Login:");
        jLabel = new JLabel();
        jLabel.setBounds(new Rectangle(180, 54, 37, 19));
        jLabel.setText("Nome:");
        this.img = new ImageIcon(this.enderecoFoto);
        Image i2 = img.getImage();
        img.setImage(i2.getScaledInstance(200,194,Image.SCALE_FAST));
        
		jLabelFoto = new JLabel(img);
		jLabelFoto.setBounds(new Rectangle(18, 36, 127, 142));
		
		this.setSize(710, 587);
		this.setLayout(null);
		this.add(getJButtonCarregaFoto(), null);
		this.add(jLabelFoto, null);
		this.add(jLabel, null);
		this.add(getJTextFieldNome(), null);
		this.add(jLabel1, null);
		this.add(getJTextFieldLogin(), null);
		this.add(jLabel2, null);
		this.add(getJPasswordFieldSenha(), null);
		this.add(jLabel3, null);
		this.add(jLabel31, null);
		this.add(getJTextFieldUniversidade(), null);
		this.add(jLabel4, null);
		this.add(jLabel21, null);
		this.add(getJTextFieldEmail(), null);
		this.add(jLabel211, null);
		this.add(getJTextFieldWebsite(), null);
		this.add(jLabelObrigatorio, null);
		this.add(jLabelObrigatorio1, null);
		this.add(jLabelObrigatorio11, null);
		this.add(jLabelObrigatorio111, null);
		this.add(getJTextFieldDepartamento(), null);
		this.add(jLabel41, null);
		this.add(jLabel411, null);
		this.add(jLabel4111, null);
		this.add(getJTextFieldTelefone(), null);
		this.add(getJTextFieldCidade(), null);
		this.add(getJTextFieldPais(), null);
		this.add(jLabelObrigatorio12, null);
		this.add(getJButtonCadastrar(), null);
		this.add(getJButtonCancelar(), null);
		this.add(jLabel41111, null);
		this.add(getJComboBoxTipoMembro(), null);
		this.add(jLabel5, null);
		
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(180, 378, 199, 100));
		this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		
		this.add(getJListLinhasSelecionadas(), null);
		this.scrollLinhasSelecionadas = new JScrollPane(this.jListLinhasSelecionadas);
		this.scrollLinhasSelecionadas.setBounds(new Rectangle(468, 378, 199, 100));
		this.scrollLinhasSelecionadas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhasSelecionadas.setVisible(true);
		this.add(scrollLinhasSelecionadas);
		
		this.add(getJButtonEntrar(), null);
		this.add(getJButtonSair(), null);
	}

	/**
	 * This method initializes jButtonCarregaFoto	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCarregaFoto() {
		if (jButtonCarregaFoto == null) {
			jButtonCarregaFoto = new JButton();
			jButtonCarregaFoto.setBounds(new Rectangle(18, 180, 127, 19));
			jButtonCarregaFoto.setText("Carregar foto*");
			jButtonCarregaFoto.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelCadastroMembro.this.bCarregarFoto();
					//PainelCadastroMembro.this.redimesionarImagem();
				}
			});
		}
		return jButtonCarregaFoto;
	}
	
public void bCarregarFoto(){
	JFileChooser arquivo = new JFileChooser();
	int returnVal = arquivo.showOpenDialog(this);
	
	if(returnVal == JFileChooser.APPROVE_OPTION){
		
	File arq = arquivo.getSelectedFile();
	this.enderecoFoto = arq.getAbsolutePath();
	ImageIcon imagem = new ImageIcon(this.enderecoFoto);
	Image temp = imagem.getImage();
	Image temp2 = temp.getScaledInstance(127,142, 0);
	this.jLabelFoto.setIcon(new ImageIcon(temp2));

	}
	
}



/**
 * This method initializes jTextFieldNome	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldNome() {
	if (jTextFieldNome == null) {
		jTextFieldNome = new JTextField();
		jTextFieldNome.setBounds(new Rectangle(234, 54, 307, 19));
	}
	return jTextFieldNome;
}

/**
 * This method initializes jTextFieldLogin	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldLogin() {
	if (jTextFieldLogin == null) {
		jTextFieldLogin = new JTextField();
		jTextFieldLogin.setBounds(new Rectangle(234, 81, 172, 19));
	}
	return jTextFieldLogin;
}

/**
 * This method initializes jPasswordFieldSenha	
 * 	
 * @return javax.swing.JPasswordField	
 */
private JPasswordField getJPasswordFieldSenha() {
	if (jPasswordFieldSenha == null) {
		jPasswordFieldSenha = new JPasswordField();
		jPasswordFieldSenha.setBounds(new Rectangle(234, 108, 172, 19));
	}
	return jPasswordFieldSenha;
}

/**
 * This method initializes jTextFieldUniversidade	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldUniversidade() {
	if (jTextFieldUniversidade == null) {
		jTextFieldUniversidade = new JTextField();
		jTextFieldUniversidade.setBounds(new Rectangle(279, 270, 217, 19));
	}
	return jTextFieldUniversidade;
}

/**
 * This method initializes jTextFieldEmail	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldEmail() {
	if (jTextFieldEmail == null) {
		jTextFieldEmail = new JTextField();
		jTextFieldEmail.setBounds(new Rectangle(234, 135, 172, 19));
	}
	return jTextFieldEmail;
}

/**
 * This method initializes jTextFieldWebsite	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldWebsite() {
	if (jTextFieldWebsite == null) {
		jTextFieldWebsite = new JTextField();
		jTextFieldWebsite.setBounds(new Rectangle(243, 162, 172, 19));
	}
	return jTextFieldWebsite;
}

/**
 * This method initializes jTextFieldDepartamento	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldDepartamento() {
	if (jTextFieldDepartamento == null) {
		jTextFieldDepartamento = new JTextField();
		jTextFieldDepartamento.setBounds(new Rectangle(279, 297, 217, 19));
	}
	return jTextFieldDepartamento;
}

/**
 * This method initializes jTextFieldTelefone	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldTelefone() {
	if (jTextFieldTelefone == null) {
		jTextFieldTelefone = new JTextField();
		jTextFieldTelefone.setBounds(new Rectangle(243, 189, 172, 19));
	}
	return jTextFieldTelefone;
}

/**
 * This method initializes jTextFieldCidade	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldCidade() {
	if (jTextFieldCidade == null) {
		jTextFieldCidade = new JTextField();
		jTextFieldCidade.setBounds(new Rectangle(243, 216, 172, 19));
	}
	return jTextFieldCidade;
}

/**
 * This method initializes jTextFieldPais	
 * 	
 * @return javax.swing.JTextField	
 */
private JTextField getJTextFieldPais() {
	if (jTextFieldPais == null) {
		jTextFieldPais = new JTextField();
		jTextFieldPais.setBounds(new Rectangle(243, 243, 172, 19));
	}
	return jTextFieldPais;
}

/**
 * This method initializes jButtonCadastrar	
 * 	
 * @return javax.swing.JButton	
 */
private JButton getJButtonCadastrar() {
	if (jButtonCadastrar == null) {
		jButtonCadastrar = new JButton();
		jButtonCadastrar.setBounds(new Rectangle(459, 504, 100, 28));
		jButtonCadastrar.setText("Cadastrar");
		jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				PainelCadastroMembro.this.inicializarMembro();
				boolean camposObrigatorios = PainelCadastroMembro.this.verificaCampoObrigatorios();
				if(camposObrigatorios == true){
					try {
						PainelCadastroMembro.this.frame.getFachada().inserirMembro(PainelCadastroMembro.this.membro);
						JOptionPane.showMessageDialog(PainelCadastroMembro.this,
							    "Usu�rio inserido com sucesso!");
						PainelCadastroMembro.this.frame.setContentPane(new PainelPrincipal(PainelCadastroMembro.this.frame));

					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ObjetoVazioException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (MembroJaExistenteException e1) {
						JOptionPane.showMessageDialog(PainelCadastroMembro.this,
							    "Membro j� existente no banco de dados",
							    "Inane error",
							    JOptionPane.ERROR_MESSAGE);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else{
					JOptionPane.showMessageDialog(PainelCadastroMembro.this,
						    "Campos obrigat�rios n�o preenchidos corretamente!",
						    "Inane error",
						    JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
	}
	return jButtonCadastrar;
}

public boolean verificaCampoObrigatorios(){
	boolean retorno = true;
	if(this.membro.getNome().equals("") || this.membro.getLogin().equals("")|| 
			this.membro.getSenha().equals("") || this.membro.getEmail().equals("") || 
			this.membro.getUrlFoto().equals("")){
		retorno = false;
	}
	return retorno;
}

/**
 * This method initializes jButtonCancelar	
 * 	
 * @return javax.swing.JButton	
 */
private JButton getJButtonCancelar() {
	if (jButtonCancelar == null) {
		jButtonCancelar = new JButton();
		jButtonCancelar.setBounds(new Rectangle(576, 504, 91, 28));
		jButtonCancelar.setText("Cancelar");
		jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {   
			public void actionPerformed(java.awt.event.ActionEvent e) { 
				
				PainelCadastroMembro.this.frame.setContentPane(new PainelInicial(PainelCadastroMembro.this.frame));
				}
		
		});
	}
	return jButtonCancelar;
}

/**
 * This method initializes jComboBoxTipoMembro	
 * 	
 * @return javax.swing.JComboBox	
 */
private JComboBox getJComboBoxTipoMembro() {
	if (jComboBoxTipoMembro == null) {
		jComboBoxTipoMembro = new JComboBox();
		jComboBoxTipoMembro.setBounds(new Rectangle(288, 324, 217, 19));
		
		jComboBoxTipoMembro.addItem("Inicia��o Cient�fica");
		jComboBoxTipoMembro.addItem("Mestrado");
		jComboBoxTipoMembro.addItem("Doutorado");
		jComboBoxTipoMembro.addItem("Professor");
		jComboBoxTipoMembro.addItem("Outro");
	}
	return jComboBoxTipoMembro;
}

/**
 * This method initializes jListLinhas	
 * 	
 * @return javax.swing.JList	
 */
private JList getJListLinhas() {
	if (jListLinhas == null) {
		this.listModelLinhas = new DefaultListModel();
		jListLinhas = new JList(this.listModelLinhas);
		jListLinhas.setBounds(new Rectangle(180, 378, 199, 100));
		try {
			Vector<String> linhas = this.frame.getFachada().retornaTodasLinhasDePesquisa();
			Iterator<String> it = linhas.iterator();
			while(it.hasNext()){
				String linha = it.next();
				this.listModelLinhas.addElement(linha);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return jListLinhas;
}

/**
 * This method initializes jListLinhasSelecionadas	
 * 	
 * @return javax.swing.JList	
 */
private JList getJListLinhasSelecionadas() {
	if (jListLinhasSelecionadas == null) {
		this.listModelLinhasSelecionadas = new DefaultListModel();
		jListLinhasSelecionadas = new JList(this.listModelLinhasSelecionadas);
		jListLinhasSelecionadas.setBounds(new Rectangle(468, 378, 199, 100));
	}
	return jListLinhasSelecionadas;
}

/**
 * This method initializes jButtonEntrar	
 * 	
 * @return javax.swing.JButton	
 */
private JButton getJButtonEntrar() {
	if (jButtonEntrar == null) {
		jButtonEntrar = new JButton();
		jButtonEntrar.setBounds(new Rectangle(396, 378, 55, 37));
		jButtonEntrar.setText(">>");
		jButtonEntrar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				String linha = (String)PainelCadastroMembro.this.jListLinhas.getSelectedValue();
				int indice = PainelCadastroMembro.this.jListLinhas.getSelectedIndex();
				PainelCadastroMembro.this.listModelLinhas.removeElementAt(indice);
				PainelCadastroMembro.this.listModelLinhasSelecionadas.addElement(linha);
			}
		});
	}
	return jButtonEntrar;
}

/**
 * This method initializes jButtonSair	
 * 	
 * @return javax.swing.JButton	
 */
private JButton getJButtonSair() {
	if (jButtonSair == null) {
		jButtonSair = new JButton();
		jButtonSair.setBounds(new Rectangle(396, 441, 55, 37));
		jButtonSair.setText("<<");
		jButtonSair.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				String linha = (String)PainelCadastroMembro.this.jListLinhasSelecionadas.getSelectedValue();
				int indice = PainelCadastroMembro.this.jListLinhasSelecionadas.getSelectedIndex();
				PainelCadastroMembro.this.listModelLinhasSelecionadas.removeElementAt(indice);
				PainelCadastroMembro.this.listModelLinhas.addElement(linha);
			}
		});
	}
	return jButtonSair;
}


}  //  @jve:decl-index=0:visual-constraint="23,28"//fim da classe PainelCadastroMmebro
