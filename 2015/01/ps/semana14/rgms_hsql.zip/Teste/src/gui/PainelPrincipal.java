package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JScrollBar;
import javax.swing.BorderFactory;
import javax.swing.border.BevelBorder;
import javax.swing.JButton;

import base.Membro;
import javax.swing.JTextField;

public class PainelPrincipal extends JPanel {
	
	
	private static final long serialVersionUID = 1L;
	private JLabel jLabelTitulo = null;
	private JTextArea jTextAreaDescricao = null;
	private JScrollPane barra = null;
	private JButton jButtonMembros = null;
	private JButton jButtonPublicacoes = null;
	private FramePrincipal frame = null;
	private JButton jButtonLinhasDePesquisa = null;

	public FramePrincipal getFrame() {
		return frame;
	}

	public void setFrame(FramePrincipal frame) {
		this.frame = frame;
	}

	/**
	 * This is the default constructor
	 */
	public PainelPrincipal(FramePrincipal frame) {
		super();
		this.frame = frame;
		
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabelTitulo = new JLabel();
		jLabelTitulo.setBounds(new Rectangle(159, 63, 379, 28));
		jLabelTitulo.setText("Sistema de Gerenciamento de Grupos de Pesquisa");
		jLabelTitulo.setFont(new Font("Calibri", Font.BOLD, 18));
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabelTitulo, null);
		this.add(getJTextAreaDescricao(), null);
		this.barra = new JScrollPane(jTextAreaDescricao); //Adiciona Scroll no TextArea
		this.barra.setBounds(162, 126, 379, 109);
		barra.setForeground(Color.lightGray);
		barra.setViewportBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		barra.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		barra.setVisible(true);
		this.add(barra);
		this.add(getJButtonMembros(), null);
		this.add(getJButtonPublicacoes(), null);
		this.add(getJButtonLinhasDePesquisa(), null);

	}

	/**
	 * This method initializes jTextAreaDescricao	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextAreaDescricao() {
		if (jTextAreaDescricao == null) {
			jTextAreaDescricao = new JTextArea();
			jTextAreaDescricao.setBounds(new Rectangle(162, 90, 379, 109));
			jTextAreaDescricao.setLineWrap(true);
			jTextAreaDescricao.setEditable(false);
			jTextAreaDescricao.setText("Descri��o do grupo:" + '\n' + "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididu.");
		
		}
		return jTextAreaDescricao;
	}

	/**
	 * This method initializes jButtonMembros	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonMembros() {
		if (jButtonMembros == null) {
			jButtonMembros = new JButton();
			jButtonMembros.setBounds(new Rectangle(405, 378, 172, 37));
			jButtonMembros.setText("Membros");
			jButtonMembros.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelPrincipal.this.frame.setContentPane(new PainelMembros(PainelPrincipal.this.frame));
				}
			});
		}
		return jButtonMembros;
	}

	/**
	 * This method initializes jButtonPublicacoes	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonPublicacoes() {
		if (jButtonPublicacoes == null) {
			jButtonPublicacoes = new JButton();
			jButtonPublicacoes.setBounds(new Rectangle(402, 252, 172, 37));
			jButtonPublicacoes.setText("Publica��es");
			jButtonPublicacoes.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelPrincipal.this.frame.setContentPane(new PainelPublicacoes(PainelPrincipal.this.frame));
				}
			});
		}
		return jButtonPublicacoes;
	}

	/**
	 * This method initializes jButtonLinhasDePesquisa	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonLinhasDePesquisa() {
		if (jButtonLinhasDePesquisa == null) {
			jButtonLinhasDePesquisa = new JButton();
			jButtonLinhasDePesquisa.setBounds(new Rectangle(405, 315, 172, 37));
			jButtonLinhasDePesquisa.setText("Linhas de Pesquisa");
			jButtonLinhasDePesquisa.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelPrincipal.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelPrincipal.this.frame));
				}
			});
		}
		return jButtonLinhasDePesquisa;
	}

	

	

}  //  @jve:decl-index=0:visual-constraint="19,13"
