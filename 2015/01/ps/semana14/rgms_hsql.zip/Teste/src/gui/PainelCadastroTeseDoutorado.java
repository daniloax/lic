package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import excecoes.ObjetoVazioException;
import excecoes.PublicacaoJaExistenteException;

import base.ArtigoEmConferencia;
import base.DissertacaoDeMestrado;
import base.Membro;
import base.TeseDeDoutorado;

import javax.swing.JComboBox;

public class PainelCadastroTeseDoutorado extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private FramePrincipal frame;
	private JLabel labelTitulo = null;
	private JTextField jTextFieldTitulo = null;
	private JLabel labelAno = null;
	private JTextField jTextFieldUrlPdf = null;
	private JButton jButtonCarregaPdf = null;
	private JTextField jTextFieldAno = null;
	private JLabel labelAno1 = null;
	private JTextField jTextFieldMes = null;
	private JLabel labelAno2 = null;
	private JButton jButtonCadastrar = null;
	private JButton jButtonCancelar = null;
	private Vector<Membro> membros = new Vector<Membro>();
	private Vector<Membro> autores = new Vector<Membro>();  //  @jve:decl-index=0:
	private Vector<Membro> autoresSelecionados = new Vector();  //  @jve:decl-index=0:
	private TeseDeDoutorado artigo = new TeseDeDoutorado();  //  @jve:decl-index=0:
	private JLabel labelTitulo1 = null;
	private JTextField jTextFieldInstituicao = null;
	private JComboBox jComboBoxMembros = null;
	
	//LINHASDEPESQUISA
	private JLabel jLabel1 = null;
	private JList jListLinhas = null;
	private JList jListLinhasSelecionadas = null;
	private JButton jButtonSelecionaLinha = null;
	private JButton jButtonTiraLinha = null;
	private DefaultListModel listModellinhas = null;
	private DefaultListModel listModellinhasSelecionadas = null;
	private JScrollPane scrollLinhas = null;
	private JScrollPane scrollLinhasSelecionadas = null;
	//LINHASDEPESQUISA
	/**
	 * This is the default constructor
	 */
	public PainelCadastroTeseDoutorado(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(18, 261, 217, 19));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(18, 99, 73, 19));
		labelTitulo1.setText("Institui��o:*");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 189, 73, 19));
		labelAno2.setText("Doutorando:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(117, 144, 46, 19));
		labelAno1.setText("M�s:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(18, 144, 46, 19));
		labelAno.setText(" Ano: *");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 54, 118, 19));
		labelTitulo.setText("Titulo disserta��o: *");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(18, 27, 232, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText("Cadastro de tese de doutorado:");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(getJTextFieldTitulo(), null);
		this.add(labelAno, null);
		this.add(getJTextFieldUrlPdf(), null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(getJTextFieldAno(), null);
		this.add(labelAno1, null);
		this.add(getJTextFieldMes(), null);
		this.add(labelAno2, null);
		
		
		this.add(getJButtonCadastrar(), null);
		this.add(getJButtonCancelar(), null);
		this.add(labelTitulo1, null);
		this.add(getJTextFieldInstituicao(), null);
		this.add(getJComboBoxMembros(), null);
		
		//LINHASDEPESQUISA
		this.add(jLabel1, null);
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 288, 280, 100));
		//this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		this.add(getJListLinhasSelecionadas(), null);
		this.scrollLinhasSelecionadas = new JScrollPane(this.jListLinhasSelecionadas);
		this.scrollLinhasSelecionadas.setBounds(new Rectangle(405, 288, 280, 100));
		//this.scrollLinhasSelecionadas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhasSelecionadas.setVisible(true);
		this.add(scrollLinhasSelecionadas);
		this.add(getJButtonSelecionaLinha(), null);
		this.add(getJButtonTiraLinha(), null);
		//LINHASDEPESQUISA
	}

	/**
	 * This method initializes jTextFieldTitulo	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldTitulo() {
		if (jTextFieldTitulo == null) {
			jTextFieldTitulo = new JTextField();
			jTextFieldTitulo.setBounds(new Rectangle(18, 72, 361, 19));
		}
		return jTextFieldTitulo;
	}

	/**
	 * This method initializes jTextFieldUrlPdf	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldUrlPdf() {
		if (jTextFieldUrlPdf == null) {
			jTextFieldUrlPdf = new JTextField();
			jTextFieldUrlPdf.setBounds(new Rectangle(18, 234, 208, 19));
		}
		return jTextFieldUrlPdf;
	}

	/**
	 * This method initializes jButtonCarregaPdf	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(234, 234, 154, 19));
			jButtonCarregaPdf.setText("Carregar arquivo pdf*");
			jButtonCarregaPdf.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelCadastroTeseDoutorado.this.carregaPdf();
				}
			});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf(){
		JFileChooser arquivo = new JFileChooser();
		int returnVal = arquivo.showOpenDialog(this);
		
		if(returnVal == JFileChooser.APPROVE_OPTION){
			File arq = arquivo.getSelectedFile();
			this.jTextFieldUrlPdf.setText(arq.getAbsolutePath());
			this.artigo.setUrlPdf(arq.getAbsolutePath().trim().toUpperCase());
			
		}
	}
	/**
	 * This method initializes jTextFieldAno	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAno() {
		if (jTextFieldAno == null) {
			jTextFieldAno = new JTextField();
			jTextFieldAno.setBounds(new Rectangle(18, 162, 64, 19));
		}
		return jTextFieldAno;
	}

	/**
	 * This method initializes jTextFieldMes	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldMes() {
		if (jTextFieldMes == null) {
			jTextFieldMes = new JTextField();
			jTextFieldMes.setBounds(new Rectangle(117, 162, 91, 19));
		}
		return jTextFieldMes;
	}

	/**
	 * This method initializes jListAutores	
	 * 	
	 * @return javax.swing.JList	
	 */
	

	/**
	 * This method initializes jButtonCadastrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastrar() {
		if (jButtonCadastrar == null) {
			jButtonCadastrar = new JButton();
			jButtonCadastrar.setBounds(new Rectangle(441, 459, 109, 28));
			jButtonCadastrar.setText("Cadastrar");
			jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					boolean camposObrigatorios = PainelCadastroTeseDoutorado.this.carregaDissertacao();
					if(camposObrigatorios == true){
						try {
							PainelCadastroTeseDoutorado.this.frame.getFachada().inserirTeseDeDoutorado(PainelCadastroTeseDoutorado.this.artigo);
							JOptionPane.showMessageDialog(null,
									"Artigo cadastrado!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);
							PainelCadastroTeseDoutorado.this.frame.setContentPane(new PainelPublicacoes(PainelCadastroTeseDoutorado.this.frame));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ObjetoVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (PublicacaoJaExistenteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(null,
								"Campos obrigat�rios n�o preenchidos", "INFORMA��O",
								JOptionPane.WARNING_MESSAGE);
					}
				}
			});
		}
		return jButtonCadastrar;
	}
	
	public boolean carregaDissertacao(){
		boolean camposObrigatorios = true;
		String titulo = this.jTextFieldTitulo.getText().trim().toUpperCase();
		this.artigo.setTitulo(titulo);
		String instituicao = this.jTextFieldInstituicao.getText().trim().toUpperCase();
		this.artigo.setInstituicao(instituicao);
		String ano = this.jTextFieldAno.getText().trim().toUpperCase();
		this.artigo.setAno(ano);
		String mes = this.jTextFieldMes.getText().trim().toUpperCase();
		this.artigo.setMes(mes);
		String autor = (String) this.jComboBoxMembros.getSelectedItem();
		this.artigo.setAutoresMembros(autor);
		String urlpdf = this.jTextFieldUrlPdf.getText();
		
		//LINHASDEPESQUISA
		Vector<String> linhas = new Vector<String>();
		for(int i = 0; i < this.listModellinhasSelecionadas.size(); i++){
			String linha = (String)this.listModellinhasSelecionadas.elementAt(i);
			linhas.add(linha);
		}
		this.artigo.setLinhasDePesquisa(linhas);
		//LINHASDEPESQUISA
		
		if(titulo.equals("") || ano.equals("") || autor.equals("") || urlpdf.equals("")){
			camposObrigatorios = false;
		}
		return camposObrigatorios;
	}
	/**
	 * This method initializes jButtonCancelar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(576, 459, 109, 28));
			jButtonCancelar.setText("Cancelar");
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelCadastroTeseDoutorado.this.frame.setContentPane(new PainelPublicacoes(PainelCadastroTeseDoutorado.this.frame));
				}
			});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes jTextFieldInstituicao	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldInstituicao() {
		if (jTextFieldInstituicao == null) {
			jTextFieldInstituicao = new JTextField();
			jTextFieldInstituicao.setBounds(new Rectangle(18, 117, 361, 19));
		}
		return jTextFieldInstituicao;
	}

	/**
	 * This method initializes jComboBoxMembros	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxMembros() {
		if (jComboBoxMembros == null) {
			jComboBoxMembros = new JComboBox();
			jComboBoxMembros.setBounds(new Rectangle(18, 207, 343, 19));
			try {
				Vector<Membro> membros = this.frame.getFachada().retornaTodosMembros();
				Iterator<Membro> it = membros.iterator();
				
				while(it.hasNext()){
					Membro x = it.next();
					this.jComboBoxMembros.addItem(x.getNome());
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jComboBoxMembros;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			this.listModellinhas = new DefaultListModel();
			jListLinhas = new JList(this.listModellinhas);
			jListLinhas.setBounds(new Rectangle(18, 288, 280, 100));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaTodasLinhasDePesquisa();
				for(int i = 0; i < linhas.size(); i++){
					String linha = linhas.elementAt(i);
					this.listModellinhas.addElement(linha);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhas;
	}

	/**
	 * This method initializes jListLinhasSelecionadas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhasSelecionadas() {
		if (jListLinhasSelecionadas == null) {
			this.listModellinhasSelecionadas = new DefaultListModel();
			jListLinhasSelecionadas = new JList(this.listModellinhasSelecionadas);
			jListLinhasSelecionadas.setBounds(new Rectangle(405, 288, 280, 100));
		}
		return jListLinhasSelecionadas;
	}

	/**
	 * This method initializes jButtonSelecionaLinha	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSelecionaLinha() {
		if (jButtonSelecionaLinha == null) {
			jButtonSelecionaLinha = new JButton();
			jButtonSelecionaLinha.setBounds(new Rectangle(315, 288, 73, 37));
			jButtonSelecionaLinha.setText(">>");
			jButtonSelecionaLinha.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelCadastroTeseDoutorado.this.jListLinhas.getSelectedIndex();
					String nomeAutor = (String) PainelCadastroTeseDoutorado.this.jListLinhas.getSelectedValue();
					PainelCadastroTeseDoutorado.this.listModellinhas.removeElementAt(indice);
					PainelCadastroTeseDoutorado.this.listModellinhasSelecionadas.addElement(nomeAutor);
				}
			});
		}
		return jButtonSelecionaLinha;
	}

	/**
	 * This method initializes jButtonTiraLinha	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonTiraLinha() {
		if (jButtonTiraLinha == null) {
			jButtonTiraLinha = new JButton();
			jButtonTiraLinha.setBounds(new Rectangle(315, 351, 73, 37));
			jButtonTiraLinha.setText("<<");
			jButtonTiraLinha.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelCadastroTeseDoutorado.this.jListLinhasSelecionadas.getSelectedIndex();
					String nomeAutor = (String) PainelCadastroTeseDoutorado.this.jListLinhasSelecionadas.getSelectedValue();
					PainelCadastroTeseDoutorado.this.listModellinhasSelecionadas.removeElementAt(indice);
					PainelCadastroTeseDoutorado.this.listModellinhas.addElement(nomeAutor);
				}
			});
		}
		return jButtonTiraLinha;
	}

}  //  @jve:decl-index=0:visual-constraint="30,6"
