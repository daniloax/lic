package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JList;

import excecoes.MembroNaoEncontradoException;
import excecoes.ParametroVazioException;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.LinhaDePesquisa;
import base.Membro;
import base.Publicacao;
import base.TeseDeDoutorado;

import java.awt.Dimension;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

public class PainelBuscaGlobal extends JPanel {

	private DefaultListModel listModelResultado;
	private static final long serialVersionUID = 1L;
	private JToolBar jToolBarTeste = null;
	private JButton jButtonVoltarInicial = null;
	private FramePrincipal frame;
	private JList jListResultado = null;
	private JButton jButtonVisualizar = null;
	private JScrollPane scrollBusca = null;
	private Vector<ArtigoEmConferencia> todasPublicacoes = new Vector<ArtigoEmConferencia>();
	private Vector<LinhaDePesquisa> todasLinhasDePesquisa = new Vector<LinhaDePesquisa>();
	private Vector<Membro> todosMembros = new Vector<Membro>();
	private String termoBusca = ""; // @jve:decl-index=0:

	int tipo = 0;
	private JLabel labelResultBusca = null;

	// 1 para publica��o, 2 para LPS, 3 para membro.

	/**
	 * This is the default constructor
	 */
	public PainelBuscaGlobal(FramePrincipal frame, String termo) {

		super();
		this.frame = frame;
		this.termoBusca = termo;
		initialize();
	}

	public String getTermoBusca() {

		return this.termoBusca;
	}

	public void setTermoBusca(String termo) {

		this.termoBusca = termo;
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		labelResultBusca = new JLabel();
		labelResultBusca.setBounds(new Rectangle(278, 162, 129, 16));
		labelResultBusca.setText(" Resultado Busca ");
		labelResultBusca.setFont(new Font("Dialog", Font.BOLD, 14));
		this.setSize(723, 587);
		this.setLayout(null);
		this.add(getJToolBarTeste(), null);
		this.scrollBusca = new JScrollPane(this.jListResultado);
		this.scrollBusca.setBounds(new Rectangle(45, 197, 613, 299));
		this.scrollBusca
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollBusca.setViewportView(getjListResultado());
		this.scrollBusca.setVisible(true);
		this.add(scrollBusca);
		this.add(getJButtonVisualizar(), null);
		this.add(labelResultBusca, null);
	}

	/**
	 * This method initializes jToolBarTeste
	 * 
	 * @return javax.swing.JToolBar
	 */
	private JToolBar getJToolBarTeste() {
		if (jToolBarTeste == null) {
			jToolBarTeste = new JToolBar();
			jToolBarTeste.setBounds(new Rectangle(540, 36, 145, 19));
			jToolBarTeste.add(getJButtonVoltarInicial());
		}
		return jToolBarTeste;
	}

	/**
	 * This method initializes jButtonVoltarInicial
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar a p�gina inicial");
			jButtonVoltarInicial
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							PainelBuscaGlobal.this.frame
									.setContentPane(new PainelPrincipal(
											PainelBuscaGlobal.this.frame));
						}
					});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jListResultado
	 * 
	 * @return javax.swing.JList
	 */
	private JList getjListResultado() {
		if (jListResultado == null) {

			this.listModelResultado = new DefaultListModel();
			jListResultado = new JList(listModelResultado);

			String termo = this.getTermoBusca();

			if (!(termo.equals(""))) {

				try {

					this.todasPublicacoes = this.frame.getFachada()
							.procurarArtigoLike(termo);

					this.todasLinhasDePesquisa = this.frame.getFachada()
							.procurarLinhaDePesquisaLike(termo);

					try {
						this.todosMembros = this.frame.getFachada()
								.procurarMembroLike(termo);
					} catch (ParametroVazioException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (MembroNaoEncontradoException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}

					// preenchimento: � preciso indicar o tipo de elemento antes
					// do identificador de cada um (nome, t�tulo), porque do
					// contr�rio n�o ser� poss�vel saber onde buscar (se linha,
					// se membro, etc.).

					Iterator<ArtigoEmConferencia> itP = todasPublicacoes
							.iterator();

					while (itP.hasNext()) {

						ArtigoEmConferencia a = (ArtigoEmConferencia) itP
								.next();
						listModelResultado.addElement("Publica��o: "
								+ a.getTitulo());

					}

					Iterator<LinhaDePesquisa> itL = todasLinhasDePesquisa
							.iterator();

					while (itL.hasNext()) {

						LinhaDePesquisa l = (LinhaDePesquisa) itL.next();
						listModelResultado.addElement("Linha De Pesquisa: "
								+ l.getTitulo());

					}

					Iterator<Membro> itM = todosMembros.iterator();

					while (itM.hasNext()) {

						Membro m = (Membro) itM.next();
						listModelResultado.addElement("Membro: " + m.getNome());

					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return jListResultado;
	}

	private String identificarTipo() {

		String retorno = "";

		String valorSelecionado = (String) PainelBuscaGlobal.this.jListResultado
				.getSelectedValue();

		if (valorSelecionado.startsWith("Membro: ")) {

			retorno = valorSelecionado.substring(8);
			this.tipo = 3;

		} else if (valorSelecionado.startsWith("Linha De Pesquisa: ")) {

			retorno = valorSelecionado.substring(19);
			this.tipo = 2;

		} else if (valorSelecionado.startsWith("Publica��o: ")) {

			retorno = valorSelecionado.substring(12);
			this.tipo = 1;

		}

		return retorno;
	}

	/**
	 * This method initializes jButtonVisualizar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonVisualizar() {
		if (jButtonVisualizar == null) {
			jButtonVisualizar = new JButton();
			jButtonVisualizar.setBounds(new Rectangle(297, 504, 127, 37));
			jButtonVisualizar.setText("Visualizar");
			jButtonVisualizar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							// CHAMAR AQUI M�TODO IDENTIFICARTIPO E, A DEPENDER
							// DO TIPO, CHAMAR O M�TODO CARREGAR CORRETO.

							String valor = (String) PainelBuscaGlobal.this
									.identificarTipo();

							int tipo = PainelBuscaGlobal.this.tipo;

							if (!(valor.equals(""))) {

								if (tipo == 1) {

									PainelBuscaGlobal.this
											.carregaExibirPublicacao(valor);

								} else if (tipo == 2) {

									PainelBuscaGlobal.this
											.carregaExibirLinhaDePesquisa(valor);

								} else if (tipo == 3) {

									PainelBuscaGlobal.this
											.carregaExibirMembro(valor);
								}

							}
						}
					});
		}
		return jButtonVisualizar;
	}

	public void carregaExibirPublicacao(String tituloPublicacao) {
		try {
			String tipo = this.frame.getFachada().retornaTipoPublicacao(tituloPublicacao);

			// carrega tipo de artigo e cria painel exibir
			if (tipo.equals("artigoconferencia")) {
				ArtigoEmConferencia artigo = this.frame.getFachada()
						.buscaArtigoEmConferencia(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirArtigoDeConferencia(
						this.frame, artigo));
			} else if (tipo.equals("artigoperiodico")) {
				ArtigoEmPeriodicoERevista artigo = this.frame.getFachada()
						.buscaArtigoEmPeriodicoRevista(tituloPublicacao);
				this.frame
						.setContentPane(new PainelExibirArtigoDePeriodicoRevista(
								this.frame, artigo));
			} else if (tipo.equals("dissertacaomestrado")) {
				DissertacaoDeMestrado artigo = this.frame.getFachada()
						.buscaDissertacaoDeMestrado(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirDissertacaoMestrado(
						this.frame, artigo));
			} else if (tipo.equals("tesedoutorado")) {
				TeseDeDoutorado artigo = this.frame.getFachada()
						.buscaTeseDeDoutorado(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirTeseDoutorado(
						this.frame, artigo));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

	}

	public void carregaExibirLinhaDePesquisa(String tituloLinha) {
		try {
			// carrega linha e cria painel exibir

			LinhaDePesquisa linha = this.frame.getFachada()
					.buscaLinhaDePesquisa(tituloLinha);
			this.frame.setContentPane(new PainelExibirLinhaDePesquisa(
					this.frame, linha));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void carregaExibirMembro(String nomeMembro) {
		try {
			// carrega membro e cria painel exibir

			Membro membro = this.frame.getFachada().buscaMembro(nomeMembro);
			this.frame
					.setContentPane(new PainelExibirMembro(this.frame, membro));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

	}

} // @jve:decl-index=0:visual-constraint="14,8"

