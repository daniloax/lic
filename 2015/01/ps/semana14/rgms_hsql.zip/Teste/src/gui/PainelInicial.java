package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class PainelInicial extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel jLabelTitulo = null;
	private JPanel jPanelLogin = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JTextField jTextFieldNomeUsuario = null;
	private JPasswordField jPasswordFieldSenha = null;
	private JButton jButtonLogin = null;
	private JLabel jLabel2 = null;
	private JLabel jLabel21 = null;
	private JButton jButtonCadastro = null;
	private FramePrincipal frame = null;

	/**
	 * This is the default constructor
	 */
	public PainelInicial(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabelTitulo = new JLabel();
		jLabelTitulo.setBounds(new Rectangle(144, 45, 388, 28));
		jLabelTitulo.setText("Sistema de Gerenciamento de Grupos de Pesquisa");
		jLabelTitulo.setFont(new Font("Calibri", Font.BOLD, 18));
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabelTitulo, null);
		this.add(getJPanelLogin(), null);
	}

	/**
	 * This method initializes jPanelLogin	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelLogin() {
		if (jPanelLogin == null) {
			jLabel21 = new JLabel();
			jLabel21.setBounds(new Rectangle(9, 153, 109, 19));
			jLabel21.setText("para se cadastrar:");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(9, 135, 235, 19));
			jLabel2.setText("Caso n�o seja cadastrado, clique abaixo");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(72, 63, 46, 19));
			jLabel1.setText("Senha:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(9, 24, 112, 22));
			jLabel.setText("Nome de Usuario:");
			jPanelLogin = new JPanel();
			jPanelLogin.setLayout(null);
			jPanelLogin.setBounds(new Rectangle(198, 90, 283, 226));
			jPanelLogin.add(jLabel, null);
			jPanelLogin.add(jLabel1, null);
			jPanelLogin.add(getJTextFieldNomeUsuario(), null);
			jPanelLogin.add(getJPasswordFieldSenha(), null);
			jPanelLogin.add(getJButtonLogin(), null);
			jPanelLogin.add(jLabel2, null);
			jPanelLogin.add(jLabel21, null);
			jPanelLogin.add(getJButtonCadastro(), null);
		}
		return jPanelLogin;
	}

	/**
	 * This method initializes jTextFieldNomeUsuario	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNomeUsuario() {
		if (jTextFieldNomeUsuario == null) {
			jTextFieldNomeUsuario = new JTextField();
			jTextFieldNomeUsuario.setBounds(new Rectangle(126, 27, 154, 19));
		}
		return jTextFieldNomeUsuario;
	}

	/**
	 * This method initializes jPasswordFieldSenha	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getJPasswordFieldSenha() {
		if (jPasswordFieldSenha == null) {
			jPasswordFieldSenha = new JPasswordField();
			jPasswordFieldSenha.setBounds(new Rectangle(126, 63, 154, 19));
		}
		return jPasswordFieldSenha;
	}

	/**
	 * This method initializes jButtonLogin	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonLogin() {
		if (jButtonLogin == null) {
			jButtonLogin = new JButton();
			jButtonLogin.setBounds(new Rectangle(126, 99, 91, 28));
			jButtonLogin.setText("Login");
			jButtonLogin.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String login = PainelInicial.this.jTextFieldNomeUsuario.getText().trim().toUpperCase();
					String senha = PainelInicial.this.jPasswordFieldSenha.getText().toUpperCase();
					PainelInicial.this.frame.getMembro().setLogin(login);
					if(login.equals("")||senha.equals("")){
						JOptionPane.showMessageDialog(PainelInicial.this.frame,
							    "Dados n�o preenchidos corretamente",
							    "Aviso",
							    JOptionPane.WARNING_MESSAGE);
					}else{
					boolean r;
					try {
						r = PainelInicial.this.frame.getFachada().autenticarMembro(login, senha);
						System.out.println(r);
						if(r == true){
						PainelInicial.this.frame.setContentPane(new PainelPrincipal(PainelInicial.this.frame) );
					}else{
						JOptionPane.showMessageDialog(PainelInicial.this.frame,
							    "Usu�rio n�o cadastrado.",
							    "Inane error",
							    JOptionPane.ERROR_MESSAGE);

					}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
						}
				}
			});
		}
		return jButtonLogin;
	}

	/**
	 * This method initializes jButtonCadastro	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastro() {
		if (jButtonCadastro == null) {
			jButtonCadastro = new JButton();
			jButtonCadastro.setBounds(new Rectangle(126, 180, 91, 28));
			jButtonCadastro.setText("Cadastro");
			jButtonCadastro.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelInicial.this.frame.setContentPane(new PainelCadastroMembro(PainelInicial.this.frame));
						}
			});
		}
		return jButtonCadastro;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
