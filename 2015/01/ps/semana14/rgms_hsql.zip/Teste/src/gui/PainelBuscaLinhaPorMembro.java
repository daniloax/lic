package gui;

import java.awt.GridBagLayout;

import javax.print.DocFlavor.STRING;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.LinhaDePesquisa;
import base.Membro;
import base.TeseDeDoutorado;

import java.awt.Point;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

public class PainelBuscaLinhaPorMembro extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JToolBar jToolBarTeste = null;
	private JButton jButtonVoltarInicial = null;
	private FramePrincipal frame ;
	private JLabel jLabel1 = null;
	private DefaultListModel listModelMembros;
	private DefaultListModel listModelMembrosSelecionados;
	private DefaultListModel listModelResultadoBusca;
	private JButton jButtonSeleciona = null;
	private JButton jButtonTiraMembro = null;
	private JList jListMembros = null;
	private JList jListMembrosSelecionados = null;
	private JButton jButtonBuscar = null;
	private JLabel jLabel11 = null;
	private JList jListResultado = null;
	private JButton jButtonVisualizar = null;
	private JScrollPane scrollMembros = null;
	private JScrollPane scrollMembrosSelecionados = null;
	private JScrollPane scrollResultadoBusca = null;
	
	/**
	 * This is the default constructor
	 */
	public PainelBuscaLinhaPorMembro(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel11 = new JLabel();
		jLabel11.setBounds(new Rectangle(288, 333, 154, 19));
		jLabel11.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel11.setText("Resultado da Busca:");
		
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(234, 126, 262, 19));
		jLabel1.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel1.setText("Selecione os membros para a busca:");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(180, 63, 379, 36));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 18));
		jLabel.setText("Busca de Linhas de Pesquisa por Membros");
		this.setSize(723, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(getJToolBarTeste(), null);
		this.add(jLabel1, null);
		this.add(getJButtonSeleciona(), null);
		this.add(getJButtonTiraMembro(), null);
		this.add(getJListMembros(), null);
		this.scrollMembros = new JScrollPane(this.jListMembros);
		this.scrollMembros.setBounds(new Rectangle(9, 171, 244, 118));
		this.scrollMembros.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollMembros.setVisible(true);
		this.add(scrollMembros);
		
		this.add(getJListMembrosSelecionados(), null);
		this.scrollMembrosSelecionados = new JScrollPane(this.jListMembrosSelecionados);
		this.scrollMembrosSelecionados.setBounds(new Rectangle(333, 171, 244, 118));
		this.scrollMembrosSelecionados.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollMembrosSelecionados.setVisible(true);
		this.add(scrollMembrosSelecionados);
		
		this.add(getJButtonBuscar(), null);
		this.add(jLabel11, null);
		this.add(getJListResultado(), null);
		this.scrollResultadoBusca = new JScrollPane(this.jListResultado);
		this.scrollResultadoBusca.setBounds(new Rectangle(90, 360, 514, 136));
		this.scrollResultadoBusca.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollResultadoBusca.setVisible(true);
		this.add(scrollResultadoBusca);
		this.add(getJButtonVisualizar(), null);
	}

	/**
	 * This method initializes jToolBarTeste	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarTeste() {
		if (jToolBarTeste == null) {
			jToolBarTeste = new JToolBar();
			jToolBarTeste.setBounds(new Rectangle(621, 36, 64, 19));
			jToolBarTeste.add(getJButtonVoltarInicial());
		}
		return jToolBarTeste;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelBuscaLinhaPorMembro.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelBuscaLinhaPorMembro.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jButtonSeleciona	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSeleciona() {
		if (jButtonSeleciona == null) {
			jButtonSeleciona = new JButton();
			jButtonSeleciona.setBounds(new Rectangle(261, 171, 64, 28));
			jButtonSeleciona.setText(">>");
			jButtonSeleciona.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelBuscaLinhaPorMembro.this.jListMembros.getSelectedIndex();
					String nomeAutor = (String) PainelBuscaLinhaPorMembro.this.jListMembros.getSelectedValue();
					PainelBuscaLinhaPorMembro.this.listModelMembros.removeElementAt(indice);
					PainelBuscaLinhaPorMembro.this.listModelMembrosSelecionados.addElement(nomeAutor);
				}
			});
		}
		return jButtonSeleciona;
	}

	/**
	 * This method initializes jButtonTiraMembro	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonTiraMembro() {
		if (jButtonTiraMembro == null) {
			jButtonTiraMembro = new JButton();
			jButtonTiraMembro.setBounds(new Rectangle(261, 261, 64, 28));
			jButtonTiraMembro.setText("<<");
			jButtonTiraMembro.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelBuscaLinhaPorMembro.this.jListMembrosSelecionados.getSelectedIndex();
					String nomeAutor = (String) PainelBuscaLinhaPorMembro.this.jListMembrosSelecionados.getSelectedValue();
					PainelBuscaLinhaPorMembro.this.listModelMembrosSelecionados.removeElementAt(indice);
					PainelBuscaLinhaPorMembro.this.listModelMembros.addElement(nomeAutor);
				}
			});
		}
		return jButtonTiraMembro;
	}

	/**
	 * This method initializes jListMembros	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListMembros() {
		if (jListMembros == null) {
			this.listModelMembros = new DefaultListModel();
			jListMembros = new JList(this.listModelMembros);
			jListMembros.setBounds(new Rectangle(9, 171, 244, 118));
			
			try {
				Vector<Membro> membro = this.frame.getFachada().retornaTodosMembros();
				Iterator<Membro> it = membro.iterator();
				while(it.hasNext()){
					String nome = it.next().getNome();
					this.listModelMembros.addElement(nome);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListMembros;
	}

	/**
	 * This method initializes jListMembrosSelecionados	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListMembrosSelecionados() {
		if (jListMembrosSelecionados == null) {
			this.listModelMembrosSelecionados = new DefaultListModel();
			jListMembrosSelecionados = new JList(this.listModelMembrosSelecionados);
			jListMembrosSelecionados.setBounds(new Rectangle(333, 171, 244, 118));
		}
		return jListMembrosSelecionados;
	}

	/**
	 * This method initializes jButtonBuscar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBuscar() {
		if (jButtonBuscar == null) {
			jButtonBuscar = new JButton();
			jButtonBuscar.setBounds(new Rectangle(585, 198, 109, 55));
			jButtonBuscar.setText("Buscar");
			jButtonBuscar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelBuscaLinhaPorMembro.this.listModelResultadoBusca.clear();
					Vector<String> autores = new Vector();
					int tamanho = PainelBuscaLinhaPorMembro.this.listModelMembrosSelecionados.getSize();
					for(int i = 0 ; i < tamanho ; i++){
						String autor = (String)PainelBuscaLinhaPorMembro.this.listModelMembrosSelecionados.elementAt(i);
						autores.add(autor);
					}
					try {
						//TO DO modificar aqui
						Vector<String> titulos = PainelBuscaLinhaPorMembro.this.frame.getFachada().buscaLinhaPorMembro(autores);
						Iterator<String> it = titulos.iterator();
						while(it.hasNext()){
							String x = it.next();
							PainelBuscaLinhaPorMembro.this.listModelResultadoBusca.addElement(x);
						}
						
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
		}
		return jButtonBuscar;
	}

	/**
	 * This method initializes jListResultado	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListResultado() {
		if (jListResultado == null) {
			this.listModelResultadoBusca = new DefaultListModel();
			jListResultado = new JList(this.listModelResultadoBusca);
			jListResultado.setBounds(new Rectangle(90, 360, 514, 136));
		}
		return jListResultado;
	}

	/**
	 * This method initializes jButtonVisualizar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVisualizar() {
		if (jButtonVisualizar == null) {
			jButtonVisualizar = new JButton();
			jButtonVisualizar.setBounds(new Rectangle(288, 504, 163, 37));
			jButtonVisualizar.setText("Visualizar");
			jButtonVisualizar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String titulo = (String)PainelBuscaLinhaPorMembro.this.jListResultado.getSelectedValue();
					if(!(titulo.equals(""))){
						LinhaDePesquisa linha;
						try {
							linha = PainelBuscaLinhaPorMembro.this.frame.getFachada().buscaLinhaDePesquisa(titulo);
							PainelBuscaLinhaPorMembro.this.frame.setContentPane(new PainelExibirLinhaDePesquisa(PainelBuscaLinhaPorMembro.this.frame , linha));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						
					}
				}
			});
		}
		return jButtonVisualizar;
	}
	
	public void carregaExibirPublicacao(String tituloPublicacao){
		try {
			String tipo = this.frame.getFachada().retornaTipoPublicacao(tituloPublicacao);
			
			//carrega tipo de artigo e cria painel exibir
			if(tipo.equals("artigoconferencia")){
				ArtigoEmConferencia artigo = this.frame.getFachada().buscaArtigoEmConferencia(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirArtigoDeConferencia(this.frame, artigo));
			}else if(tipo.equals("artigoperiodico")){
				ArtigoEmPeriodicoERevista artigo = this.frame.getFachada().buscaArtigoEmPeriodicoRevista(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirArtigoDePeriodicoRevista(this.frame, artigo));
			}else if(tipo.equals("dissertacaomestrado")){
				DissertacaoDeMestrado artigo = this.frame.getFachada().buscaDissertacaoDeMestrado(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirDissertacaoMestrado(this.frame, artigo));
			}else if(tipo.equals("tesedoutorado")){
				TeseDeDoutorado artigo = this.frame.getFachada().buscaTeseDeDoutorado(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirTeseDoutorado(this.frame, artigo));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
	}

}  //  @jve:decl-index=0:visual-constraint="-10,43"
