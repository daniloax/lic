package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import excecoes.ObjetoVazioException;
import excecoes.ParametroVazioException;
import excecoes.PublicacaoJaExistenteException;
import excecoes.PublicacaoNaoEncontradaException;

import base.ArtigoEmConferencia;
import base.DissertacaoDeMestrado;
import base.Membro;
import javax.swing.JComboBox;

public class PainelEditarDissertacaoMestrado extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private FramePrincipal frame;
	private JLabel labelTitulo = null;
	private JTextField jTextFieldTitulo = null;
	private JLabel labelAno = null;
	private JTextField jTextFieldUrlPdf = null;
	private JButton jButtonCarregaPdf = null;
	private JTextField jTextFieldAno = null;
	private JLabel labelAno1 = null;
	private JTextField jTextFieldMes = null;
	private JLabel labelAno2 = null;
	private JButton jButtonCadastrar = null;
	private JButton jButtonCancelar = null;
	private Vector<Membro> membros = new Vector<Membro>();
	private Vector<Membro> autores = new Vector<Membro>();  //  @jve:decl-index=0:
	private Vector<Membro> autoresSelecionados = new Vector();  //  @jve:decl-index=0:
	private DissertacaoDeMestrado artigo = new DissertacaoDeMestrado();  //  @jve:decl-index=0:
	private JLabel labelTitulo1 = null;
	private JTextField jTextFieldInstituicao = null;
	private JComboBox jComboBoxMembros = null;
	private JLabel jLabel1 = null;
	private JList jListLinhas = null;
	private JList jListLinhasSelecionadas = null;
	private JButton jButtonSelecionaLinha = null;
	private JButton jButtonTiraLinha = null;
	private DefaultListModel listModelLinhas;
	private DefaultListModel listModelLinhasSelecionadas;
	private JScrollPane scrollLinhas ;
	private JScrollPane scrollLinhasSelecionadas ;
	/**
	 * This is the default constructor
	 */
	public PainelEditarDissertacaoMestrado(FramePrincipal frame, DissertacaoDeMestrado artigo) {
		super();
		this.frame = frame;
		this.artigo = artigo;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(18, 342, 199, 19));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(18, 126, 73, 19));
		labelTitulo1.setText("Institui��o:*");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 252, 73, 19));
		labelAno2.setText("Mestrando:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(117, 189, 46, 19));
		labelAno1.setText("M�s:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(18, 189, 46, 19));
		labelAno.setText(" Ano: *");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 63, 118, 19));
		labelTitulo.setText("Titulo disserta��o: *");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 271, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText("Edi��o de disserta��o de mestrado:");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(getJTextFieldTitulo(), null);
		this.add(labelAno, null);
		this.add(getJTextFieldUrlPdf(), null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(getJTextFieldAno(), null);
		this.add(labelAno1, null);
		this.add(getJTextFieldMes(), null);
		this.add(labelAno2, null);
		
		
		this.add(getJButtonCadastrar(), null);
		this.add(getJButtonCancelar(), null);
		this.add(labelTitulo1, null);
		this.add(getJTextFieldInstituicao(), null);
		this.add(getJComboBoxMembros(), null);
		this.add(jLabel1, null);
		this.add(getJListLinhasSelecionadas(), null);
		this.scrollLinhasSelecionadas = new JScrollPane(this.jListLinhasSelecionadas);
		this.scrollLinhasSelecionadas.setBounds(new Rectangle(414, 360, 280, 82));
		this.scrollLinhasSelecionadas.setVisible(true);
		this.add(scrollLinhasSelecionadas);
		
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 360, 280, 82));
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		
		this.add(getJButtonSelecionaLinha(), null);
		this.add(getJButtonTiraLinha(), null);
	}

	/**
	 * This method initializes jTextFieldTitulo	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldTitulo() {
		if (jTextFieldTitulo == null) {
			jTextFieldTitulo = new JTextField();
			jTextFieldTitulo.setBounds(new Rectangle(18, 90, 361, 19));
			jTextFieldTitulo.setText(this.artigo.getTitulo());
		}
		return jTextFieldTitulo;
	}

	/**
	 * This method initializes jTextFieldUrlPdf	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldUrlPdf() {
		if (jTextFieldUrlPdf == null) {
			jTextFieldUrlPdf = new JTextField();
			jTextFieldUrlPdf.setBounds(new Rectangle(18, 315, 208, 19));
		}
		return jTextFieldUrlPdf;
	}

	/**
	 * This method initializes jButtonCarregaPdf	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(243, 315, 154, 19));
			jButtonCarregaPdf.setText("Carregar arquivo pdf");
			jButtonCarregaPdf.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelEditarDissertacaoMestrado.this.carregaPdf();
				}
			});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf(){
		JFileChooser arquivo = new JFileChooser();
		int returnVal = arquivo.showOpenDialog(this);
		
		if(returnVal == JFileChooser.APPROVE_OPTION){
			File arq = arquivo.getSelectedFile();
			this.jTextFieldUrlPdf.setText(arq.getAbsolutePath());
			this.artigo.setUrlPdf(arq.getAbsolutePath().trim().toUpperCase());
			
		}
	}
	/**
	 * This method initializes jTextFieldAno	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAno() {
		if (jTextFieldAno == null) {
			jTextFieldAno = new JTextField();
			jTextFieldAno.setBounds(new Rectangle(18, 216, 64, 19));
			jTextFieldAno.setText(this.artigo.getAno());
		}
		return jTextFieldAno;
	}

	/**
	 * This method initializes jTextFieldMes	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldMes() {
		if (jTextFieldMes == null) {
			jTextFieldMes = new JTextField();
			jTextFieldMes.setBounds(new Rectangle(117, 216, 91, 19));
			jTextFieldMes.setText(this.artigo.getMes());
		}
		return jTextFieldMes;
	}

	/**
	 * This method initializes jListAutores	
	 * 	
	 * @return javax.swing.JList	
	 */
	

	/**
	 * This method initializes jButtonCadastrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastrar() {
		if (jButtonCadastrar == null) {
			jButtonCadastrar = new JButton();
			jButtonCadastrar.setBounds(new Rectangle(441, 459, 109, 28));
			jButtonCadastrar.setText("Salvar");
			jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					boolean camposObrigatorios = PainelEditarDissertacaoMestrado.this.carregaDissertacao();
					if(camposObrigatorios == true){
						try {
							PainelEditarDissertacaoMestrado.this.frame.getFachada().editarDissertacaoDeMestrado(PainelEditarDissertacaoMestrado.this.artigo);
							JOptionPane.showMessageDialog(null,
									"Artigo atualizado!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);
							PainelEditarDissertacaoMestrado.this.frame.setContentPane(new PainelPublicacoes(PainelEditarDissertacaoMestrado.this.frame));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ObjetoVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ParametroVazioException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						} catch (PublicacaoNaoEncontradaException e3) {
							// TODO Auto-generated catch block
							e3.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(null,
								"Campos obrigat�rios n�o preenchidos", "INFORMA��O",
								JOptionPane.WARNING_MESSAGE);
					}
				}
			});
		}
		return jButtonCadastrar;
	}
	
	public boolean carregaDissertacao(){
		boolean camposObrigatorios = true;
		String titulo = this.jTextFieldTitulo.getText().trim().toUpperCase();
		this.artigo.setTitulo(titulo);
		String instituicao = this.jTextFieldInstituicao.getText().trim().toUpperCase();
		this.artigo.setInstituicao(instituicao);
		String ano = this.jTextFieldAno.getText().trim().toUpperCase();
		this.artigo.setAno(ano);
		String mes = this.jTextFieldMes.getText().trim().toUpperCase();
		this.artigo.setMes(mes);
		String autor = (String) this.jComboBoxMembros.getSelectedItem();
		this.artigo.setAutoresMembros(autor);
		//LINHASDEPESQUISA
		
		Vector<String> linhas = new Vector<String>();
		for(int i = 0; i < this.listModelLinhasSelecionadas.size(); i++){
			String linha = (String) this.listModelLinhasSelecionadas.elementAt(i);
			linhas.add(linha);
		}
		this.artigo.setLinhasDePesquisa(linhas);
		//LINHASDEPESQUISA
		if(titulo.equals("") || ano.equals("") || autor.equals("")){
			camposObrigatorios = false;
		}
		return camposObrigatorios;
	}
	/**
	 * This method initializes jButtonCancelar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(576, 459, 109, 28));
			jButtonCancelar.setText("Cancelar");
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelEditarDissertacaoMestrado.this.frame.setContentPane(new PainelPublicacoes(PainelEditarDissertacaoMestrado.this.frame));
				}
			});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes jTextFieldInstituicao	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldInstituicao() {
		if (jTextFieldInstituicao == null) {
			jTextFieldInstituicao = new JTextField();
			jTextFieldInstituicao.setBounds(new Rectangle(18, 153, 361, 19));
			jTextFieldInstituicao.setText(this.artigo.getInstituicao());
		}
		return jTextFieldInstituicao;
	}

	/**
	 * This method initializes jComboBoxMembros	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxMembros() {
		if (jComboBoxMembros == null) {
			jComboBoxMembros = new JComboBox();
			jComboBoxMembros.setBounds(new Rectangle(18, 279, 343, 19));
			try {
				Vector<Membro> membros = this.frame.getFachada().retornaTodosMembros();
				Iterator<Membro> it = membros.iterator();
				
				while(it.hasNext()){
					Membro x = it.next();
					this.jComboBoxMembros.addItem(x.getNome());
					
				}
				
				//this.jComboBoxMembros.setSelectedItem(arg0);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jComboBoxMembros;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			this.listModelLinhas = new DefaultListModel();
			jListLinhas = new JList(this.listModelLinhas );
			jListLinhas.setBounds(new Rectangle(18, 360, 280, 82));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaTodasLinhasDePesquisa();
				Iterator<String> it = linhas.iterator();
				while(it.hasNext()){
					String x = it.next();
					boolean achou = false;
					int i = 0;
					while(i < this.listModelLinhasSelecionadas.getSize() && !achou){
						if(x.equals(this.listModelLinhasSelecionadas.elementAt(i))){
							achou = true;
						}
					
						i++;
					}
					if(!achou){
						this.listModelLinhas.addElement(x);
					}
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhas;
	}

	/**
	 * This method initializes jListLinhasSelecionadas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhasSelecionadas() {
		if (jListLinhasSelecionadas == null) {
			this.listModelLinhasSelecionadas = new DefaultListModel();
			jListLinhasSelecionadas = new JList(this.listModelLinhasSelecionadas);
			jListLinhasSelecionadas.setBounds(new Rectangle(414, 360, 280, 82));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmaPublicacao(this.artigo.getTitulo());
				for(int i = 0; i < linhas.size(); i++){
					String linha = linhas.elementAt(i);
					this.listModelLinhasSelecionadas.addElement(linha);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhasSelecionadas;
	}

	/**
	 * This method initializes jButtonSelecionaLinha	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSelecionaLinha() {
		if (jButtonSelecionaLinha == null) {
			jButtonSelecionaLinha = new JButton();
			jButtonSelecionaLinha.setBounds(new Rectangle(324, 360, 64, 37));
			jButtonSelecionaLinha.setText(">>");
			jButtonSelecionaLinha.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String linha = (String)PainelEditarDissertacaoMestrado.this.jListLinhas.getSelectedValue();
					int indice = PainelEditarDissertacaoMestrado.this.jListLinhas.getSelectedIndex();
					PainelEditarDissertacaoMestrado.this.listModelLinhas.removeElementAt(indice);
					PainelEditarDissertacaoMestrado.this.listModelLinhasSelecionadas.addElement(linha);
				}
			});
		}
		return jButtonSelecionaLinha;
	}

	/**
	 * This method initializes jButtonTiraLinha	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonTiraLinha() {
		if (jButtonTiraLinha == null) {
			jButtonTiraLinha = new JButton();
			jButtonTiraLinha.setBounds(new Rectangle(324, 405, 64, 37));
			jButtonTiraLinha.setText("<<");
			jButtonTiraLinha.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String linha = (String)PainelEditarDissertacaoMestrado.this.jListLinhasSelecionadas.getSelectedValue();
					int indice = PainelEditarDissertacaoMestrado.this.jListLinhasSelecionadas.getSelectedIndex();
					PainelEditarDissertacaoMestrado.this.listModelLinhasSelecionadas.removeElementAt(indice);
					PainelEditarDissertacaoMestrado.this.listModelLinhas.addElement(linha);
				}
			});
		}
		return jButtonTiraLinha;
	}

}  //  @jve:decl-index=0:visual-constraint="30,6"
