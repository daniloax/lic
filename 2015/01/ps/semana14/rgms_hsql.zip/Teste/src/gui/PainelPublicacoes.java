package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.Publicacao;
import base.TeseDeDoutorado;

import java.awt.Dimension;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

public class PainelPublicacoes extends JPanel {
	
	private DefaultListModel listaPublicacoes;
	private static final long serialVersionUID = 1L;
	private JToolBar jToolBarTeste = null;
	private JButton jButtonVoltarInicial = null;
	public FramePrincipal frame;
	private JLabel jLabelTitulo1 = null;
	private JComboBox jComboBoxTipoPublicacao = null;
	private JButton jButtonCadastrar = null;
	private JTextField jTextFieldBusca = null;
	private JButton jButtonBuscar = null;
	private JLabel jLabel1 = null;
	private JList jListPublicacoes = null;
	private JButton jButtonVisualizar = null;
	private JScrollPane scrollBusca = null;
	private Vector<ArtigoEmConferencia> todasPublicacoes;
	
	//private JPanel jPanelTeste = null;
	
	/**
	 * This is the default constructor
	 */
	public PainelPublicacoes(FramePrincipal frame) {
		
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(234, 270, 190, 28));
		jLabel1.setFont(new Font("Dialog", Font.BOLD, 18));
		jLabel1.setText("Filtro de Publica��es:");
		jLabelTitulo1 = new JLabel();
		jLabelTitulo1.setBounds(new Rectangle(18, 90, 316, 19));
		jLabelTitulo1.setText("Selecione o tipo de publica��o que deseja cadastrar:");
		jLabelTitulo1.setFont(new Font("Calibri", Font.BOLD, 14));
		this.setSize(723, 587);
		this.setLayout(null);
		this.add(getJToolBarTeste(), null);
		this.add(jLabelTitulo1, null);
		this.add(getJComboBoxTipoPublicacao(), null);
		this.add(getJButtonCadastrar(), null);
		this.add(getJTextFieldBusca(), null);
		
		this.add(getJButtonBuscar(), null);
		this.add(jLabel1, null);
		this.scrollBusca = new JScrollPane(this.jListPublicacoes);
		this.scrollBusca.setBounds(new Rectangle(45, 342, 613, 154));
		this.scrollBusca.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		scrollBusca.setViewportView(getJListPublicacoes());
		this.scrollBusca.setVisible(true);
		this.add(scrollBusca);
		this.add(getJButtonVisualizar(), null);
	
		//this.add(getJPanelTeste(), null);
		
	}

	/**
	 * This method initializes jToolBarTeste	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarTeste() {
		if (jToolBarTeste == null) {
			jToolBarTeste = new JToolBar();
			jToolBarTeste.setBounds(new Rectangle(540, 36, 145, 19));
			jToolBarTeste.add(getJButtonVoltarInicial());
		}
		return jToolBarTeste;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar a p�gina inicial");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelPublicacoes.this.frame.setContentPane(new PainelPrincipal(PainelPublicacoes.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jComboBoxTipoPublicacao	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxTipoPublicacao() {
		if (jComboBoxTipoPublicacao == null) {
			jComboBoxTipoPublicacao = new JComboBox();
			jComboBoxTipoPublicacao.setBounds(new Rectangle(45, 117, 226, 28));
			jComboBoxTipoPublicacao.addItem("Artigo em confer�ncia");
			jComboBoxTipoPublicacao.addItem("Artigo em peri�dico/revista");
			jComboBoxTipoPublicacao.addItem("Disserta��o de mestrado");
			jComboBoxTipoPublicacao.addItem("Tese de doutorado");
		}
		return jComboBoxTipoPublicacao;
	}

	/**
	 * This method initializes jButtonCadastrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastrar() {
		if (jButtonCadastrar == null) {
			jButtonCadastrar = new JButton();
			jButtonCadastrar.setBounds(new Rectangle(81, 153, 136, 28));
			jButtonCadastrar.setText("Cadastrar");
			jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String tipo = jComboBoxTipoPublicacao.getSelectedItem().toString().trim();
					
					if(tipo.equals("Artigo em confer�ncia")){
						PainelPublicacoes.this.frame.setContentPane(new PainelCadastroArtigoConferencia(PainelPublicacoes.this.frame));
					}else if(tipo.equals("Artigo em peri�dico/revista")){
						PainelPublicacoes.this.frame.setContentPane(new PainelCadastroArtigoPeriodicoRevista(PainelPublicacoes.this.frame));
					}else if(tipo.equals("Disserta��o de mestrado")){
						PainelPublicacoes.this.frame.setContentPane(new PainelCadastroDissertacaoMestrado(PainelPublicacoes.this.frame));
					}else if(tipo.equals("Tese de doutorado")){
						PainelPublicacoes.this.frame.setContentPane(new PainelCadastroTeseDoutorado(PainelPublicacoes.this.frame));
					}
					
				}
			});
		}
		return jButtonCadastrar;
	}

	/**
	 * This method initializes jTextFieldBusca	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldBusca() {
		if (jTextFieldBusca == null) {
			jTextFieldBusca = new JTextField();
			jTextFieldBusca.setBounds(new Rectangle(45, 306, 451, 28));
		}
		return jTextFieldBusca;
	}

	/**
	 * This method initializes jButtonBuscar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBuscar() {
		if (jButtonBuscar == null) {
			jButtonBuscar = new JButton();
			jButtonBuscar.setBounds(new Rectangle(513, 306, 145, 28));
			jButtonBuscar.setText("Buscar Publica��o");
			jButtonBuscar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String busca = PainelPublicacoes.this.jTextFieldBusca.getText().trim().toUpperCase();
					if(!(busca.equals(""))){
						try {
							Vector<ArtigoEmConferencia> artigos = PainelPublicacoes.this.frame.getFachada().procurarArtigoLike(busca);
							Iterator<ArtigoEmConferencia> it = artigos.iterator();
							PainelPublicacoes.this.listaPublicacoes.clear();
							while(it.hasNext()){
								String titulo = it.next().getTitulo();
								PainelPublicacoes.this.listaPublicacoes.addElement(titulo);
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(PainelPublicacoes.this,
							    "Campo de busca n�o preenchido",
							    "Aviso",
							    JOptionPane.WARNING_MESSAGE);
					}
				}
			});
		}
		return jButtonBuscar;
	}

	/**
	 * This method initializes jListPublicacoes	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListPublicacoes() {
		if (jListPublicacoes == null) {

			this.listaPublicacoes = new DefaultListModel();
			jListPublicacoes = new JList(listaPublicacoes);
			
			try {
				this.todasPublicacoes = this.frame.getFachada().retornaTodasPublicacoes();
				Iterator<ArtigoEmConferencia> it = todasPublicacoes.iterator();
				while(it.hasNext()){
					ArtigoEmConferencia x = (ArtigoEmConferencia) it.next();
					listaPublicacoes.addElement(x.getTitulo());
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListPublicacoes;
	}

	/**
	 * This method initializes jButtonVisualizar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVisualizar() {
		if (jButtonVisualizar == null) {
			jButtonVisualizar = new JButton();
			jButtonVisualizar.setBounds(new Rectangle(297, 504, 127, 37));
			jButtonVisualizar.setText("Visualizar");
			jButtonVisualizar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String titulo = (String)PainelPublicacoes.this.jListPublicacoes.getSelectedValue();
					if(!(titulo.equals(""))){
					PainelPublicacoes.this.carregaExibirPublicacao(titulo);
					}
				}
			});
		}
		return jButtonVisualizar;
	}
	
	public void carregaExibirPublicacao(String tituloPublicacao){
		try {
			String tipo = this.frame.getFachada().retornaTipoPublicacao(tituloPublicacao);
			
			//carrega tipo de artigo e cria painel exibir
			if(tipo.equals("artigoconferencia")){
				ArtigoEmConferencia artigo = this.frame.getFachada().buscaArtigoEmConferencia(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirArtigoDeConferencia(this.frame, artigo));
			}else if(tipo.equals("artigoperiodico")){
				ArtigoEmPeriodicoERevista artigo = this.frame.getFachada().buscaArtigoEmPeriodicoRevista(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirArtigoDePeriodicoRevista(this.frame, artigo));
			}else if(tipo.equals("dissertacaomestrado")){
				DissertacaoDeMestrado artigo = this.frame.getFachada().buscaDissertacaoDeMestrado(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirDissertacaoMestrado(this.frame, artigo));
			}else if(tipo.equals("tesedoutorado")){
				TeseDeDoutorado artigo = this.frame.getFachada().buscaTeseDeDoutorado(tituloPublicacao);
				this.frame.setContentPane(new PainelExibirTeseDoutorado(this.frame, artigo));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
	}

	

	

	/**
	 * This method initializes jButtonGerarListas	
	 * 	
	 * @return javax.swing.JButton	
	 */
	

}  //  @jve:decl-index=0:visual-constraint="14,8"
