package gui;

import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JPanel;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Rectangle;
import java.awt.Font;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

import base.Membro;
import fachada.*;
public class FramePrincipal  extends JFrame{
	
	private Membro membro;  //  @jve:decl-index=0:
	

	private JPanel jPainelPrincipal = null;
	private JMenuBar jJMenuBar = null;
	private JMenu jMenu = null;
	private JMenuItem Login = null;
	private JLabel jLabelTitulo = null;
	private JMenuItem jMenuItemSair = null;
	private JTextField jTextFieldNomeUsuario = null;
	private JLabel jLabel1 = null;
	private JPasswordField jPasswordFieldSenha = null;
	private JButton jButtonLogin = null;
	private JPanel jPanelLogin = null;
	private JLabel jLabel = null;
	private JLabel jLabel2 = null;
	private JLabel jLabel21 = null;
	private JButton jButtonCadastro = null;
	private Fachada fachada = new Fachada();  //  @jve:decl-index=0:
	private JMenuItem jMenuItemDeslogar = null;
	
	public Membro getMembro() {
		return membro;
	}

	public void setMembro(Membro membro) {
		this.membro = membro;
	}
	
	public Fachada getFachada() {
		return fachada;
	}

	public void setFachada(Fachada fachada) {
		this.membro = new Membro();
		this.fachada = fachada;
	}

	/**
	 * This method initializes 
	 * 
	 */
	public FramePrincipal() {
		super();
		this.membro = new Membro();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 */
	private void initialize() {
        this.setSize(new Dimension(723, 587));
        this.setPreferredSize(new Dimension(710, 376));
        this.setJMenuBar(getJJMenuBar());
        this.setContentPane(getJPainelPrincipal());
        this.setTitle("Sistema Para Gerenciamento de Grupos de Pesquisa");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
			
	}

	/**
	 * This method initializes jPainelPrincipal	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPainelPrincipal() {
		if (jPainelPrincipal == null) {
			jLabel1 = new JLabel();
			jLabel1.setText("Senha:");
			jLabel1.setBounds(new Rectangle(72, 63, 46, 19));
			jLabelTitulo = new JLabel();
			jLabelTitulo.setBounds(new Rectangle(144, 18, 388, 28));
			jLabelTitulo.setFont(new Font("Calibri", Font.BOLD, 18));
			jLabelTitulo.setText("Sistema de Gerenciamento de Grupos de Pesquisa");
			jPainelPrincipal = new JPanel();
			jPainelPrincipal.setLayout(null);
			jPainelPrincipal.add(jLabelTitulo, null);
			jPainelPrincipal.add(getJPanelLogin(), null);
			
		}
		return jPainelPrincipal;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			//JMenuBar.add(getJMenuArquivo());
			jJMenuBar.add(getJMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenu() {
		if (jMenu == null) {
			jMenu = new JMenu();
			jMenu.setText("Arquivo");
			jMenu.add(getJMenuItemSair());
			jMenu.add(getJMenuItemDeslogar());
			
		}
		return jMenu;
	}



	/**
	 * This method initializes jTextFieldNomeUsuario	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNomeUsuario() {
		if (jTextFieldNomeUsuario == null) {
			jTextFieldNomeUsuario = new JTextField();
			jTextFieldNomeUsuario.setBounds(new Rectangle(126, 27, 154, 19));
		}
		return jTextFieldNomeUsuario;
	}

	/**
	 * This method initializes jPasswordFieldSenha	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getJPasswordFieldSenha() {
		if (jPasswordFieldSenha == null) {
			jPasswordFieldSenha = new JPasswordField();
			jPasswordFieldSenha.setBounds(new Rectangle(126, 63, 154, 19));
		}
		return jPasswordFieldSenha;
	}

	/**
	 * This method initializes jButtonLogin	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonLogin() {
		if (jButtonLogin == null) {
			jButtonLogin = new JButton();
			jButtonLogin.setText("Login");
			jButtonLogin.setBounds(new Rectangle(126, 99, 91, 28));
			jButtonLogin.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String login = FramePrincipal.this.jTextFieldNomeUsuario.getText().trim().toUpperCase();
					String senha = FramePrincipal.this.jPasswordFieldSenha.getText().toUpperCase();
					
					FramePrincipal.this.getMembro().setLogin(login);
					if(login.equals("")||senha.equals("")){
					JOptionPane.showMessageDialog(FramePrincipal.this,
						    "Dados n�o preenchidos corretamente",
						    "Aviso",
						    JOptionPane.WARNING_MESSAGE);
					
					}else{
						
					
					try {
						boolean r = FramePrincipal.this.fachada.autenticarMembro(login, senha);
						System.out.println(r);
						if(r == true){
							FramePrincipal.this.setContentPane(new PainelPrincipal(FramePrincipal.this) );
						}else{
							JOptionPane.showMessageDialog(FramePrincipal.this,
								    "Usu�rio n�o cadastrado.",
								    "Inane error",
								    JOptionPane.ERROR_MESSAGE);

						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
				}
				}
			});
		}
		return jButtonLogin;
	}

	/**
	 * This method initializes jPanelLogin	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelLogin() {
		if (jPanelLogin == null) {
			jLabel21 = new JLabel();
			jLabel21.setBounds(new Rectangle(9, 153, 109, 19));
			jLabel21.setText("para se cadastrar:");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(9, 135, 235, 19));
			jLabel2.setText("Caso n�o seja cadastrado, clique abaixo");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(9, 24, 112, 22));
			jLabel.setText("Nome de Usuario:");
			jPanelLogin = new JPanel();
			jPanelLogin.setLayout(null);
			jPanelLogin.setBounds(new Rectangle(198, 63, 283, 226));
			jPanelLogin.add(jLabel, null);
			jPanelLogin.add(jLabel1, null);
			jPanelLogin.add(getJTextFieldNomeUsuario(), null);
			jPanelLogin.add(getJPasswordFieldSenha(), null);
			jPanelLogin.add(getJButtonLogin(), null);
			jPanelLogin.add(jLabel2, null);
			jPanelLogin.add(jLabel21, null);
			jPanelLogin.add(getJButtonCadastro(), null);
		}
		return jPanelLogin;
	}

	/**
	 * This method initializes jButtonCadastro	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastro() {
		if (jButtonCadastro == null) {
			jButtonCadastro = new JButton();
			jButtonCadastro.setBounds(new Rectangle(126, 180, 91, 28));
			jButtonCadastro.setText("Cadastro");
			
			jButtonCadastro.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					FramePrincipal.this.setContentPane(new PainelCadastroMembro(FramePrincipal.this));
				}
			});
		}
		return jButtonCadastro;
	}

	/**
	 * This method initializes jMenuItemDeslogar	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemDeslogar() {
		if (jMenuItemDeslogar == null) {
			jMenuItemDeslogar = new JMenuItem();
			jMenuItemDeslogar.setText("Deslogar");
			jMenuItemDeslogar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
			FramePrincipal.this.setContentPane(new PainelInicial(FramePrincipal.this));
			}
		});
		}
		return jMenuItemDeslogar;
	}

		/**
	 * This method initializes jMenuItemSair	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItemSair() {
		if (jMenuItemSair == null) {
			jMenuItemSair = new JMenuItem();
			jMenuItemSair.setText("Sair");
			jMenuItemSair.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.exit(0);
				}
			});
		}
		return jMenuItemSair;
	}

public static void main(String[] args) {
	new FramePrincipal().setVisible(true);
}
}  //  @jve:decl-index=0:visual-constraint="17,9"
