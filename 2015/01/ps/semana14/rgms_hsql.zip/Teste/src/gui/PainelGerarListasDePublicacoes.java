package gui;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.Image;

import javax.swing.JPanel;
import java.awt.Rectangle;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.SQLException;
import java.util.Vector;



import javax.swing.JButton;
import javax.swing.JRadioButton;

import fachada.Fachada;

import base.ArtigoEmConferencia;
import base.Lista;
import base.ListaPublicacoesPDF;



public class PainelGerarListasDePublicacoes extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JButton jButtonGerarRelatorio = null;
	private JButton jButtonGerarLista = null;
	

	/**
	 * This is the default constructor
	 */
	public PainelGerarListasDePublicacoes() {
		
		super();
		
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(18, 9, 208, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 12));
		jLabel.setText("Gera��o de Listas de Publica��es");
		this.setLayout(null);
		this.setBounds(new Rectangle(414, 126, 244, 117));
		this.add(jLabel, null);
		this.add(getJButtonGerarRelatorio(), null);
		this.add(getJButtonGerarLista(), null);
		//this.setBackground(Color.white);
	
		
	}


	

	/**
	 * This method initializes jButtonGerarRelatorio	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonGerarRelatorio() {
		if (jButtonGerarRelatorio == null) {
			jButtonGerarRelatorio = new JButton();
			jButtonGerarRelatorio.setBounds(new Rectangle(297, 216, 136, 28));
			jButtonGerarRelatorio.setText("Gerar Relat�rio");
			//this.gerarRelatorio();
		}
		return jButtonGerarRelatorio;
	}

	/**
	 * This method initializes jButtonGerarLista	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonGerarLista() {
		if (jButtonGerarLista == null) {
			jButtonGerarLista = new JButton();
			jButtonGerarLista.setBounds(new Rectangle(45, 90, 145, 19));
			jButtonGerarLista.setText("Gerar Lista");
			jButtonGerarLista.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelGerarListasDePublicacoes.this.gerarRelatorio();
				}
			});
		}
		return jButtonGerarLista;
	}

	public void gerarRelatorio(){
		
	}
	
}  //  @jve:decl-index=0:visual-constraint="20,36"
