package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import excecoes.ObjetoVazioException;
import excecoes.ParametroVazioException;
import excecoes.PublicacaoJaExistenteException;
import excecoes.PublicacaoNaoEncontradaException;

import base.ArtigoEmConferencia;
import base.Membro;

public class PainelEditarArtigoConferencia extends JPanel {
	Vector<String> vectorAutoresSelecionados;
	private int numeroAutoresArtigo;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private FramePrincipal frame;
	private JLabel labelTitulo = null;
	private JTextField jTextFieldTitulo = null;
	private JLabel labelTitulo1 = null;
	private JTextField jTextFieldNomeConferencia = null;
	private JLabel labelAno = null;
	private JTextField jTextFieldUrlPdf = null;
	private JButton jButtonCarregaPdf = null;
	private JTextField jTextFieldAno = null;
	private JLabel labelAno1 = null;
	private JTextField jTextFieldMes = null;
	private JLabel labelAno11 = null;
	private JTextField jTextFieldPaginas = null;
	private JLabel labelAno2 = null;
	private JList jListAutores = null;
	private JList jListAutoresSelecionados = null;
	private JButton jButtonAdicionarAutor = null;
	private JButton jButtonRemoverAutor = null;
	private JLabel labelAno21 = null;
	private JTextField jTextFieldAutoresNaoMembros = null;
	private JButton jButtonCadastrar = null;
	private JButton jButtonCancelar = null;
	private JScrollPane scrollautores = null;
	private JScrollPane scrollautoresSelecionados = null;
	private Vector<Membro> membros = new Vector<Membro>();
	private Vector<Membro> autores = new Vector<Membro>();  //  @jve:decl-index=0:
	private Vector<Membro> autoresSelecionados = new Vector();  //  @jve:decl-index=0:
	private ArtigoEmConferencia artigo;  //  @jve:decl-index=0:
	DefaultListModel listaAutores = null;
	DefaultListModel listaAutoresSelecionados = null;
	
	//LINHASDEPESQUISA
	private JLabel jLabel1 = null;
	private JButton jButtonSelecionaLinha = null;
	private JButton jButtonTiraLinha = null;
	private DefaultListModel listModelLinhas;
	private DefaultListModel listModelLinhasSelecionadas;
	private JScrollPane scrollLinhas = null;
	private JScrollPane scrollLinhasSelecionadas = null;
	private JList jListLinhas = null;
	private JList jListLinhasSelecionadas = null;
	//LINHASDEPESQUISA
	/**
	 * This is the default constructor
	 */
	public PainelEditarArtigoConferencia(FramePrincipal frame, ArtigoEmConferencia artigo) {
		super();
		this.frame = frame;
		this.artigo = artigo;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(24, 347, 190, 16));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelAno21 = new JLabel();
		labelAno21.setBounds(new Rectangle(24, 302, 280, 19));
		labelAno21.setText("Demais autores (nomes separados por v�rgula):");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(24, 194, 190, 19));
		labelAno2.setText("Autores cadastrados no grupo:*");
		labelAno11 = new JLabel();
		labelAno11.setBounds(new Rectangle(267, 149, 64, 19));
		labelAno11.setText("P�ginas:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(123, 149, 46, 19));
		labelAno1.setText("M�s:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(24, 149, 46, 19));
		labelAno.setText(" Ano: *");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(24, 104, 136, 19));
		labelTitulo1.setText("Nome da confer�ncia: *");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(24, 59, 91, 19));
		labelTitulo.setText("Titulo Artigo: *");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(24, 32, 271, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText("Editar artigo em confer�ncia:");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(getJTextFieldTitulo(), null);
		this.add(labelTitulo1, null);
		this.add(getJTextFieldNomeConferencia(), null);
		this.add(labelAno, null);
		this.add(getJTextFieldUrlPdf(), null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(getJTextFieldAno(), null);
		this.add(labelAno1, null);
		this.add(getJTextFieldMes(), null);
		this.add(labelAno11, null);
		this.add(getJTextFieldPaginas(), null);
		this.add(labelAno2, null);
		
		this.add(getJListAutoresSelecionados(), null);
		this.scrollautoresSelecionados = new JScrollPane(this.jListAutoresSelecionados);
		this.scrollautoresSelecionados.setBounds(new Rectangle(420, 212, 271, 82));
		//this.scrollautoresSelecionados.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollautoresSelecionados.setVisible(true);
		this.add(scrollautoresSelecionados);
		
		this.add(getJListAutores(), null);
		this.scrollautores = new JScrollPane(this.jListAutores);
		this.scrollautores.setBounds(new Rectangle(24, 212, 271, 82));
		this.scrollautores.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollautores.setVisible(true);
		this.add(scrollautores);
		
		
		this.add(getJButtonAdicionarAutor(), null);
		this.add(getJButtonRemoverAutor(), null);
		this.add(labelAno21, null);
		this.add(getJTextFieldAutoresNaoMembros(), null);
		this.add(getJButtonCadastrar(), null);
		this.add(getJButtonCancelar(), null);
		this.add(jLabel1, null);
		this.add(getJButtonSelecionaLinha(), null);
		
		
		
		this.add(getJButtonTiraLinha(), null);
		this.add(getJListLinhasSelecionadas(), null);
		this.scrollLinhasSelecionadas = new JScrollPane(this.jListLinhasSelecionadas);
		scrollLinhasSelecionadas.setBounds(new Rectangle(423, 369, 271, 82));
		//this.scrollLinhasSelecionadas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		scrollLinhasSelecionadas.setViewportView(getJListLinhasSelecionadas());
		this.scrollLinhasSelecionadas.setVisible(true);
		this.add(scrollLinhasSelecionadas);
	
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		scrollLinhas.setBounds(new Rectangle(27, 369, 280, 82));
		//this.scrollLinhasSelecionadas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		
	}

	/**
	 * This method initializes jTextFieldTitulo	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldTitulo() {
		if (jTextFieldTitulo == null) {
			jTextFieldTitulo = new JTextField();
			jTextFieldTitulo.setBounds(new Rectangle(24, 77, 361, 19));
			jTextFieldTitulo.setText(this.artigo.getTitulo());
		}
		return jTextFieldTitulo;
	}

	/**
	 * This method initializes jTextFieldNomeConferencia	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNomeConferencia() {
		if (jTextFieldNomeConferencia == null) {
			jTextFieldNomeConferencia = new JTextField();
			jTextFieldNomeConferencia.setBounds(new Rectangle(24, 122, 361, 19));
			jTextFieldNomeConferencia.setText(this.artigo.getConferencia());
		}
		return jTextFieldNomeConferencia;
	}

	/**
	 * This method initializes jTextFieldUrlPdf	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldUrlPdf() {
		if (jTextFieldUrlPdf == null) {
			jTextFieldUrlPdf = new JTextField();
			jTextFieldUrlPdf.setBounds(new Rectangle(465, 167, 208, 19));
		}
		return jTextFieldUrlPdf;
	}

	/**
	 * This method initializes jButtonCarregaPdf	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(474, 185, 190, 19));
			jButtonCarregaPdf.setText("Carregar arquivo pdf");
			jButtonCarregaPdf.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelEditarArtigoConferencia.this.carregaPdf();
				}
			});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf(){
		JFileChooser arquivo = new JFileChooser();
		int returnVal = arquivo.showOpenDialog(this);
		
		if(returnVal == JFileChooser.APPROVE_OPTION){
			File arq = arquivo.getSelectedFile();
			this.jTextFieldUrlPdf.setText(arq.getAbsolutePath());
			this.artigo.setUrlPdf(arq.getAbsolutePath());
			//this.artigo.setPdf(new File(arq.getAbsolutePath()));
			
		}
	}
	/**
	 * This method initializes jTextFieldAno	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAno() {
		if (jTextFieldAno == null) {
			jTextFieldAno = new JTextField();
			jTextFieldAno.setBounds(new Rectangle(24, 167, 64, 19));
			jTextFieldAno.setText(this.artigo.getAno());
		}
		return jTextFieldAno;
	}

	/**
	 * This method initializes jTextFieldMes	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldMes() {
		if (jTextFieldMes == null) {
			jTextFieldMes = new JTextField();
			jTextFieldMes.setBounds(new Rectangle(123, 167, 109, 19));
			jTextFieldMes.setText(this.artigo.getMes());
		}
		return jTextFieldMes;
	}

	/**
	 * This method initializes jTextFieldPaginas	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldPaginas() {
		if (jTextFieldPaginas == null) {
			jTextFieldPaginas = new JTextField();
			jTextFieldPaginas.setBounds(new Rectangle(267, 167, 118, 19));
			jTextFieldPaginas.setText(this.artigo.getPaginas());
		}
		return jTextFieldPaginas;
	}

	/**
	 * This method initializes jListAutores	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListAutores() {
		if (jListAutores == null) {
			
		    this.listaAutores = new DefaultListModel();
			jListAutores = new JList(listaAutores);
			jListAutores.setBounds(new Rectangle(18, 288, 271, 127));
			try {
				this.membros = this.frame.getFachada().retornaTodosMembros();
				this.autores = (Vector<Membro>) this.membros.clone();
				Iterator<Membro> it = autores.iterator();
				while(it.hasNext()){
					Membro x = it.next();
					boolean achou = false;
					int i = 0;
					while(i < this.listaAutoresSelecionados.getSize() && !achou){
						if(x.getNome().equals(this.listaAutoresSelecionados.elementAt(i))){
							achou = true;
						}
					
						i++;
					}
					if(!achou){
						listaAutores.addElement(x.getNome());
					}
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListAutores;
	}

	/**
	 * This method initializes jListAutoresSelecionados	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListAutoresSelecionados() {
		if (jListAutoresSelecionados == null) {
			this.listaAutoresSelecionados = new DefaultListModel();
			jListAutoresSelecionados = new JList(listaAutoresSelecionados);
			jListAutoresSelecionados.setBounds(new Rectangle(414, 288, 271, 127));
			try {
				this.vectorAutoresSelecionados = this.frame.getFachada().retornaMembrosDeUmaPublicacao(this.artigo.getTitulo());
				this.numeroAutoresArtigo = vectorAutoresSelecionados.size();
				Iterator<String> it = vectorAutoresSelecionados.iterator();
				while(it.hasNext()){
					String autor = it.next();
					listaAutoresSelecionados.addElement(autor);
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListAutoresSelecionados;
	}

	/**
	 * This method initializes jButtonAdicionarAutor	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAdicionarAutor() {
		if (jButtonAdicionarAutor == null) {
			jButtonAdicionarAutor = new JButton();
			jButtonAdicionarAutor.setBounds(new Rectangle(321, 212, 73, 28));
			jButtonAdicionarAutor.setText(">>");
			jButtonAdicionarAutor.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelEditarArtigoConferencia.this.jListAutores.getSelectedIndex();
					String nomeAutor = (String) PainelEditarArtigoConferencia.this.jListAutores.getSelectedValue();
					PainelEditarArtigoConferencia.this.listaAutores.removeElementAt(indice);
					PainelEditarArtigoConferencia.this.listaAutoresSelecionados.addElement(nomeAutor);
					
				}
			});
			
		}
		return jButtonAdicionarAutor;
	}

	/**
	 * This method initializes jButtonRemoverAutor	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRemoverAutor() {
		if (jButtonRemoverAutor == null) {
			jButtonRemoverAutor = new JButton();
			jButtonRemoverAutor.setBounds(new Rectangle(321, 266, 73, 28));
			jButtonRemoverAutor.setText("<<");
			jButtonRemoverAutor.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelEditarArtigoConferencia.this.jListAutoresSelecionados.getSelectedIndex();
					String nomeAutor = (String) PainelEditarArtigoConferencia.this.jListAutoresSelecionados.getSelectedValue();
					PainelEditarArtigoConferencia.this.listaAutores.addElement(nomeAutor);
					PainelEditarArtigoConferencia.this.listaAutoresSelecionados.removeElementAt(indice);;
					
				}
			});
		}
		return jButtonRemoverAutor;
	}

	/**
	 * This method initializes jTextFieldAutoresNaoMembros	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAutoresNaoMembros() {
		if (jTextFieldAutoresNaoMembros == null) {
			jTextFieldAutoresNaoMembros = new JTextField();
			jTextFieldAutoresNaoMembros.setBounds(new Rectangle(24, 320, 370, 19));
			jTextFieldAutoresNaoMembros.setText(this.artigo.getAutoresNaoMembros());
		}
		return jTextFieldAutoresNaoMembros;
	}

	/**
	 * This method initializes jButtonCadastrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastrar() {
		if (jButtonCadastrar == null) {
			jButtonCadastrar = new JButton();
			jButtonCadastrar.setBounds(new Rectangle(447, 482, 109, 28));
			jButtonCadastrar.setText("Salvar");
			jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					boolean camposObrigatorios = PainelEditarArtigoConferencia.this.carregaArtigoConferencia();
					if(camposObrigatorios == true){
						try {
							PainelEditarArtigoConferencia.this.frame.getFachada().editarArtigoEmConferencia(PainelEditarArtigoConferencia.this.artigo);
							JOptionPane.showMessageDialog(null,
									"Artigo atualizado!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);
							PainelEditarArtigoConferencia.this.frame.setContentPane(new PainelPublicacoes(PainelEditarArtigoConferencia.this.frame));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ObjetoVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ParametroVazioException e3) {
							// TODO Auto-generated catch block
							e3.printStackTrace();
						} catch (PublicacaoNaoEncontradaException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(null,
								"Campos obrigat�rios n�o preenchidos", "INFORMA��O",
								JOptionPane.WARNING_MESSAGE);
					}
				}
			});
		}
		return jButtonCadastrar;
	}
	
	public boolean carregaArtigoConferencia(){
		boolean camposObrigatorios = true;
		int tamanho = this.listaAutoresSelecionados.getSize();
		Vector<String> v = new Vector();
		for(int i = 0; i < tamanho; i++){
			String autor = (String) this.listaAutoresSelecionados.getElementAt(i);
			v.add(autor);
		}
			this.artigo.setNomeAutoresMembros(v);
			String titulo = this.jTextFieldTitulo.getText().trim().toUpperCase();
			this.artigo.setTitulo(titulo);
			String nomeConferencia = this.jTextFieldNomeConferencia.getText().trim().toUpperCase();
			this.artigo.setConferencia(nomeConferencia);
			String ano = this.jTextFieldAno.getText().trim().toUpperCase();
			this.artigo.setAno(ano);
			String mes = this.jTextFieldMes.getText().trim().toUpperCase();
			this.artigo.setMes(mes);
			String paginas = this.jTextFieldPaginas.getText().trim().toUpperCase();
			this.artigo.setPaginas(paginas);
			String autoresNaoMembros = this.jTextFieldAutoresNaoMembros.getText().trim().toUpperCase();
			this.artigo.setAutoresNaoMembros(autoresNaoMembros);
			//LINHASDEPESQUISA
			
			Vector<String> linhas = new Vector<String>();
			for(int i = 0; i < this.listModelLinhasSelecionadas.size(); i++){
				String linha = (String) this.listModelLinhasSelecionadas.elementAt(i);
				linhas.add(linha);
			}
			this.artigo.setLinhasDePesquisa(linhas);
			//LINHASDEPESQUISA
			if(v.isEmpty() || titulo.equals("") || nomeConferencia.equals("") || ano.equals("")){
			camposObrigatorios = false;
			}
			
			
		return camposObrigatorios;
	}
	/**
	 * This method initializes jButtonCancelar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(582, 482, 109, 28));
			jButtonCancelar.setText("Cancelar");
			
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelEditarArtigoConferencia.this.frame.setContentPane(new PainelExibirArtigoDeConferencia(PainelEditarArtigoConferencia.this.frame, PainelEditarArtigoConferencia.this.artigo ));
				}
			});
		}
		return jButtonCancelar;
	}

	

	/**
	 * This method initializes jButtonSelecionaLinha	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSelecionaLinha() {
		if (jButtonSelecionaLinha == null) {
			jButtonSelecionaLinha = new JButton();
			jButtonSelecionaLinha.setBounds(new Rectangle(321, 365, 73, 28));
			jButtonSelecionaLinha.setText(">>");
			jButtonSelecionaLinha.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String linha = (String)PainelEditarArtigoConferencia.this.jListLinhas.getSelectedValue();
					int indice = PainelEditarArtigoConferencia.this.jListLinhas.getSelectedIndex();
					PainelEditarArtigoConferencia.this.listModelLinhas.removeElementAt(indice);
					PainelEditarArtigoConferencia.this.listModelLinhasSelecionadas.addElement(linha);
				}
			});
		}
		return jButtonSelecionaLinha;
	}

	/**
	 * This method initializes jButtonTiraLinha	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonTiraLinha() {
		if (jButtonTiraLinha == null) {
			jButtonTiraLinha = new JButton();
			jButtonTiraLinha.setBounds(new Rectangle(321, 419, 73, 28));
			jButtonTiraLinha.setText("<<");
			jButtonTiraLinha.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String linha = (String)PainelEditarArtigoConferencia.this.jListLinhasSelecionadas.getSelectedValue();
					int indice = PainelEditarArtigoConferencia.this.jListLinhasSelecionadas.getSelectedIndex();
					PainelEditarArtigoConferencia.this.listModelLinhasSelecionadas.removeElementAt(indice);
					PainelEditarArtigoConferencia.this.listModelLinhas.addElement(linha);
				}
			});
		}
		return jButtonTiraLinha;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			this.listModelLinhas = new DefaultListModel();
			jListLinhas = new JList(this.listModelLinhas);
			jListLinhas.setBounds(new Rectangle(18, 342, 280, 82));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaTodasLinhasDePesquisa();
				Iterator<String> it = linhas.iterator();
				while(it.hasNext()){
					String x = it.next();
					boolean achou = false;
					int i = 0;
					while(i < this.listModelLinhasSelecionadas.getSize() && !achou){
						if(x.equals(this.listModelLinhasSelecionadas.elementAt(i))){
							achou = true;
						}
					
						i++;
					}
					if(!achou){
						this.listModelLinhas.addElement(x);
					}
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListLinhas;
	}

	/**
	 * This method initializes jListLinhasSelecionadas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhasSelecionadas() {
		if (jListLinhasSelecionadas == null) {
			this.listModelLinhasSelecionadas = new DefaultListModel();
			jListLinhasSelecionadas = new JList(this.listModelLinhasSelecionadas);
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmaPublicacao(this.artigo.getTitulo());
				for(int i = 0; i < linhas.size(); i++){
					String linha = linhas.elementAt(i);
					this.listModelLinhasSelecionadas.addElement(linha);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhasSelecionadas;
	}

	

}  //  @jve:decl-index=0:visual-constraint="10,10"
