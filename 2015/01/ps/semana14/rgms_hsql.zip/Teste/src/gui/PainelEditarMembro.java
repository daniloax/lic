package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;

import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.Membro;
import base.TeseDeDoutorado;

import java.lang.String;
import javax.swing.JPasswordField;
import java.awt.Point;
import javax.swing.JToolBar;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import excecoes.MembroNaoEncontradoException;
import excecoes.ObjetoVazioException;
import excecoes.ParametroVazioException;

public class PainelEditarMembro extends JPanel {

	private Membro membro ; // @jve:decl-index=0:
	
	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;
	private JLabel labelTitulo1 = null;
	private JLabel labelAno = null;
	private JLabel labelAno2 = null;
	private JTextField exibirNome = null;
	private JTextField departamento = null;
	private JTextField exibirEmail = null;
	
	private JLabel labelTelefone = null;

	private JTextField exibirTelefone = null;

	private JLabel labelSite = null;

	private JTextField exibirSite = null;

	private JLabel labelCidade = null;

	private JTextField exibirCidade = null;

	private JLabel labelPais = null;

	private JTextField exibirPais = null;

	private JLabel labelLogin = null;

	private JTextField exibirLogin = null;

	private JLabel labelFoto = null;

	private JLabel jLabel1 = null;

	private JRadioButton jRadioButtonAtivo = null;

	private JLabel jLabel11 = null;

	private JButton jButtonSalvar = null;

	private JButton jButtonCancelar = null;
	private JButton jButtonMudarFoto = null;
	private JLabel jLabel2 = null;

	private JPasswordField jPasswordFieldSenha = null;

	private JComboBox jComboBoxTipoMembro = null;

	private JLabel labelAno1 = null;

	private JTextField jTextFieldUniversidade = null;

	private JLabel jLabel3 = null;
	
	//LINHADEPESQUISA
	private JList jListLinhas = null;

	private JList jListLinhasSelecionadas = null;

	private JButton jButtonEntrar = null;

	private JButton jButtonSair = null;
	
	private JScrollPane scrollLinhas = null;
	
	private JScrollPane scrollLinhasSelecionadas = null;
	
	private DefaultListModel listModelLinhas = null;
	
	private DefaultListModel listModelLinhasSelecionadas = null;
	//LINHADEPESQUISA
	/**
	 * This is the default constructor
	 */
	public PainelEditarMembro(FramePrincipal frame, Membro m) {
		super();
		this.frame = frame;
		this.membro = m;
		
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel3 = new JLabel();
		jLabel3.setBounds(new Rectangle(18, 405, 190, 19));
		jLabel3.setText("Linhas de Pesquisa Associadas:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(189, 108, 82, 19));
		labelAno1.setText("Universidade:");
		jLabel2 = new JLabel();
		jLabel2.setBounds(new Rectangle(216, 270, 73, 19));
		jLabel2.setText("Nova senha:");
		jLabel11 = new JLabel();
		jLabel11.setBounds(new Rectangle(45, 378, 37, 19));
		jLabel11.setText("Ativo");
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(18, 360, 46, 19));
		jLabel1.setText("Status:");
		labelFoto = new JLabel();
		labelFoto.setText("JLabel");
		labelFoto.setSize(new Dimension(127, 142));
		labelFoto.setLocation(new Point(18, 54));
		labelFoto.setIcon(this.membro.getFoto());
		labelLogin = new JLabel();
		labelLogin.setBounds(new Rectangle(18, 270, 50, 20));
		labelLogin.setText("  Login:");
		labelPais = new JLabel();
		labelPais.setBounds(new Rectangle(216, 315, 45, 20));
		labelPais.setText(" Pa�s:");
		labelCidade = new JLabel();
		labelCidade.setBounds(new Rectangle(18, 315, 53, 19));
		labelCidade.setText(" Cidade:");
		labelSite = new JLabel();
		labelSite.setBounds(new Rectangle(405, 270, 59, 20));
		labelSite.setText(" Website:");
		labelTelefone = new JLabel();
		labelTelefone.setBounds(new Rectangle(468, 225, 58, 18));
		labelTelefone.setText(" Telefone:");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 225, 44, 19));
		labelAno2.setText(" E-mail:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(189, 162, 90, 19));
		labelAno.setText(" Departamento: ");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(405, 315, 36, 19));
		labelTitulo1.setText(" Tipo:");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(189, 54, 45, 19));
		labelTitulo.setText(" Nome:");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 125, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Perfil do membro");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelTitulo1, null);
		this.add(labelAno, null);
		this.add(labelAno2, null);

		this.add(getExibirNome(), null);
		this.add(getExibirDepartamento(), null);
		this.add(getEmail(), null);
		this.add(labelTelefone, null);
		this.add(getExibirTelefone(), null);
		this.add(labelSite, null);
		this.add(getExibirSite(), null);
		this.add(labelCidade, null);
		this.add(getExibirCidade(), null);
		this.add(labelPais, null);
		this.add(getExibirPais(), null);
		this.add(labelLogin, null);
		this.add(getExibirLogin(), null);
		this.add(labelFoto, null);
		this.add(jLabel1, null);
		this.add(getJRadioButtonAtivo(), null);
		this.add(jLabel11, null);
		this.add(getJButtonSalvar(), null);
		this.add(getJButtonCancelar(), null);
		this.add(getJButtonMudarFoto(), null);
		this.add(jLabel2, null);
		this.add(getJPasswordFieldSenha(), null);
		this.add(getJComboBoxTipoMembro(), null);
		this.add(labelAno1, null);
		this.add(getJTextFieldUniversidade(), null);
		
		//LINHASDEPESQUISA
		this.add(getJListLinhasSelecionadas(), null);
		this.scrollLinhasSelecionadas = new JScrollPane(this.jListLinhasSelecionadas);
		this.scrollLinhasSelecionadas.setBounds(new Rectangle(360, 423, 253, 82));
		this.scrollLinhasSelecionadas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhasSelecionadas.setVisible(true);
		this.add(scrollLinhasSelecionadas);
		
		this.add(jLabel3, null);
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 423, 253, 82));
		this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		
		this.add(getJButtonEntrar(), null);
		this.add(getJButtonSair(), null);
		//LINHASDEPESQUISA
	}

	public void carregaPdf() {

		// incluir trecho de c�digo para abrir pdf com visualizar padr�o em java
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirNome() {
		if (exibirNome == null) {
			exibirNome = new JTextField();
			exibirNome.setBounds(new Rectangle(189, 81, 440, 19));
			// preenche com o valor
			String titulo = this.membro.getNome();
			exibirNome.setText(titulo);
			
		}
		return exibirNome;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirDepartamento() {
		if (departamento == null) {
			departamento = new JTextField();
			departamento.setBounds(new Rectangle(189, 189, 342, 20));
			// preenche com o valor
			String ano = this.membro.getDpto_univ();
			departamento.setText(ano);
			
		}
		return departamento;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getEmail() {
		if (exibirEmail == null) {
			exibirEmail = new JTextField();
			exibirEmail.setBounds(new Rectangle(18, 243, 386, 20));
			// preencher com o valor
			String autor = this.membro.getEmail();
			exibirEmail.setText(autor);
			
		}
		return exibirEmail;
	}

	/**
	 * This method initializes exibirTelefone
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTelefone() {
		if (exibirTelefone == null) {
			exibirTelefone = new JTextField();
			exibirTelefone.setBounds(new Rectangle(468, 243, 141, 20));
			
			
			// preencher com o valor
			String autor = this.membro.getTelefone();
			exibirTelefone.setText(autor);
		}
		return exibirTelefone;
	}

	/**
	 * This method initializes exibirSite
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirSite() {
		if (exibirSite == null) {
			exibirSite = new JTextField();
			exibirSite.setBounds(new Rectangle(405, 288, 208, 20));
			String x = this.membro.getWebsite();
			exibirSite.setText(x);
			
		}
		return exibirSite;
	}

	/**
	 * This method initializes exibirCidade
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirCidade() {
		if (exibirCidade == null) {
			exibirCidade = new JTextField();
			exibirCidade.setBounds(new Rectangle(18, 333, 142, 20));
			String x = this.membro.getCidade();
			exibirCidade.setText(x);
			
		}
		return exibirCidade;
	}

	/**
	 * This method initializes exibirPais
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirPais() {
		if (exibirPais == null) {
			exibirPais = new JTextField();
			exibirPais.setBounds(new Rectangle(216, 333, 126, 20));
			String x = this.membro.getPais();
			exibirPais.setText(x);
			
		}
		return exibirPais;
	}

	/**
	 * This method initializes exibirLogin
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirLogin() {
		if (exibirLogin == null) {
			exibirLogin = new JTextField();
			exibirLogin.setBounds(new Rectangle(18, 288, 139, 20));
			String x = this.membro.getLogin();
			exibirLogin.setText(x);
			
		}
		return exibirLogin;
	}

	public Membro getMembro() {
		return membro;
	}

	public void setMembro(Membro membro) {
		this.membro = membro;
	}


	/**
	 * This method initializes jRadioButtonAtivo	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButtonAtivo() {
		if (jRadioButtonAtivo == null) {
			jRadioButtonAtivo = new JRadioButton("teste");
			jRadioButtonAtivo.setBounds(new Rectangle(18, 378, 19, 19));
			
			if(this.membro.getStatus().equals("ATIVO")){
				
				jRadioButtonAtivo.setSelected(true);
				
			}else{
				jRadioButtonAtivo.setSelected(false);
			}
		}
		return jRadioButtonAtivo;
	}

	/**
	 * This method initializes jButtonSalvar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSalvar() {
		if (jButtonSalvar == null) {
			jButtonSalvar = new JButton();
			jButtonSalvar.setBounds(new Rectangle(198, 513, 109, 28));
			jButtonSalvar.setText("Salvar");
			jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					boolean camposObrigatorios = PainelEditarMembro.this.atualizaMembro();
					if(camposObrigatorios == true){
						try {
							PainelEditarMembro.this.frame.getFachada().editarMembro(PainelEditarMembro.this.membro);
							JOptionPane.showMessageDialog(PainelEditarMembro.this,
						    "Usu�rio editado com sucesso!");
							PainelEditarMembro.this.frame.getMembro().setLogin(PainelEditarMembro.this.membro.getLogin());
							PainelEditarMembro.this.frame.setContentPane(new PainelMembros(PainelEditarMembro.this.frame));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ObjetoVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ParametroVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (MembroNaoEncontradoException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(PainelEditarMembro.this,
							    "Campos obrigat�rios n�o preenchidos corretamente!",
							    "Inane error",
							    JOptionPane.ERROR_MESSAGE);
					}
				}
			});
		}
		return jButtonSalvar;
	}

	public boolean atualizaMembro(){
		boolean retorno = true;
		this.membro.setNome(this.getExibirNome().getText().trim().toUpperCase());
		this.membro.setUniversidade(this.jTextFieldUniversidade.getText().trim().toUpperCase());
		this.membro.setDpto_univ(this.departamento.getText().trim().toUpperCase());
		this.membro.setTipo((String)(this.jComboBoxTipoMembro.getSelectedItem()));
		this.membro.setEmail(exibirEmail.getText().trim().toUpperCase());
		this.membro.setTelefone(exibirTelefone.getText().trim().toUpperCase());
		this.membro.setLogin(exibirLogin.getText().trim().toUpperCase());
		this.membro.setSenha(jPasswordFieldSenha.getText().toUpperCase());
		this.membro.setWebsite(exibirSite.getText().trim().toUpperCase());
		this.membro.setCidade(exibirCidade.getText().trim().toUpperCase());
		this.membro.setPais(exibirPais.getText().trim().toUpperCase());
		if(this.jRadioButtonAtivo.isSelected()){
			this.membro.setStatus("ATIVO");
		}else{
			this.membro.setStatus("INATIVO");
		}
		
		//LINHADEPESQUISA
		Vector<String> linhas = new Vector();
		for(int i = 0; i < this.listModelLinhasSelecionadas.getSize(); i++){
			String linha = (String) this.listModelLinhasSelecionadas.getElementAt(i);
			linhas.add(linha);
		}
		this.membro.setLinhasDePesquisa(linhas);
		//LINHADEPESQUISA
		
		if(this.membro.getNome().equals("") || this.membro.getLogin().equals("")|| 
				this.membro.getSenha().equals("") || this.membro.getEmail().equals("")){
			retorno = false;
		}
		
		return retorno;
		
	}
	/**
	 * This method initializes jButtonCancelar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(351, 513, 109, 28));
			jButtonCancelar.setText("Cancelar");
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelEditarMembro.this.frame.setContentPane(new PainelMembros(PainelEditarMembro.this.frame));
				}
			});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes jButtonMudarFoto	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonMudarFoto() {
		if (jButtonMudarFoto == null) {
			jButtonMudarFoto = new JButton();
			jButtonMudarFoto.setBounds(new Rectangle(18, 198, 127, 19));
			jButtonMudarFoto.setText("Mudar foto");
			jButtonMudarFoto.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelEditarMembro.this.carregaFoto();
				}
			});
		}
		return jButtonMudarFoto;
	}
	
	public void carregaFoto(){
		JFileChooser arquivo = new JFileChooser();
		int returnVal = arquivo.showOpenDialog(this);
		
		if(returnVal == JFileChooser.APPROVE_OPTION){
			
		File arq = arquivo.getSelectedFile();
		this.membro.setUrlFoto(arq.getAbsolutePath())  ;
		ImageIcon imagem = new ImageIcon(this.membro.getUrlFoto());
		Image temp = imagem.getImage();
		Image temp2 = temp.getScaledInstance(127,142, 0);
		this.labelFoto.setIcon(new ImageIcon(temp2));

		}
	}

	/**
	 * This method initializes jPasswordFieldSenha	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getJPasswordFieldSenha() {
		if (jPasswordFieldSenha == null) {
			jPasswordFieldSenha = new JPasswordField();
			jPasswordFieldSenha.setBounds(new Rectangle(216, 288, 118, 19));
		}
		return jPasswordFieldSenha;
	}

	/**
	 * This method initializes jComboBoxTipoMembro	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxTipoMembro() {
		if (jComboBoxTipoMembro == null) {
			jComboBoxTipoMembro = new JComboBox();
			jComboBoxTipoMembro.setBounds(new Rectangle(405, 333, 226, 19));
			jComboBoxTipoMembro.addItem("INICIA��O CIENT�FICA");
			jComboBoxTipoMembro.addItem("MESTRADO");
			jComboBoxTipoMembro.addItem("DOUTORADO");
			jComboBoxTipoMembro.addItem("PROFESSOR");
			jComboBoxTipoMembro.addItem("OUTRO");
		}
		return jComboBoxTipoMembro;
	}

	/**
	 * This method initializes jTextFieldUniversidade	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldUniversidade() {
		if (jTextFieldUniversidade == null) {
			jTextFieldUniversidade = new JTextField();
			jTextFieldUniversidade.setBounds(new Rectangle(189, 135, 343, 19));
			// preenche com o valor
			String universidade = this.membro.getUniversidade();
			jTextFieldUniversidade.setText(universidade);
		}
		return jTextFieldUniversidade;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			this.listModelLinhas = new DefaultListModel();
			jListLinhas = new JList(this.listModelLinhas);
			jListLinhas.setBounds(new Rectangle(18, 423, 253, 82));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaTodasLinhasDePesquisa();
				Iterator<String> it = linhas.iterator();
				while(it.hasNext()){
					String x = it.next();
					boolean achou = false;
					int i = 0;
					while(i < this.listModelLinhasSelecionadas.getSize() && !achou){
						if(x.equals(this.listModelLinhasSelecionadas.elementAt(i))){
							achou = true;
						}
					
						i++;
					}
					if(!achou){
						this.listModelLinhas.addElement(x);
					}
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhas;
	}

	/**
	 * This method initializes jListLinhasSelecionadas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhasSelecionadas() {
		if (jListLinhasSelecionadas == null) {
			this.listModelLinhasSelecionadas = new DefaultListModel();
			jListLinhasSelecionadas = new JList(this.listModelLinhasSelecionadas);
			jListLinhasSelecionadas.setBounds(new Rectangle(360, 423, 253, 82));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmMembro(this.membro.getNome());
				for(int i = 0; i < linhas.size(); i++){
					String linha = linhas.elementAt(i);
					System.out.println(linha);
					this.listModelLinhasSelecionadas.addElement(linha);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhasSelecionadas;
	}

	/**
	 * This method initializes jButtonEntrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonEntrar() {
		if (jButtonEntrar == null) {
			jButtonEntrar = new JButton();
			jButtonEntrar.setBounds(new Rectangle(288, 423, 55, 28));
			jButtonEntrar.setText(">>");
			jButtonEntrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String linha = (String)PainelEditarMembro.this.jListLinhas.getSelectedValue();
					int indice = PainelEditarMembro.this.jListLinhas.getSelectedIndex();
					PainelEditarMembro.this.listModelLinhas.removeElementAt(indice);
					PainelEditarMembro.this.listModelLinhasSelecionadas.addElement(linha);
				}
			});
		}
		return jButtonEntrar;
	}
	
	
	/**
	 * This method initializes jButtonSair	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonSair() {
		if (jButtonSair == null) {
			jButtonSair = new JButton();
			jButtonSair.setBounds(new Rectangle(288, 477, 55, 28));
			jButtonSair.setText("<<");
			jButtonSair.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String linha = (String)PainelEditarMembro.this.jListLinhasSelecionadas.getSelectedValue();
					int indice = PainelEditarMembro.this.jListLinhasSelecionadas.getSelectedIndex();
					PainelEditarMembro.this.listModelLinhasSelecionadas.removeElementAt(indice);
					PainelEditarMembro.this.listModelLinhas.addElement(linha);
				}
			});
		}
		return jButtonSair;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"