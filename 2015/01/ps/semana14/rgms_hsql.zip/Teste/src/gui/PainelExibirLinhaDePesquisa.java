package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import com.sun.org.apache.bcel.internal.generic.NEW;

import base.ArtigoEmConferencia;
import base.LinhaDePesquisa;
import base.Membro;
import javax.swing.JToolBar;

public class PainelExibirLinhaDePesquisa extends JPanel {

	private LinhaDePesquisa linhaDePesquisa; // @jve:decl-index=0:

	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;

	private JLabel labelDescBreve = null;
	private JLabel labelDescDet = null;
	private JLabel labelFinanciadores = null;
	private JButton jButtonRemover = null;
	private JButton jButtonEditar = null;
	private JTextField exibirTitulo = null;
	private JTextField exibirDescBreve = null;
	private JTextField exibirDescDet = null;
	private JTextField exibirFinanciadores = null;

	private JLabel links = null;

	private JTextField exibirLinks = null;

	private JLabel labelMembros = null;

	private JLabel labelPublicacoes = null;

	private JList listaMembrosSelecionados = null;
	private JScrollPane scrollMembrosSelecionados = null;
	private DefaultListModel listModelMembrosSelecionados = null;

	private JList listaPublicacoesSelecionadas = null;
	private JScrollPane scrollPublicacoesSelecionadas = null;
	private DefaultListModel listModelPublicacoesSelecionadas = null;

	private JToolBar jToolBarPaginaInicial = null;

	private JButton jButtonVoltarInicial = null;

	/**
	 * This is the default constructor
	 */
	public PainelExibirLinhaDePesquisa(FramePrincipal frame, LinhaDePesquisa linha) {
		super();
		this.frame = frame;
		this.linhaDePesquisa = linha;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		labelPublicacoes = new JLabel();
		labelPublicacoes.setBounds(new Rectangle(369, 387, 78, 16));
		labelPublicacoes.setText(" Publica��es:");
		labelMembros = new JLabel();
		labelMembros.setBounds(new Rectangle(18, 387, 67, 16));
		labelMembros.setText(" Membros:");
		links = new JLabel();
		links.setBounds(new Rectangle(18, 322, 118, 16));
		links.setText(" Links relacionados:");
		labelFinanciadores = new JLabel();
		labelFinanciadores.setBounds(new Rectangle(18, 252, 95, 19));
		labelFinanciadores.setText(" Financiadores:");
		labelDescDet = new JLabel();
		labelDescDet.setBounds(new Rectangle(18, 189, 130, 19));
		labelDescDet.setText(" Descri��o detalhada: ");
		labelDescBreve = new JLabel();
		labelDescBreve.setBounds(new Rectangle(18, 126, 105, 19));
		labelDescBreve.setText(" Descri��o breve:");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 63, 43, 19));
		labelTitulo.setText(" Titulo: ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 222, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Detalhes da linha de pesquisa");
		this.setSize(712, 561);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelDescBreve, null);
		this.add(labelDescDet, null);
		this.add(labelFinanciadores, null);

		this.add(getJButtonRemover(), null);
		this.add(getJButtonEditar(), null);
		this.add(getExibirTitulo(), null);
		this.add(getExibirDescricaoBreve(), null);
		this.add(getExibirDescricaoDetalhada(), null);
		this.add(getExibirFinanciadores(), null);
		this.add(links, null);
		this.add(getExibirLinks(), null);
		this.add(labelMembros, null);
		this.add(labelPublicacoes, null);

		this.add(getListaMembrosSelecionados(), null);

		this.scrollMembrosSelecionados = new JScrollPane(
				this.listaMembrosSelecionados);
		this.scrollMembrosSelecionados.setBounds(18, 405, 243, 95);
		this.scrollMembrosSelecionados
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		this.scrollMembrosSelecionados.setVisible(true);
		this.add(scrollMembrosSelecionados);

		this.add(getListaPublicacoesSelecionadas(), null);

		this.scrollPublicacoesSelecionadas = new JScrollPane(
				this.listaPublicacoesSelecionadas);
		this.scrollPublicacoesSelecionadas.setBounds(369, 405, 242, 96);
		this.scrollPublicacoesSelecionadas
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		this.scrollPublicacoesSelecionadas.setVisible(true);
		this.add(scrollPublicacoesSelecionadas);
		this.add(getJToolBarPaginaInicial(), null);
	}

	public void carregaPdf() {

		// incluir trecho de c�digo para abrir pdf com visualizar padr�o em java
	}

	/**
	 * This method initializes jButtonCadastrar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonRemover() {
		if (jButtonRemover == null) {
			jButtonRemover = new JButton();
			jButtonRemover.setBounds(new Rectangle(369, 513, 109, 28));
			jButtonRemover.setText("Remover");
			jButtonRemover
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							// chamar m�todo para remover linha de pesquisa do
							// bd
							// n�o � preciso carregar outra tela, apenas exibir
							// uma msg de confirma��o da remo��o

							JOptionPane.showMessageDialog(null,
									"Linha de Pesquisa removida!",
									"INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);

						}
					});
		}
		return jButtonRemover;
	}

	/**
	 * This method initializes jButtonCancelar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonEditar() {
		if (jButtonEditar == null) {
			jButtonEditar = new JButton();
			jButtonEditar.setBounds(new Rectangle(504, 513, 109, 28));
			jButtonEditar.setText("Editar");

			jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
						
						PainelExibirLinhaDePesquisa.this.frame.setContentPane(new PainelEditarLinhaDePesquisa(PainelExibirLinhaDePesquisa.this.frame , PainelExibirLinhaDePesquisa.this.linhaDePesquisa));

						}
					});
		}
		return jButtonEditar;
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTitulo() {
		if (exibirTitulo == null) {
			exibirTitulo = new JTextField();
			exibirTitulo.setBounds(new Rectangle(21, 94, 609, 20));
			// preenche com o valor
			String titulo = this.linhaDePesquisa.getTitulo();
			exibirTitulo.setText(titulo);
			exibirTitulo.setEnabled(false);
		}
		return exibirTitulo;
	}

	/**
	 * This method initializes exibirConferencia
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirDescricaoBreve() {
		if (exibirDescBreve == null) {
			exibirDescBreve = new JTextField();
			exibirDescBreve.setBounds(new Rectangle(22, 156, 608, 20));
			// preenche com o valor
			String descBreve = this.linhaDePesquisa.getDescricaoBreve();
			exibirDescBreve.setText(descBreve);
			exibirDescBreve.setEnabled(false);

		}
		return exibirDescBreve;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirDescricaoDetalhada() {
		if (exibirDescDet == null) {
			exibirDescDet = new JTextField();
			exibirDescDet.setBounds(new Rectangle(22, 217, 607, 20));
			// preenche com o valor
			String descDet = this.linhaDePesquisa.getDescricaoDetalhada();
			exibirDescDet.setText(descDet);
			exibirDescDet.setEnabled(false);
		}
		return exibirDescDet;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirFinanciadores() {
		if (exibirFinanciadores == null) {
			exibirFinanciadores = new JTextField();
			exibirFinanciadores.setBounds(new Rectangle(21, 284, 607, 20));
			// preencher com o valor
			// verificar formato de inser��o dos autores no objeto
			String financiadores = this.linhaDePesquisa.getFinanciadores();
			this.exibirFinanciadores.setText(financiadores);
			exibirFinanciadores.setEnabled(false);
		}
		return exibirFinanciadores;
	}

	public LinhaDePesquisa getLinhaDePesquisa() {
		return this.linhaDePesquisa;
	}

	public void setLinhaDePesquisa(LinhaDePesquisa linha) {
		this.linhaDePesquisa = linha;
	}

	/**
	 * This method initializes exibirLinks
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirLinks() {
		if (exibirLinks == null) {
			exibirLinks = new JTextField();
			exibirLinks.setBounds(new Rectangle(21, 354, 607, 20));
			String links = this.linhaDePesquisa.getLinksRelacionados();
			this.exibirLinks.setText(links);
			exibirLinks.setEnabled(false);
		}

		return exibirLinks;
	}

	/**
	 * This method initializes listaMembros
	 * 
	 * @return javax.swing.JList
	 */
	private JList getListaMembrosSelecionados() {
		if (this.listaMembrosSelecionados == null) {

			this.listModelMembrosSelecionados = new DefaultListModel();
			this.listaMembrosSelecionados = new JList(
					this.listModelMembrosSelecionados);
			this.listaMembrosSelecionados.setBounds(new Rectangle(23, 429, 243,
					95));

			Vector<String> membros = this.linhaDePesquisa.getNomeMembros();

			Iterator<String> itM = membros.iterator();

			String nome = "";

			while (itM.hasNext()) {
				nome = itM.next();
				listModelMembrosSelecionados.addElement(nome);
			}

		}
		return listaMembrosSelecionados;
	}

	/**
	 * This method initializes listaPublicacoes
	 * 
	 * @return javax.swing.JList
	 */
	private JList getListaPublicacoesSelecionadas() {
		if (this.listaPublicacoesSelecionadas == null) {

			this.listModelPublicacoesSelecionadas = new DefaultListModel();
			listaPublicacoesSelecionadas = new JList(
					this.listModelPublicacoesSelecionadas);
			listaPublicacoesSelecionadas.setBounds(new Rectangle(371, 425, 242,
					96));

			Vector<String> publicacoes = this.linhaDePesquisa.getPublicacoes();

			Iterator<String> itP = publicacoes.iterator();

			String titulo = "";

			while (itP.hasNext()) {
				titulo = itP.next();
				listModelPublicacoesSelecionadas.addElement(titulo);
			}

		}
		return listaPublicacoesSelecionadas;
	}

	/**
	 * This method initializes jToolBarPaginaInicial	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarPaginaInicial() {
		if (jToolBarPaginaInicial == null) {
			jToolBarPaginaInicial = new JToolBar();
			jToolBarPaginaInicial.setBounds(new Rectangle(603, 27, 64, 19));
			jToolBarPaginaInicial.add(getJButtonVoltarInicial());
		}
		return jToolBarPaginaInicial;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelExibirLinhaDePesquisa.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelExibirLinhaDePesquisa.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

} // @jve:decl-index=0:visual-constraint="10,10"