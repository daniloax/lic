package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import excecoes.ObjetoVazioException;
import excecoes.PublicacaoJaExistenteException;

import base.ArtigoEmConferencia;
import base.Membro;

public class PainelCadastroArtigoConferencia extends JPanel {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private FramePrincipal frame;
	private JLabel labelTitulo = null;
	private JTextField jTextFieldTitulo = null;
	private JLabel labelTitulo1 = null;
	private JTextField jTextFieldNomeConferencia = null;
	private JLabel labelAno = null;
	private JTextField jTextFieldUrlPdf = null;
	private JButton jButtonCarregaPdf = null;
	private JTextField jTextFieldAno = null;
	private JLabel labelAno1 = null;
	private JTextField jTextFieldMes = null;
	private JLabel labelAno11 = null;
	private JTextField jTextFieldPaginas = null;
	private JLabel labelAno2 = null;
	private JList jListAutores = null;
	private JList jListAutoresSelecionados = null;
	private JButton jButtonAdicionarAutor = null;
	private JButton jButtonRemoverAutor = null;
	private JLabel labelAno21 = null;
	private JTextField jTextFieldAutoresNaoMembros = null;
	private JButton jButtonCadastrar = null;
	private JButton jButtonCancelar = null;
	private JScrollPane scrollautores = null;
	private JScrollPane scrollautoresSelecionados = null;
	private Vector<Membro> membros = new Vector<Membro>();
	private Vector<Membro> autores = new Vector<Membro>();  //  @jve:decl-index=0:
	private Vector<Membro> autoresSelecionados = new Vector();  //  @jve:decl-index=0:
	private ArtigoEmConferencia artigo = new ArtigoEmConferencia();  //  @jve:decl-index=0:
	DefaultListModel listaAutores = null;
	DefaultListModel listaAutoresSelecionados = null;
	
	//LINHASDEPESQUISA
	private JLabel jLabel1 = null;
	private JList jListLinhas = null;
	private JList jListLinhasSelecionadas = null;
	private JButton jButtonEntrar = null;
	private JButton jButtonTirar = null;
	private DefaultListModel listModellinhas = null;
	private DefaultListModel listModellinhasSelecionadas = null;
	private JScrollPane scrollLinhas = null;
	private JScrollPane scrollLinhasSelecionadas = null;
	//LINHASDEPESQUISA
	/**
	 * This is the default constructor
	 */
	public PainelCadastroArtigoConferencia(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(18, 342, 190, 19));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelAno21 = new JLabel();
		labelAno21.setBounds(new Rectangle(18, 297, 280, 19));
		labelAno21.setText("Demais autores (nomes separados por v�rgula):");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 180, 190, 19));
		labelAno2.setText("Autores cadastrados no grupo:*");
		labelAno11 = new JLabel();
		labelAno11.setBounds(new Rectangle(261, 135, 64, 19));
		labelAno11.setText("P�ginas:");
		labelAno1 = new JLabel();
		labelAno1.setBounds(new Rectangle(117, 135, 46, 19));
		labelAno1.setText("M�s:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(18, 135, 46, 19));
		labelAno.setText(" Ano: *");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(18, 90, 136, 19));
		labelTitulo1.setText("Nome da confer�ncia: *");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 45, 91, 19));
		labelTitulo.setText("Titulo Artigo: *");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(18, 18, 271, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText("Cadastro de artigos em confer�ncias:");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(getJTextFieldTitulo(), null);
		this.add(labelTitulo1, null);
		this.add(getJTextFieldNomeConferencia(), null);
		this.add(labelAno, null);
		this.add(getJTextFieldUrlPdf(), null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(getJTextFieldAno(), null);
		this.add(labelAno1, null);
		this.add(getJTextFieldMes(), null);
		this.add(labelAno11, null);
		this.add(getJTextFieldPaginas(), null);
		this.add(labelAno2, null);
		
		this.add(getJListAutores(), null);
		this.scrollautores = new JScrollPane(this.jListAutores);
		this.scrollautores.setBounds(new Rectangle(18, 198, 271, 91));
		this.scrollautores.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollautores.setVisible(true);
		this.add(scrollautores);
		
		this.add(getJListAutoresSelecionados(), null);
		this.scrollautoresSelecionados = new JScrollPane(this.jListAutoresSelecionados);
		this.scrollautoresSelecionados.setBounds(new Rectangle(423, 198, 271, 91));
		this.scrollautoresSelecionados.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollautoresSelecionados.setVisible(true);
		this.add(scrollautoresSelecionados);
		this.add(getJButtonAdicionarAutor(), null);
		this.add(getJButtonRemoverAutor(), null);
		this.add(labelAno21, null);
		this.add(getJTextFieldAutoresNaoMembros(), null);
		this.add(getJButtonCadastrar(), null);
		this.add(getJButtonCancelar(), null);
		
		//LINHASDEPESQUISA
		this.add(jLabel1, null);
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 369, 271, 91));
		//this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		
		this.add(getJListLinhasSelecionadas(), null);
		this.scrollLinhasSelecionadas = new JScrollPane(this.jListLinhasSelecionadas);
		this.scrollLinhasSelecionadas.setBounds(new Rectangle(423, 369, 271, 91));
		//this.scrollLinhasSelecionadas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhasSelecionadas.setVisible(true);
		this.add(scrollLinhasSelecionadas);
		this.add(getJButtonEntrar(), null);
		this.add(getJButtonTirar(), null);
		//LINHASDEPESQUISA
	}

	/**
	 * This method initializes jTextFieldTitulo	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldTitulo() {
		if (jTextFieldTitulo == null) {
			jTextFieldTitulo = new JTextField();
			jTextFieldTitulo.setBounds(new Rectangle(18, 63, 361, 19));
		}
		return jTextFieldTitulo;
	}

	/**
	 * This method initializes jTextFieldNomeConferencia	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldNomeConferencia() {
		if (jTextFieldNomeConferencia == null) {
			jTextFieldNomeConferencia = new JTextField();
			jTextFieldNomeConferencia.setBounds(new Rectangle(18, 108, 361, 19));
		}
		return jTextFieldNomeConferencia;
	}

	/**
	 * This method initializes jTextFieldUrlPdf	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldUrlPdf() {
		if (jTextFieldUrlPdf == null) {
			jTextFieldUrlPdf = new JTextField();
			jTextFieldUrlPdf.setBounds(new Rectangle(459, 153, 208, 19));
		}
		return jTextFieldUrlPdf;
	}

	/**
	 * This method initializes jButtonCarregaPdf	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(468, 171, 190, 19));
			jButtonCarregaPdf.setText("Carregar arquivo pdf*");
			jButtonCarregaPdf.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelCadastroArtigoConferencia.this.carregaPdf();
				}
			});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf(){
		JFileChooser arquivo = new JFileChooser();
		int returnVal = arquivo.showOpenDialog(this);
		
		if(returnVal == JFileChooser.APPROVE_OPTION){
			File arq = arquivo.getSelectedFile();
			this.jTextFieldUrlPdf.setText(arq.getAbsolutePath());
			this.artigo.setUrlPdf(arq.getAbsolutePath());
			//this.artigo.setPdf(new File(arq.getAbsolutePath()));
			
		}
	}
	/**
	 * This method initializes jTextFieldAno	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAno() {
		if (jTextFieldAno == null) {
			jTextFieldAno = new JTextField();
			jTextFieldAno.setBounds(new Rectangle(18, 153, 64, 19));
		}
		return jTextFieldAno;
	}

	/**
	 * This method initializes jTextFieldMes	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldMes() {
		if (jTextFieldMes == null) {
			jTextFieldMes = new JTextField();
			jTextFieldMes.setBounds(new Rectangle(117, 153, 109, 19));
		}
		return jTextFieldMes;
	}

	/**
	 * This method initializes jTextFieldPaginas	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldPaginas() {
		if (jTextFieldPaginas == null) {
			jTextFieldPaginas = new JTextField();
			jTextFieldPaginas.setBounds(new Rectangle(261, 153, 118, 19));
		}
		return jTextFieldPaginas;
	}

	/**
	 * This method initializes jListAutores	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListAutores() {
		if (jListAutores == null) {
			
		    this.listaAutores = new DefaultListModel();
			jListAutores = new JList(listaAutores);
			jListAutores.setBounds(new Rectangle(18, 288, 271, 127));
			try {
				this.membros = this.frame.getFachada().retornaTodosMembros();
				this.autores = (Vector<Membro>) this.membros.clone();
				Iterator<Membro> it = autores.iterator();
				while(it.hasNext()){
					Membro x = it.next();
					listaAutores.addElement(x.getNome());
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return jListAutores;
	}

	/**
	 * This method initializes jListAutoresSelecionados	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListAutoresSelecionados() {
		if (jListAutoresSelecionados == null) {
			this.listaAutoresSelecionados = new DefaultListModel();
			jListAutoresSelecionados = new JList(listaAutoresSelecionados);
			jListAutoresSelecionados.setBounds(new Rectangle(414, 288, 271, 127));
		}
		return jListAutoresSelecionados;
	}

	/**
	 * This method initializes jButtonAdicionarAutor	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonAdicionarAutor() {
		if (jButtonAdicionarAutor == null) {
			jButtonAdicionarAutor = new JButton();
			jButtonAdicionarAutor.setBounds(new Rectangle(315, 198, 73, 37));
			jButtonAdicionarAutor.setText(">>");
			jButtonAdicionarAutor.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelCadastroArtigoConferencia.this.jListAutores.getSelectedIndex();
					String nomeAutor = (String) PainelCadastroArtigoConferencia.this.jListAutores.getSelectedValue();
					PainelCadastroArtigoConferencia.this.listaAutores.removeElementAt(indice);
					PainelCadastroArtigoConferencia.this.listaAutoresSelecionados.addElement(nomeAutor);
					
				}
			});
			
		}
		return jButtonAdicionarAutor;
	}

	/**
	 * This method initializes jButtonRemoverAutor	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonRemoverAutor() {
		if (jButtonRemoverAutor == null) {
			jButtonRemoverAutor = new JButton();
			jButtonRemoverAutor.setBounds(new Rectangle(315, 252, 73, 37));
			jButtonRemoverAutor.setText("<<");
			jButtonRemoverAutor.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelCadastroArtigoConferencia.this.jListAutoresSelecionados.getSelectedIndex();
					String nomeAutor = (String) PainelCadastroArtigoConferencia.this.jListAutoresSelecionados.getSelectedValue();
					PainelCadastroArtigoConferencia.this.listaAutores.addElement(nomeAutor);
					PainelCadastroArtigoConferencia.this.listaAutoresSelecionados.removeElementAt(indice);;
					
				}
			});
		}
		return jButtonRemoverAutor;
	}

	/**
	 * This method initializes jTextFieldAutoresNaoMembros	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldAutoresNaoMembros() {
		if (jTextFieldAutoresNaoMembros == null) {
			jTextFieldAutoresNaoMembros = new JTextField();
			jTextFieldAutoresNaoMembros.setBounds(new Rectangle(18, 315, 370, 19));
		}
		return jTextFieldAutoresNaoMembros;
	}

	/**
	 * This method initializes jButtonCadastrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCadastrar() {
		if (jButtonCadastrar == null) {
			jButtonCadastrar = new JButton();
			jButtonCadastrar.setBounds(new Rectangle(441, 477, 109, 28));
			jButtonCadastrar.setText("Cadastrar");
			jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					boolean camposObrigatorios = PainelCadastroArtigoConferencia.this.carregaArtigoConferencia();
					if(camposObrigatorios == true){
						try {
							PainelCadastroArtigoConferencia.this.frame.getFachada().inserirArtigoEmConferencia(PainelCadastroArtigoConferencia.this.artigo);
							JOptionPane.showMessageDialog(null,
									"Artigo cadastrado!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);
							PainelCadastroArtigoConferencia.this.frame.setContentPane(new PainelPublicacoes(PainelCadastroArtigoConferencia.this.frame));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ObjetoVazioException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (PublicacaoJaExistenteException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else{
						JOptionPane.showMessageDialog(null,
								"Campos obrigat�rios n�o preenchidos", "INFORMA��O",
								JOptionPane.WARNING_MESSAGE);
					}
				}
			});
		}
		return jButtonCadastrar;
	}
	
	public boolean carregaArtigoConferencia(){
		boolean camposObrigatorios = true;
		int tamanho = this.listaAutoresSelecionados.getSize();
		Vector<String> v = new Vector();
		for(int i = 0; i < tamanho; i++){
			String autor = (String) this.listaAutoresSelecionados.getElementAt(i);
			v.add(autor);
		}
			this.artigo.setNomeAutoresMembros(v);
			String titulo = this.jTextFieldTitulo.getText().trim().toUpperCase();
			this.artigo.setTitulo(titulo);
			String nomeConferencia = this.jTextFieldNomeConferencia.getText().trim().toUpperCase();
			this.artigo.setConferencia(nomeConferencia);
			String ano = this.jTextFieldAno.getText().trim().toUpperCase();
			this.artigo.setAno(ano);
			String mes = this.jTextFieldMes.getText().trim().toUpperCase();
			this.artigo.setMes(mes);
			String paginas = this.jTextFieldPaginas.getText().trim().toUpperCase();
			this.artigo.setPaginas(paginas);
			String autoresNaoMembros = this.jTextFieldAutoresNaoMembros.getText().trim().toUpperCase();
			this.artigo.setAutoresNaoMembros(autoresNaoMembros);
			
			
			//LINHASDEPESQUISA
			Vector<String> linhas = new Vector<String>();
			for(int i = 0; i < this.listModellinhasSelecionadas.size(); i++){
				String linha = (String)this.listModellinhasSelecionadas.elementAt(i);
				linhas.add(linha);
			}
			this.artigo.setLinhasDePesquisa(linhas);
			//LINHASDEPESQUISA
			if(v.isEmpty() || titulo.equals("") || nomeConferencia.equals("") || ano.equals("") ||
					(this.artigo.getUrlPdf()== null)){
			camposObrigatorios = false;
			}
			
			
		return camposObrigatorios;
	}
	/**
	 * This method initializes jButtonCancelar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(576, 477, 109, 28));
			jButtonCancelar.setText("Cancelar");
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelCadastroArtigoConferencia.this.frame.setContentPane(new PainelPublicacoes(PainelCadastroArtigoConferencia.this.frame));
				}
			});
		}
		return jButtonCancelar;
	}
	
	//LINHASDEPESQUISA
	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			this.listModellinhas = new DefaultListModel();
			jListLinhas = new JList(this.listModellinhas);
			jListLinhas.setBounds(new Rectangle(18, 369, 271, 91));
			
			try {
				Vector<String> linhas = this.frame.getFachada().retornaTodasLinhasDePesquisa();
				for(int i = 0; i < linhas.size(); i++){
					String linha = linhas.elementAt(i);
					this.listModellinhas.addElement(linha);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhas;
	}

	/**
	 * This method initializes jListLinhasSelecionadas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhasSelecionadas() {
		if (jListLinhasSelecionadas == null) {
			this.listModellinhasSelecionadas = new DefaultListModel();
			jListLinhasSelecionadas = new JList(this.listModellinhasSelecionadas);
			jListLinhasSelecionadas.setBounds(new Rectangle(423, 369, 271, 91));
		}
		return jListLinhasSelecionadas;
	}

	/**
	 * This method initializes jButtonEntrar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonEntrar() {
		if (jButtonEntrar == null) {
			jButtonEntrar = new JButton();
			jButtonEntrar.setBounds(new Rectangle(315, 369, 73, 37));
			jButtonEntrar.setText(">>");
			jButtonEntrar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelCadastroArtigoConferencia.this.jListLinhas.getSelectedIndex();
					String nomeAutor = (String) PainelCadastroArtigoConferencia.this.jListLinhas.getSelectedValue();
					PainelCadastroArtigoConferencia.this.listModellinhas.removeElementAt(indice);
					PainelCadastroArtigoConferencia.this.listModellinhasSelecionadas.addElement(nomeAutor);
				}
			});
		}
		return jButtonEntrar;
	}

	/**
	 * This method initializes jButtonTirar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonTirar() {
		if (jButtonTirar == null) {
			jButtonTirar = new JButton();
			jButtonTirar.setBounds(new Rectangle(315, 423, 73, 37));
			jButtonTirar.setText("<<");
			jButtonTirar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int indice = (int) PainelCadastroArtigoConferencia.this.jListLinhasSelecionadas.getSelectedIndex();
					String nomeAutor = (String) PainelCadastroArtigoConferencia.this.jListLinhasSelecionadas.getSelectedValue();
					PainelCadastroArtigoConferencia.this.listModellinhasSelecionadas.removeElementAt(indice);
					PainelCadastroArtigoConferencia.this.listModellinhas.addElement(nomeAutor);
				}
			});
		}
		return jButtonTirar;
	}
	//LINHASDEPESQUISA
}  //  @jve:decl-index=0:visual-constraint="10,10"
