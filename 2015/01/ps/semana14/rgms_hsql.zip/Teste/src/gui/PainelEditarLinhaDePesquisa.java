package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import com.sun.org.apache.bcel.internal.generic.NEW;

import excecoes.LinhaDePesquisaNaoEncontradaException;
import excecoes.ObjetoVazioException;
import excecoes.ParametroVazioException;

import base.ArtigoEmConferencia;
import base.LinhaDePesquisa;
import base.Membro;

public class PainelEditarLinhaDePesquisa extends JPanel {

	private LinhaDePesquisa linhaDePesquisa; // @jve:decl-index=0:

	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;

	private JLabel labelDescBreve = null;
	private JLabel labelDescDet = null;
	private JLabel labelFinanciadores = null;
	private JButton jButtonCancelar = null;
	private JButton jButtonAtualizar = null;
	private JTextField exibirTitulo = null;
	private JTextField exibirDescBreve = null;
	private JTextField exibirDescDet = null;
	private JTextField exibirFinanciadores = null;

	private JLabel links = null;

	private JTextField exibirLinks = null;

	/**
	 * This is the default constructor
	 */
	public PainelEditarLinhaDePesquisa(FramePrincipal frame, LinhaDePesquisa linha) {
		super();
		this.frame = frame;
		this.linhaDePesquisa = linha;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		links = new JLabel();
		links.setBounds(new Rectangle(18, 234, 118, 16));
		links.setText(" Links relacionados:");
		labelFinanciadores = new JLabel();
		labelFinanciadores.setBounds(new Rectangle(18, 189, 95, 19));
		labelFinanciadores.setText(" Financiadores:");
		labelDescDet = new JLabel();
		labelDescDet.setBounds(new Rectangle(18, 144, 130, 19));
		labelDescDet.setText(" Descri��o detalhada: ");
		labelDescBreve = new JLabel();
		labelDescBreve.setBounds(new Rectangle(18, 99, 105, 19));
		labelDescBreve.setText(" Descri��o breve:");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 54, 43, 19));
		labelTitulo.setText(" Titulo: ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 222, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Detalhes da linha de pesquisa");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelDescBreve, null);
		this.add(labelDescDet, null);
		this.add(labelFinanciadores, null);

		this.add(getJButtonCancelar(), null);
		this.add(getJButtonAtualizar(), null);
		this.add(getExibirTitulo(), null);
		this.add(getExibirDescricaoBreve(), null);
		this.add(getExibirDescricaoDetalhada(), null);
		this.add(getExibirFinanciadores(), null);
		this.add(links, null);
		this.add(getExibirLinks(), null);
	}

	/**
	 * This method initializes jButtonCadastrar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(522, 531, 109, 19));
			jButtonCancelar.setText("Cancelar");
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
			PainelEditarLinhaDePesquisa.this.frame.setContentPane(new PainelExibirLinhaDePesquisa(PainelEditarLinhaDePesquisa.this.frame , PainelEditarLinhaDePesquisa.this.linhaDePesquisa));
			

						}
					});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes jButtonCancelar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonAtualizar() {
		if (jButtonAtualizar == null) {
			jButtonAtualizar = new JButton();
			jButtonAtualizar.setBounds(new Rectangle(387, 531, 109, 19));
			jButtonAtualizar.setText("Salvar");

			jButtonAtualizar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

			boolean camposObrigatorios = PainelEditarLinhaDePesquisa.this.atualizarLinhaDePesquisa();

					if (camposObrigatorios == true) {

					try {
						PainelEditarLinhaDePesquisa.this.frame.getFachada().editarLinhaDePesquisa(PainelEditarLinhaDePesquisa.this.linhaDePesquisa);
						JOptionPane.showMessageDialog(null,
								"Linha de Pesquisa atualizada!",
								"INFORMATION",
								JOptionPane.INFORMATION_MESSAGE);
						PainelEditarLinhaDePesquisa.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelEditarLinhaDePesquisa.this.frame));
					
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ObjetoVazioException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ParametroVazioException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (LinhaDePesquisaNaoEncontradaException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

						

						// adaptar chamada abaixo:
						// PainelCadastroArtigoPeriodicoRevista.this.frame.setContentPane(new
						// PainelPublicacoes(PainelCadastroArtigoPeriodicoRevista.this.frame));

					} else {

						JOptionPane.showMessageDialog(null,
								"Campos obrigatorios nao preenchidos",
								"INFORMATION",
								JOptionPane.WARNING_MESSAGE);

					}


						}
					});
		}
		return jButtonAtualizar;
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTitulo() {
		if (exibirTitulo == null) {
			exibirTitulo = new JTextField();
			exibirTitulo.setBounds(new Rectangle(18, 72, 609, 20));
			// preenche com o valor
			String titulo = this.linhaDePesquisa.getTitulo();
			exibirTitulo.setText(titulo);
			exibirTitulo.setEnabled(true);
		}
		return exibirTitulo;
	}

	/**
	 * This method initializes exibirConferencia
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirDescricaoBreve() {
		if (exibirDescBreve == null) {
			exibirDescBreve = new JTextField();
			exibirDescBreve.setBounds(new Rectangle(18, 117, 608, 20));
			// preenche com o valor
			String descBreve = this.linhaDePesquisa.getDescricaoBreve();
			exibirDescBreve.setText(descBreve);
			exibirDescBreve.setEnabled(true);

		}
		return exibirDescBreve;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirDescricaoDetalhada() {
		if (exibirDescDet == null) {
			exibirDescDet = new JTextField();
			exibirDescDet.setBounds(new Rectangle(18, 162, 607, 20));
			// preenche com o valor
			String descDet = this.linhaDePesquisa.getDescricaoDetalhada();
			exibirDescDet.setText(descDet);
			exibirDescDet.setEnabled(true);
		}
		return exibirDescDet;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirFinanciadores() {
		if (exibirFinanciadores == null) {
			exibirFinanciadores = new JTextField();
			exibirFinanciadores.setBounds(new Rectangle(18, 207, 607, 20));
			// preencher com o valor
			// verificar formato de inser��o dos autores no objeto
			String financiadores = this.linhaDePesquisa.getFinanciadores();
			this.exibirFinanciadores.setText(financiadores);
			exibirFinanciadores.setEnabled(true);
		}
		return exibirFinanciadores;
	}

	public LinhaDePesquisa getLinhaDePesquisa() {
		return this.linhaDePesquisa;
	}

	public void setLinhaDePesquisa(LinhaDePesquisa linha) {
		this.linhaDePesquisa = linha;
	}

	/**
	 * This method initializes exibirLinks
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirLinks() {
		if (exibirLinks == null) {
			exibirLinks = new JTextField();
			exibirLinks.setBounds(new Rectangle(18, 252, 607, 20));
			String links = this.linhaDePesquisa.getLinksRelacionados();
			this.exibirLinks.setText(links);
			exibirLinks.setEnabled(true);
		}

		return exibirLinks;
	}



	public boolean atualizarLinhaDePesquisa() {
		boolean camposObrigatorios = true;

		

		String titulo = this.getExibirTitulo().getText().trim().toUpperCase();
		this.linhaDePesquisa.setTitulo(titulo);

		String descricaoBreve = this.exibirDescBreve.getText().trim()
				.toUpperCase();
		this.linhaDePesquisa.setDescricaoBreve(descricaoBreve);

		String descricaoDetalhada = this.exibirDescDet.getText()
				.trim().toUpperCase();
		this.linhaDePesquisa.setDescricaoDetalhada(descricaoDetalhada);

		String financiadores = this.exibirFinanciadores.getText().trim()
				.toUpperCase();
		this.linhaDePesquisa.setFinanciadores(financiadores);

		String links = this.exibirLinks.getText().trim().toUpperCase();
		this.linhaDePesquisa.setLinksRelacionados(links);

		if (titulo.equals("") || descricaoBreve.equals("")) {
			camposObrigatorios = false;
		}

		return camposObrigatorios;
	}


}  //  @jve:decl-index=0:visual-constraint="-19,12"