package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;

import java.awt.Desktop;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.Membro;
import java.lang.String;
import javax.swing.JToolBar;

public class PainelExibirDissertacaoMestrado extends JPanel {

	private DissertacaoDeMestrado dis ; // @jve:decl-index=0:

	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;

	private JLabel labelTitulo1 = null;
	private JLabel labelAno = null;
	private JButton jButtonCarregaPdf = null;
	private JLabel labelAno2 = null;
	private JButton jButtonRemover = null;
	private JButton jButtonCancelar = null;
	private JTextField exibirTitulo = null;
	private JTextField exibirInstituicao = null;
	private JTextField exibirAno = null;
	private JTextField exibirAutores = null;

	private JLabel labelMes = null;

	private JTextField exibirMes = null;

	private JToolBar jToolBarPaginaInicial = null;

	private JButton jButtonVoltarInicial = null;
	
	//LINHASDEPESQUISA
	private JLabel jLabel1 = null;

	private JList jListLinhas = null;
	
	private JScrollPane scrollLinhas = null;
	//LINHASDEPESQUISA
	/**
	 * This is the default constructor
	 */
	public PainelExibirDissertacaoMestrado(FramePrincipal frame, DissertacaoDeMestrado artigo) {
		super();
		this.frame = frame;
		this.dis = artigo;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel1 = new JLabel();
		jLabel1.setBounds(new Rectangle(18, 315, 190, 19));
		jLabel1.setText("Linhas de pesquisa associadas:");
		labelMes = new JLabel();
		labelMes.setBounds(new Rectangle(108, 171, 41, 19));
		labelMes.setText(" M�s: ");
		labelAno2 = new JLabel();
		labelAno2.setBounds(new Rectangle(18, 234, 57, 19));
		labelAno2.setText(" Autor:");
		labelAno = new JLabel();
		labelAno.setBounds(new Rectangle(18, 171, 46, 19));
		labelAno.setText(" Ano: ");
		labelTitulo1 = new JLabel();
		labelTitulo1.setBounds(new Rectangle(18, 108, 70, 19));
		labelTitulo1.setText(" Institui��o: ");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 54, 116, 19));
		labelTitulo.setText(" Titulo Disserta��o: ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(18, 27, 183, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText(" Detalhes da disserta��o");
		this.setSize(712, 587);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(labelTitulo1, null);
		this.add(labelAno, null);
		this.add(getJButtonCarregaPdf(), null);
		this.add(labelAno2, null);

		this.add(getJButtonRemover(), null);
		this.add(getJButtonEditar(), null);
		this.add(getExibirTitulo(), null);
		this.add(getExibirInstituicao(), null);
		this.add(getExibirAno(), null);
		this.add(getExibirAutores(), null);
		this.add(labelMes, null);
		this.add(getExibirMes(), null);
		this.add(getJToolBarPaginaInicial(), null);
		//LINHASDEPESQUISA
		this.add(jLabel1, null);
		this.add(getJListLinhas(), null);
		this.scrollLinhas = new JScrollPane(this.jListLinhas);
		this.scrollLinhas.setBounds(new Rectangle(18, 342, 343, 73));
		//this.scrollLinhas.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);  
		this.scrollLinhas.setVisible(true);
		this.add(scrollLinhas);
		//LINHASDEPESQUISA
	}

	/**
	 * This method initializes jButtonCarregaPdf
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonCarregaPdf() {
		if (jButtonCarregaPdf == null) {
			jButtonCarregaPdf = new JButton();
			jButtonCarregaPdf.setBounds(new Rectangle(441, 288, 190, 19));
		jButtonCarregaPdf.setText("Visualizar artigo em pdf");
			jButtonCarregaPdf
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							PainelExibirDissertacaoMestrado.this.carregaPdf();
						}
					});
		}
		return jButtonCarregaPdf;
	}

	public void carregaPdf() {

		try {
			Desktop.getDesktop().open(this.dis.getPdf());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This method initializes jButtonCadastrar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonRemover() {
		if (jButtonRemover == null) {
			jButtonRemover = new JButton();
			jButtonRemover.setBounds(new Rectangle(428, 450, 109, 28));
			jButtonRemover.setText("Remover");
			jButtonRemover
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							// chamar m�todo para remover artigo do bd
							// n�o � preciso carregar outra tela, apenas exibir
							// uma msg de confirma��o da remo��o

							JOptionPane.showMessageDialog(null,
									"Publica��o removida!", "INFORMA��O",
									JOptionPane.INFORMATION_MESSAGE);

						}
					});
		}
		return jButtonRemover;
	}

	/**
	 * This method initializes jButtonCancelar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonEditar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(570, 450, 109, 28));
			jButtonCancelar.setText("Editar");

			jButtonCancelar
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {
							PainelExibirDissertacaoMestrado.this.frame.setContentPane(new PainelEditarDissertacaoMestrado(PainelExibirDissertacaoMestrado.this.frame , PainelExibirDissertacaoMestrado.this.dis));
							// chamar tela de edi��o (tela de cadastro s� que
							// com os campos preenchidos)

						}
					});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTitulo() {
		if (exibirTitulo == null) {
			exibirTitulo = new JTextField();
			exibirTitulo.setBounds(new Rectangle(18, 81, 609, 20));
			// preenche com o valor
			String titulo = this.dis.getTitulo();
			exibirTitulo.setText(titulo);
			exibirTitulo.setEnabled(false);
		}
		return exibirTitulo;
	}

	/**
	 * This method initializes exibirInstituicao
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirInstituicao() {
		if (exibirInstituicao == null) {
			exibirInstituicao = new JTextField();
			exibirInstituicao.setBounds(new Rectangle(22, 138, 608, 20));
			// preenche com o valor
			String instituicao = this.dis.getInstituicao();
			exibirInstituicao.setText(instituicao);
			exibirInstituicao.setEnabled(false);

		}
		return exibirInstituicao;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAno() {
		if (exibirAno == null) {
			exibirAno = new JTextField();
			exibirAno.setBounds(new Rectangle(22, 199, 60, 20));
			// preenche com o valor
			String ano = this.dis.getAno();
			exibirAno.setText(ano);
			exibirAno.setEnabled(false);
		}
		return exibirAno;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAutores() {
		if (exibirAutores == null) {
			exibirAutores = new JTextField();
			exibirAutores.setBounds(new Rectangle(18, 261, 605, 20));
			// preencher com o valor
			String autor = this.dis.getAutoresMembros();
			exibirAutores.setText(autor);
			exibirAutores.setEnabled(false);
		}
		return exibirAutores;
	}

	public DissertacaoDeMestrado getDissertacao() {
		return dis;
	}

	public void setDissertacao(DissertacaoDeMestrado dis) {
		this.dis = dis;
	}

	/**
	 * This method initializes exibirMes
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirMes() {
		if (exibirMes == null) {
			exibirMes = new JTextField();
			exibirMes.setBounds(new Rectangle(117, 198, 78, 20));
			// preencher com o valor
			String mes = this.dis.getMes();
			exibirMes.setText(mes);
			exibirMes.setEnabled(false);
		}
		return exibirMes;
	}

	/**
	 * This method initializes jToolBarPaginaInicial	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarPaginaInicial() {
		if (jToolBarPaginaInicial == null) {
			jToolBarPaginaInicial = new JToolBar();
			jToolBarPaginaInicial.setBounds(new Rectangle(612, 27, 64, 19));
			jToolBarPaginaInicial.add(getJButtonVoltarInicial());
		}
		return jToolBarPaginaInicial;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelExibirDissertacaoMestrado.this.frame.setContentPane(new PainelPublicacoes(PainelExibirDissertacaoMestrado.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

	/**
	 * This method initializes jListLinhas	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJListLinhas() {
		if (jListLinhas == null) {
			DefaultListModel listModelLinhas = new DefaultListModel();
			jListLinhas = new JList(listModelLinhas);
			jListLinhas.setBounds(new Rectangle(18, 342, 343, 73));
			try {
				Vector<String> linhas = this.frame.getFachada().retornaLinhasDeUmaPublicacao(this.dis.getTitulo());
				for(int i = 0; i< linhas.size(); i++){
					listModelLinhas.addElement(linhas.elementAt(i));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jListLinhas;
	}
}  //  @jve:decl-index=0:visual-constraint="17,9"
