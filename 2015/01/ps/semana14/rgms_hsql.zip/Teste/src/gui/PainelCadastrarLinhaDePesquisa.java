package gui;

import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.ListSelectionModel;

import base.ArtigoEmConferencia;
import base.ArtigoEmPeriodicoERevista;
import base.DissertacaoDeMestrado;
import base.LinhaDePesquisa;
import base.Membro;
import base.TeseDeDoutorado;

import java.lang.String;
import javax.swing.JToolBar;

import excecoes.LinhaDePesquisaJaExistenteException;
import excecoes.ObjetoVazioException;

public class PainelCadastrarLinhaDePesquisa extends JPanel {

	private LinhaDePesquisa linhaDePesquisa = new LinhaDePesquisa(); // @jve:decl-index=0:
	private FramePrincipal frame;
	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JLabel labelTitulo = null;

	private JLabel descricaoBreve = null;
	private JLabel descricaoDetalhada = null;
	private JLabel financiadores = null;
	private JButton jButtonCancelar = null;
	private JButton jButtonCadastrar = null;
	private JTextField exibirTitulo = null;
	private JTextField campoDescricaoBreve = null;
	private JTextField campoDescricaoDetalhada = null;
	private JTextField exibirFinanciadores = null;
	private JLabel labelLinks = null;
	private JTextField campoLinks = null;

	/*
	 * private JList listaMembros = null; private DefaultListModel
	 * listModelMembros = null; private JScrollPane scrollMembros = null;
	 */
	

	// ideia de paola: fazer o msm pra publica��es, s� que no <> do vector
	// colocar ArtigoEmConferencia

	private Vector<ArtigoEmConferencia> publicacoes = new Vector<ArtigoEmConferencia>(); // @jve:decl-index=0:
	private Vector<ArtigoEmConferencia> publicacoesDaLista = new Vector<ArtigoEmConferencia>();  //  @jve:decl-index=0:
	private DefaultListModel listModelPublicacoes = null;

	private DefaultListModel listModelPublicacoesSelecionadas = null;
	private JToolBar jToolBarTeste = null;
	private JButton jButtonVoltarInicial = null;

	/**
	 * This is the default constructor
	 */
	public PainelCadastrarLinhaDePesquisa(FramePrincipal frame) {
		super();
		this.frame = frame;
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		labelLinks = new JLabel();
		labelLinks.setBounds(new Rectangle(18, 243, 254, 16));
		labelLinks.setText(" Links relacionados (separados por v�rgula):");
		financiadores = new JLabel();
		financiadores.setBounds(new Rectangle(18, 198, 92, 19));
		financiadores.setText(" Financiadores:");
		descricaoDetalhada = new JLabel();
		descricaoDetalhada.setBounds(new Rectangle(18, 153, 132, 19));
		descricaoDetalhada.setText(" Descri��o detalhada: ");
		descricaoBreve = new JLabel();
		descricaoBreve.setBounds(new Rectangle(18, 99, 104, 19));
		descricaoBreve.setText(" Descri��o breve: ");
		labelTitulo = new JLabel();
		labelTitulo.setBounds(new Rectangle(18, 54, 42, 19));
		labelTitulo.setText(" Titulo: ");
		jLabel = new JLabel();
		jLabel.setBounds(new Rectangle(9, 27, 226, 19));
		jLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		jLabel.setText("Cadastro da Linha de Pesquisa:");
		this.setSize(693, 549);
		this.setLayout(null);
		this.add(jLabel, null);
		this.add(labelTitulo, null);
		this.add(descricaoBreve, null);
		this.add(descricaoDetalhada, null);
		this.add(financiadores, null);

		this.add(getJButtonCancelar(), null);
		this.add(getJButtonCadastrar(), null);
		this.add(getExibirTitulo(), null);
		this.add(getDescricaoBreve(), null);
		this.add(getDescricaoDetalhada(), null);
		this.add(getExibirAutores(), null);
		this.add(labelLinks, null);
		this.add(getCampoLinks(), null);

		this.add(getJToolBarTeste(), null);
	}

	
	

	public void carregaPdf() {

		// incluir trecho de c�digo para abrir pdf com visualizar padr�o em java
	}

	/**
	 * This method initializes jButtonCadastrar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonCancelar() {
		if (jButtonCancelar == null) {
			jButtonCancelar = new JButton();
			jButtonCancelar.setBounds(new Rectangle(504, 504, 109, 28));
			jButtonCancelar.setText("Cancelar");
			jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

			PainelCadastrarLinhaDePesquisa.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelCadastrarLinhaDePesquisa.this.frame));

						}
					});
		}
		return jButtonCancelar;
	}

	/**
	 * This method initializes jButtonCancelar
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonCadastrar() {
		if (jButtonCadastrar == null) {
			jButtonCadastrar = new JButton();
			jButtonCadastrar.setBounds(new Rectangle(369, 504, 109, 28));
			jButtonCadastrar.setText("Cadastrar");

			jButtonCadastrar.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(java.awt.event.ActionEvent e) {

							boolean camposObrigatorios = PainelCadastrarLinhaDePesquisa.this.carregaLinhaDePesquisa();

							if (camposObrigatorios == true) {

								try {
									PainelCadastrarLinhaDePesquisa.this.frame.getFachada().inserirLinhaDePesquisa(PainelCadastrarLinhaDePesquisa.this.linhaDePesquisa);
									JOptionPane.showMessageDialog(null,
											"Linha de Pesquisa cadastrada!",
											"INFORMATION",
											JOptionPane.INFORMATION_MESSAGE);
									PainelCadastrarLinhaDePesquisa.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelCadastrarLinhaDePesquisa.this.frame));
								
								} catch (SQLException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} catch (ClassNotFoundException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} catch (ObjetoVazioException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} catch (LinhaDePesquisaJaExistenteException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
							} else {

								JOptionPane.showMessageDialog(null,
										"Campos obrigatorios nao preenchidos",
										"INFORMATION",
										JOptionPane.WARNING_MESSAGE);

							}

						}
					});
		}
		return jButtonCadastrar;
	}

	/**
	 * This method initializes exibirTitulo
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirTitulo() {
		if (exibirTitulo == null) {
			exibirTitulo = new JTextField();
			exibirTitulo.setBounds(new Rectangle(18, 72, 609, 20));

		}
		return exibirTitulo;
	}

	/**
	 * This method initializes exibirInstituicao
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getDescricaoBreve() {
		if (campoDescricaoBreve == null) {
			campoDescricaoBreve = new JTextField();
			campoDescricaoBreve.setBounds(new Rectangle(18, 117, 608, 20));
			// preenche com o valor

		}
		return campoDescricaoBreve;
	}

	/**
	 * This method initializes exibirAno
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getDescricaoDetalhada() {
		if (campoDescricaoDetalhada == null) {
			campoDescricaoDetalhada = new JTextField();
			campoDescricaoDetalhada.setBounds(new Rectangle(18, 171, 607, 20));
			// preenche com o valor

		}
		return campoDescricaoDetalhada;
	}

	/**
	 * This method initializes exibirAutores
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getExibirAutores() {
		if (exibirFinanciadores == null) {
			exibirFinanciadores = new JTextField();
			exibirFinanciadores.setBounds(new Rectangle(18, 216, 605, 20));
			// preencher com o valor

		}
		return exibirFinanciadores;
	}

	/**
	 * This method initializes campoLinks
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getCampoLinks() {
		if (campoLinks == null) {
			campoLinks = new JTextField();
			campoLinks.setBounds(new Rectangle(18, 261, 603, 20));
		}
		return campoLinks;
	}

	/**
	 * This method initializes listaMembros
	 * 
	 * @return javax.swing.JList
	 */

	public boolean carregaLinhaDePesquisa() {
		boolean camposObrigatorios = true;

		

		

		String titulo = this.getExibirTitulo().getText().trim().toUpperCase();
		this.linhaDePesquisa.setTitulo(titulo);

		String descricaoBreve = this.getDescricaoBreve().getText().trim().toUpperCase();
		this.linhaDePesquisa.setDescricaoBreve(descricaoBreve);

		String descricaoDetalhada = this.getDescricaoDetalhada().getText().trim().toUpperCase();
		this.linhaDePesquisa.setDescricaoDetalhada(descricaoDetalhada);

		String financiadores = this.exibirFinanciadores.getText().trim().toUpperCase();
		this.linhaDePesquisa.setFinanciadores(financiadores);

		String links = this.campoLinks.getText().trim().toUpperCase();
		this.linhaDePesquisa.setLinksRelacionados(links);

		if (titulo.equals("") || descricaoBreve.equals("")) {
			camposObrigatorios = false;
		}

		return camposObrigatorios;
	}

	/**
	 * This method initializes jToolBarTeste	
	 * 	
	 * @return javax.swing.JToolBar	
	 */
	private JToolBar getJToolBarTeste() {
		if (jToolBarTeste == null) {
			jToolBarTeste = new JToolBar();
			jToolBarTeste.setBounds(new Rectangle(558, 27, 64, 19));
			jToolBarTeste.add(getJButtonVoltarInicial());
		}
		return jToolBarTeste;
	}

	/**
	 * This method initializes jButtonVoltarInicial	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonVoltarInicial() {
		if (jButtonVoltarInicial == null) {
			jButtonVoltarInicial = new JButton();
			jButtonVoltarInicial.setFont(new Font("Dialog", Font.BOLD, 10));
			jButtonVoltarInicial.setText("Voltar");
			jButtonVoltarInicial.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					PainelCadastrarLinhaDePesquisa.this.frame.setContentPane(new PainelLinhasDePesquisa(PainelCadastrarLinhaDePesquisa.this.frame));
				}
			});
		}
		return jButtonVoltarInicial;
	}

}  //  @jve:decl-index=0:visual-constraint="10,2"
