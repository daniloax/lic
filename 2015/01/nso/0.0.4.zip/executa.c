#include "executa.h"

int main(int argc, char *argv[]) {
   
   char *pshm, identificador[10];
   int idsem, idshm, key, status, pid;
   
   // sprintf(idsem, "%d", argv[1]);
   
   key = atoi(argv[1]);
   idshm = atoi(argv[2]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      
      printf("erro ao obter semaforo\n");
      exit(1);

   }
   
   /** attach */
   pshm = shmat(idshm, (char *) 0, 0);
   
   // printf("./%s\n", argv[0]);
   // printf("%s\n", argv[1]);
   // printf("%d\n", idsem);
   
   /** cria processo filho */
   /* pid = fork();
   
   if (pid == 0) {
      
      v_sem(idsem);
      
      printf("filho - obtive o semaforo, vou dormir\n");
      sleep(1);
      printf("filho - dormi\n");
      
      p_sem(idsem);
      
      exit(0);
      
   } */
   
   p_sem(idsem);
   
   /** codigo do pai */

   while (1) {
   
      v_sem(idsem);
      
      printf("\n%s - obtive o semaforo, vou dormir\n", argv[0]);
      sleep(1);
      printf("%s - dormi\n", argv[0]);
      sleep(1);
      printf("%s - vou ler\n", argv[0]);
      sleep(1);
      printf("%s - li\n", argv[0]);
      sleep(1);
      printf("%s - valor lido = %s\n", argv[0], pshm);
      sleep(1);
      printf("%s - vou escrever\n", argv[0]);
      sleep(1);
      
      sprintf(identificador, "%d", getpid());
      *pshm = calloc(strlen(identificador), sizeof(char));
      strcpy(pshm, identificador);
      
      printf("%s - escrevi\n", argv[0]);
      
      p_sem(idsem);
   
   }
   // wait(&status);
   
   /** detach */
   if (shmdt(pshm) == -1)
      printf("The shmdt call failed!, error number = %d\n", errno);

   else
      printf("The shmdt call succeeded!\n");
   
   return 0;
   
}
