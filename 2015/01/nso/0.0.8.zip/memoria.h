#ifndef MEMORIA_H_
#define MEMORIA_H_

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

struct shmid_ds buf;

#endif /* MEMORIA_H_ */
