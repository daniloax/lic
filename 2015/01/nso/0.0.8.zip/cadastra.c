#include "cadastra.h"

int main(int argc, char *argv[]) {
   
   printf("%s %s %s\n", argv[0], argv[3], argv[4]);
   
   return 0;
   
}
