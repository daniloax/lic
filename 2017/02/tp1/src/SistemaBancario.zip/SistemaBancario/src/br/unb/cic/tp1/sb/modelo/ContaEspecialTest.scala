package br.unb.cic.tp1.sb.modelo

import org.scalatest.FunSuite

class ContaEspecialTest extends FunSuite {
  test("Teste para o construtor") {
    val conta01 = new ContaEspecial(100, 50)
    assert(conta01.saldo == 100)
    
    try { 
      val conta02 = new ContaEspecial(-50, 50)
      fail()
    }
    catch {
      case e: IllegalArgumentException => succeed
    }
  }
  
  test("operacao debitar") {
    val conta01 = new ContaEspecial(100, 50)
    conta01.debitar(100)
    assert(conta01.saldo == 0)
    
    conta01.debitar(40)
    assert(conta01.saldo == -40)
    
    conta01.debitar(10)
    assert(conta01.saldo == -50)
    
    try {
      conta01.debitar(1)
      fail()
    }
    catch {
      case e : IllegalArgumentException => succeed
    }
  }
}