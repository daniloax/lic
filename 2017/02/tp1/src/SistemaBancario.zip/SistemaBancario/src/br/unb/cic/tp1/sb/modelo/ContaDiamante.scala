package br.unb.cic.tp1.sb.modelo

class ContaDiamante(val _s : Double) extends ContaCorrente(_s) {
  override def debitar(valor : Double) : Unit = {
    _saldo -= valor
  }
}