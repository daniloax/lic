package br.unb.cic.tp1.sb

import scala.io.StdIn
import br.unb.cic.tp1.sb.repositorio.RepositorioDeContas
import br.unb.cic.tp1.sb.modelo.ContaCorrente

object Main extends App {
  println("Informe o ID da conta corrente")
  val idx = StdIn.readInt()
  
  println("Informe o valor a ser debitado")
  val valor = StdIn.readDouble()
  
  val c = RepositorioDeContas.pesquisaContaCorrente(idx)
  println("saldo inicial: "  + c.saldo)
  
  c.debitar(valor)
  
  println("saldo final: " + c.saldo)
  
}