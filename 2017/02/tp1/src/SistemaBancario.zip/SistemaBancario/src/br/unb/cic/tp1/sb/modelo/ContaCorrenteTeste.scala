package br.unb.cic.tp1.sb.modelo

import org.scalatest.FunSuite

class ContaCorrenteTeste extends FunSuite  {
  
  test("construtor da classe conta corrente") {
    val conta01: ContaCorrente  = new ContaCorrente(20.0)
  
    assert(conta01.saldo == 20.0)
    
    try {
      val conta02 : ContaCorrente = new ContaCorrente(-10)
      fail()
    }
    catch {
      case e : IllegalArgumentException => succeed
    }
    
  }
  test ("Operacao debitar") {
    val conta01 = new ContaCorrente(500)
    conta01.debitar(100)
    assert(conta01.saldo==400)
    
    try {
      conta01.debitar(400.5)
      conta01.debitar(-10)
      fail()
    }
    catch {
      case e : IllegalArgumentException => succeed 
    }
  }
  
  test("Operacao debitar com valor negativo") {
    val conta01 = new ContaCorrente(500)
    try {
      conta01.debitar(-10.0)
      fail()
    }
    catch {
      case e : IllegalArgumentException => succeed
    }
  }
  
  test("Operacao creditar") {
    val conta01 = new ContaCorrente(500)
    conta01.creditar(100)
    assert(conta01.saldo == 600)
    
    try {
      conta01.creditar(-10)
      fail()
    }
    catch {
      case e: IllegalArgumentException => succeed 
    }
  }
}