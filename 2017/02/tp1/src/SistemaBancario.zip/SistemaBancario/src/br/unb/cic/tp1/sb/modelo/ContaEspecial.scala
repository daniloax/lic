package br.unb.cic.tp1.sb.modelo

class ContaEspecial(var _s : Double, val _limite : Double) extends ContaCorrente(_s) {
  
  final override def debitar(valor : Double) : Unit = {
    require(valor > 0 && ((_saldo + _limite) - valor >= 0))
    _saldo -= valor
  }
  
}