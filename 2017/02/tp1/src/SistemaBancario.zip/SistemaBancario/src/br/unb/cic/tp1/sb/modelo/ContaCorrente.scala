package br.unb.cic.tp1.sb.modelo

class ContaCorrente(protected var _saldo : Double) {
  require(_saldo >= 0)
  
  def saldo : Double = _saldo
  
  def debitar(valor : Double) : Unit = {
    require(valor > 0 && valor <= _saldo)
    this._saldo -= valor   
  }
  
  def creditar(valor : Double) : Unit = {
    require(valor > 0)
    this._saldo += valor
  }
}