package br.unb.cic.tp1.sb.repositorio

import br.unb.cic.tp1.sb.modelo.ContaCorrente
import br.unb.cic.tp1.sb.modelo.ContaEspecial

object RepositorioDeContas {
  var contas = new Array[ContaCorrente](5)
  
  def pesquisaContaCorrente(idx : Int) : ContaCorrente = {
    contas(0) = new ContaCorrente(100)
    contas(1) = new ContaEspecial(200, 50)
    contas(2) = new ContaEspecial(300, 50)
    contas(3) = new ContaCorrente(400)
    contas(4) = new ContaCorrente(500)
    return contas(idx)
  }
}