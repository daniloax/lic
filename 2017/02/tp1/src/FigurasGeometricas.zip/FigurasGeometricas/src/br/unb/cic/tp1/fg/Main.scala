package br.unb.cic.tp1.fg

import io.StdIn.{readLine, readInt} 
import scala.collection.mutable.MutableList

object Main extends App {
   
  imprimeOpcoes()
  
  var opcao = readLine
  val figuras = new MutableList[FiguraGeometrica]
  
  while(opcao != "e") {
    opcao match {
      case "c" => figuras += novoCirculo()
      case "r" => figuras += novoRetangulo()
      case "t" => println(figuras.map(f => f.area).sum)
    }
    imprimeOpcoes
    opcao = readLine
  }
  
  def novoCirculo() : Circulo = {
    println("raio : ")
    val raio = readInt
    return new Circulo(raio)
  }
  
  def novoRetangulo() : Retangulo = {
    println("base : ")
    val base = readInt
    println("altura : ")
    val altura = readInt
    return new Retangulo(base, altura)
  }
  def imprimeOpcoes() { 
    println("Escolha a sua opcao: ")
    println("(c) adicionar um circulo ")
    println("(r) adicionar um retangulo ")
    println("(t) calcular o total das areas ")
    println("(e) sair ")
  }
}