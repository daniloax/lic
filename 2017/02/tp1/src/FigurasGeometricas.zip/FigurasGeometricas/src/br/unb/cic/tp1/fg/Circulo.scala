package br.unb.cic.tp1.fg

/**
 * Um circulo eh uma figura geometrica, e, dessa forma, 
 * faz sentido usar o relacionamento de heranca (extends) 
 * com a classe abstrata FiguraGeometrica. 
 */
class Circulo(val raio : Double) extends FiguraGeometrica {
  override def area : Double = 3.14 * raio * raio  
  override def perimetro : Double = 2 * 3.14 * raio
}