package br.unb.cic.tp1.fg

/**
 * Representa a raiz da hierarquia das figuras 
 * geometricas. Basicamente estabelece um contrato 
 * que obriga as subclasses concretas de FiguraGeometrica 
 * a implementarem o metodo area :: Double
 */
abstract class FiguraGeometrica {
   def area : Double
   def perimetro : Double
}