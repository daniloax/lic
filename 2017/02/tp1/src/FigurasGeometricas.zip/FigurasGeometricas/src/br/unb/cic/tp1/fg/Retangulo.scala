package br.unb.cic.tp1.fg

class Retangulo(val base: Double, val altura : Double) extends FiguraGeometrica {
  override def area : Double = {
    return base * altura
  }
  override def perimetro : Double = 
    2 * base + 2 * altura
}