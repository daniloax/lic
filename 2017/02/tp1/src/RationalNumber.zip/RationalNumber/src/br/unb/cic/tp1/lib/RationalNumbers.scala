package br.unb.cic.tp1.lib

class RationalNumbers(private val numerador: Int, private val denominador: Int = 1) {
  require(denominador != 0)

  val g = GCD(numerador, denominador)

  val n = numerador / g

  val d = denominador / g

  def +(that: RationalNumbers): RationalNumbers = {
    val num = (that.denominador * this.numerador) + (that.numerador * this.denominador)
    val den = that.denominador * this.denominador
    return new RationalNumbers(num, den)
  }
 
  def compare(a : RationalNumbers, b: RationalNumbers) : Int = {
   a.n * b.d - b.n * a.d 
  }
  
  def compare(other : RationalNumbers) : Int = {
   compare(this, other)
  }

  override def equals(o: Any): Boolean = {
     o match {
      case outro : RationalNumbers => (this.n == outro.n) && (this.d == outro.d)
      case _  => false
     }
  }

  override def toString: String = numerador + "/" + denominador
  
  private def GCD(a: Int, b: Int): Int = {
    if (b == 0) {
      return a
    } else {
      return GCD(b, a % b)
    }
  }
 
}