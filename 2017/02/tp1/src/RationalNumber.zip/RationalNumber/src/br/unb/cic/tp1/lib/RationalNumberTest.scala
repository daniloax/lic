package br.unb.cic.tp1.lib

import org.scalatest.FunSuite 
import java.io.IOException

/** Test cases for the RationalNumber class. 
 * 
 * This class is based on the ScalaTest framework 
 * (a kind of JUnit framework for Scala). For now, 
 * we configure the project as a maven project, in order 
 * to obtain the corresponding library. 

 */
class RationalNumberTest extends FunSuite {
 
  // a simple test for the RationalNumber constructor
  test("a simple test for the RationalNumber constructor") {
    val n1 = new RationalNumbers(3,4)
    val n2 = new RationalNumbers(6,8)

    assert(n1 == n2)
  }
  
  // a simple test for the plus operator
  test("a test for the + operator of Rational Numbers") {
    val n1 = new RationalNumbers(2, 3)
    val n2 = new RationalNumbers(3, 5) 
    val n3 = n1 + n2
    val expected = new RationalNumbers(19, 15)
    
    assert(n3 == expected) 
  }
  
  test("a test for a rational number with zero as denominator") {
//    try {
//      val z1 = new RationalNumbers(5,0)
//      println("nao deve passar aqui")
//      fail() //fail reporta um erro de logica
//    }
//    catch { //succeed reporta um comportamento esperado
//      case iae : IllegalArgumentException => {
//        println("deve passar aqui" + iae.getCause)
//        succeed  
//      }
//    }
    assertThrows[IllegalArgumentException] {
      val z1 = new RationalNumbers(5, 0)
    }
  }
  test("compare a rational number"){
    val n1 = new RationalNumbers(1,2)
    val n2 = new RationalNumbers(2,4)
    val n3 = new RationalNumbers(1,4)
    
    assert(n1.compare(n2) == 0)
    assert((n2).compare(n3) > 0)
    assert(n3.compare(n1) < 0)
    
  }
}

