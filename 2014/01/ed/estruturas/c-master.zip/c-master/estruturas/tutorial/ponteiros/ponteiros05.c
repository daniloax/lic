main () {

  int x, y;
  int *p1, *p2;
  x = 5;
  y = 7;
  p1 = &x;
  printf(" %d\n", *p1);
  p2 = &y;
  printf(" %d\n", *p2);
  p2 = p1;
  printf(" %d\n", *p2);

  system("pause");      
}
