# -*- coding: utf-8 -*-
"""
Created on Wed Nov 13 19:22:36 2013
 
@author: romulo
"""
import zipfile
import os, sys
from os import mkdir
import shutil
 
 
 
nomeapp = raw_input("\nNome do Aplicativo .zip que Deseja Buscar: ")
 
#cria diretorio com o nome do arquivo digitado pelo usuário
os.mkdir("/home/romulo/testepython/novo/" + nomeapp)
 
#copia o arquivo .zip para o diretorio com o seu mesmo nome
shutil.copy("/home/romulo/testepython/" + nomeapp, "/home/romulo/testepython/novo/" + nomeapp)
 
#entra no diretorio nomeapp
os.chdir("/home/romulo/testepython/novo/" + nomeapp)
 
#extrai o arquivo zip que o usuario digitou e armazenou na variável nomeapp
 
zf = zipfile.ZipFile(nomeapp, "r")
zf.extractall()
 
#exibe na tela o conteudo do arquivo info.txt
a = open("info.txt")
texto = a.read()
print texto