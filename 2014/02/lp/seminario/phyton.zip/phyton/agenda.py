# Lista Telefonica que grava e le de arquivo de texto


ARQUIVO = "lista_telefonica.txt" # Nome do arquivo de texto

def le_agenda():                # Função que le o arquivo de texto
    try:                         # Tratamento de erro
        arq = open(ARQUIVO,"r+") # Abre o arquivo para leitura e escrita
        print( '\n'+arq.read() ) # Quebra linha e mostra o conteudo
        arq.close()              # Fecha o arquivo
    except IOError:              # Tratamento de erro
        print('\nArquivo não encontrado!')

def escreve_agenda(texto, numero):        # Função que le e escreve no arquivo
    try:                           # Tratamento de erro
        arq = open(ARQUIVO,"a+")# Abre o arquivo para gravação no final do arquivo
        arq.writelines('\nNome: '+texto) # Escreve no arquivo o parametro 'texto'
        arq.writelines('\nTelefone: '+numero+'\n')

        arq.close()
        print('\nGravando 50%\nRegistro gravado com sucesso')
    except IOError:                # Tratamento de erro
        print('\nErro ao abrir o arquivo!') # Mostra na tela uma mensagem de erro
        
def reset_agenda():                # Função que le o arquivo de texto
    try:                         # Tratamento de erro
        arq = open(ARQUIVO,"w+")
        arq.writelines ('\n\nAgenda Telefônica\n\n')
        print ('\n\nVocê resetou a sua agenda\n')
        arq.close()              # Fecha o arquivo
    except IOError:              # Tratamento de erro
        print('\nArquivo não encontrado!')

def backup_agenda():                # Função que faz backup da agenda
    try:
        arq = open(ARQUIVO, "r+")
        narq = open('backup.txt', "w+")
        narq.write (arq.read())
        print('\n\nVocê fez uma cópia de segurança da sua agenda\n\n')
        narq.close()
        arq.close()
    except IOError:
        print ('\nNão foi possivel fazer o backup')

def recuperar_agenda():                # Função que faz backup da agenda
    try:
        arq = open('lista_telefonica.txt', "w+")
        narq = open('backup.txt', "r+")
        arq.write (narq.read())
        print('\n\nVocê recuperou a sua agenda\n\n')
        narq.close()
        arq.close()
    except IOError:
        print ('\nNão foi possivel recuperar o backup')

while(True):                     # Loop infinito
    print('\nEscolha a opcao:')
    print('1 -> Cadastrar Telefone')
    print('2 -> Listar Telefones')
    print('3 -> Resetar Agenda')
    print('4 -> Backup da Agenda')
    print('5 -> Recuperar Agenda')
    print('0-> Sair')
    vOpcao = int(input('Digite a sua opcao:')) # Entrada da opcao pelo teclado

    if vOpcao == 0:             # Se a opcao for 0
        sair = input('\n\n\nO último Backup será restaurado...\nDeseja Restaurar o Backup a sua agenda [Y/N]:')
        if ((sair == 'y') or (sair == 'Y')):
            break                     # Quebra o laço infinito
        elif ((sair == 'n') or (sair == 'N')):
            print ('\n\n\n\n\n\n\n\n\nVocê retornou para o menu inicial\n\n')
    elif vOpcao == 1: # Se a opcao for 1
        nome = input('\nDigite o nome:')      # Entrada do nome pelo teclado
        telefone = input('\nPreencha com DDD + Nmero (telefone deve ter 10 digitos)\nDigite o Telefone:')# Entrada do telefone pelo teclado
        gravar = input('\n\n\n\n\n\n\n\n\nDeseja gravar esse contato [Y/N]: ')
        if ((gravar == 'y') or (gravar == 'Y')):
            escreve_agenda(str(nome), str(telefone))# Chama a função que grava em arquivo
        elif ((gravar == 'n') or (gravar == 'N')):
            print ('\n\n\n\n\n\n\n\n\nVocê não salvou o Contato\n\n')
            
    elif vOpcao == 2:             # Se a opcao for 2
        listar = input('\n\nVer lista de Contatos [Y/N]: ')
        if ((listar == 'y') or (listar == 'Y')):
            le_agenda()              # Chama a função que le o arquivo
        elif ((listar == 'n') or (listar == 'N')):
            print ('\n\n\n\n\n\n\n\n\nVocê retornou para o menu inicial\n\n')
    elif vOpcao == 3:
        resetar = input('\n\n\nVocê perderá todos os seu Contatos...\nDeseja Resetar a sua agenda [Y/N]:')
        if ((resetar == 'y') or (resetar == 'Y')):
            reset_agenda()              # Chama a função que le o arquivo
        elif ((resetar == 'n') or (resetar == 'N')):
            print ('\n\n\n\n\n\n\n\n\nVocê retornou para o menu inicial\n\n')
    elif vOpcao == 4:
        backup = input('\n\n\nTodos os seu Contatos ficarão seguros...\nDeseja fazer o Bacukp a sua agenda [Y/N]:')
        if ((backup == 'y') or (backup == 'Y')):
            backup_agenda()              # Chama a função que le o arquivo
        elif ((backup == 'n') or (backup == 'N')):
            print ('\n\n\n\n\n\n\n\n\nVocê retornou para o menu inicial\n\n')        
    elif vOpcao == 5:
        recuperar = input('\n\n\nO último Backup será restaurado...\nDeseja Restaurar o Backup a sua agenda [Y/N]:')
        if ((recuperar == 'y') or (recuperar == 'Y')):
            recuperar_agenda()              # Chama a função que le o arquivo
        elif ((recuperar == 'n') or (recuperar == 'N')):
            print ('\n\n\n\n\n\n\n\n\nVocê retornou para o menu inicial\n\n')


