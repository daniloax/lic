def soma_listas(l1, l2):
     l3 = []
     for i in range(0, len(l1)):
          l3.append(l1[i] + l2[i])
     return l3

def subtrai_listas(l1, l2):
     l3 = []
     for i in range(0, len(l1)):
          l3.append(l1[i] - l2[i])
     return l3

def multiplica_listas(l1, l2):
     l3 = []
     for i in range(0, len(l1)):
          l3.append(l1[i] * l2[i])
     return l3

def divide_listas(l1, l2):
     l3 = []
     for i in range(0, len(l1)):
          l3.append(float(l1[i] + l2[i]))
     return l3

while(True):
     l1 = [4, 2, 3]
     l2 = [0, 5, 6]
     print ('Lista Soma: \n ', soma_listas(l1, l2))          
     print ('Lista Subtração: \n', subtrai_listas(l1, l2))
     print ('Lista Multiplicação: \n', multiplica_listas(l1, l2))
     print ('Lista Divisão: \n', divide_listas(l1, l2))
     break
