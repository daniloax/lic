#!/bin/env python3
 
import os, zipfile, sys
 
diretorio = os.path.join('/Users\ThiagoComp\Documents', 'meusarquivos')
arquivozip = input('Digite o nome do arquivo ZIP: ')
arquivozip = os.path.join(diretorio, arquivozip)
 
try:
    z = zipfile.ZipFile(arquivozip, "r")
except FileNotFoundError:
    print("Arquivo {0} não encontrado".format(arquivozip))
    sys.exit(1)
     
for filename in z.namelist():
    if filename == 'info.txt':
        bytes = z.read(filename)
        print("{0} --> tamanho: {1} bytes".format(filename, len(bytes)))
        print()
        print(bytes.decode('ascii'))
        z.close()
    else:
        print('prolog.zip encontrado')
        z.close()
