# Problem Set "Strings"
# Fonte: http://www.python.org.br/wiki/ExerciciosComStrings
# Exercicio 1
# Name: Diego Tostes
# Time: 05'00"

while(True):
    str1 = input('digite a primeira string ---> ')
    str2 = input('digite a segunda string ---> ')
    numStr1 = len(str1)
    numStr2 = len(str2)
 
    print ('\n\nCompara duas strings\n\n')
    print ('String 1 :' +str1)
    #print ('possui tamanho' +numStr1)
    print ('String 2 :' +str2)
    #print ('possui tamanho' +numStr1)
    if (numStr1 != numStr2):
        print ('As duas strings sao de tamanhos diferentes.\nAs duas strings possuem conteudo diferente.\n\n')
    elif (str1 == str2):
        print ('\n\nAs duas strings sao iguais!\n\n')
