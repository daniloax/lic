#!/usr/bin/python

"""Bubble Sort"""

list = [3, 2, 1, 7, 6, 0, 99, 86,0, 8, 1001, 845, 632, 9, 542, 164, 653, 1624];

print ('A lista antes de ser ordenada: \n')
print(list)

swapped = False

for i in range(len(list) or not swapped):
	swapped = False
	for j in range(i + 1, len(list)):
		if list[j] < list[i]:
			temp = list[j]
			list[j] = list[i]
			list[i] = temp
print ('\n\nA lista após ser ordenada crescente: \n')
print (list)

for i in range(len(list) or not swapped):
	swapped = False
	for j in range(i + 1, len(list)):
		if list[j] > list[i]:
			temp = list[j]
			list[j] = list[i]
			list[i] = temp
print ('\n\nA lista após ser ordenada DEcrescente: \n')
print (list)
