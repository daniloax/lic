#include <stdio.h>
#include <stdlib.h>

#include "interface_apresentacao.h"


int main(int argc, char *argv[])
{
    executar();
    getchar();
}
