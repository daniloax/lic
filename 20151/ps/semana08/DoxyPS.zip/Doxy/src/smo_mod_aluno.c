/**
 * \addtogroup MOD_ALN
 * \{
 * \file smo_mod_aluno.c
 * \brief Implementação
 */
/** \} */

#include <stdio.h>
#include <stdlib.h>

#include "smo_mod_aluno.h"
#include "smo_global.h"
#include "smo_menu.h"

#include "smo_arquivo_estado.h"
#include "smo_arquivo_aluno.h"
#include "smo_monitoria_solicitacao.h"
#include "smo_visualizacao.h"


/* *******************************************************
* Protótipos das funções locais
* ****************************************************** */

void menu_listar_informacoes (void);

/* *******************************************************
* Implementaçã das funções locais
* ****************************************************** */

/**
* Módulo coordenador: função principal
* \param narg Número de argumentos da chamada
* \param args Vetor dos argumentos da chamada
*
* Mostra o menu com as opções do módulo e
* dispara a função associada à escolha do coordenador.
*/
// Emite um sinal sonoro
void ES_bipe (void);

//
void ES_imp_cab ();
int32_t
main (int32_t narg, char_t *args[]) {
    int8_t ctd = 0;
    int32_t matricula;
    bool_t existe_usuario;
    char_t entrada[256];

    MNU_opcao menu[] = {
        {'S', 's', "Solicitar monitoria",
            MON_S_cadastrar_solicitacoes},
        {'P', 'p', "Aceitar selecao prospectiva",
         NULL},
        {'A', 'a', "Avaliar monitoria",
         NULL},
        {'V', 'v', "Visualizar informacoes\n",
         menu_listar_informacoes},
        {'\x14', '\x14', "Terminar", MNU_termina_prog},
        {'*', '*', NULL, NULL}
    };
    if (!ARQ_E_ambiente_ok ()) {
        ES_bipe ();
        return 0;
    }

    ARQ_E_abre_arquivo_estado ();
    ARQ_E_ler_arquivo_estado ();
    ARQ_E_fecha_arquivo_estado ();
    GLB_atualiza_modulo ("MODULO ALUNO");
    GLB_atualiza_smodulo (NULL);
    GLB_atualiza_funcao (NULL);

    /* Verifica se aluno está cadastrado */
    ES_imp_cab ();
    ARQ_A_abre_arq_aluno ();
    ctd = 0;
    existe_usuario = false;

    do {
        do {
            ES_imp_cab ();
            printf ("\nDigite sua matricula (0 p/terminar): ");
            ES_ler_linha (entrada);
        } while (!ES_entrada_num_int (entrada));
        matricula = atoi (ES_primeiro_token (entrada, ES_delim_espacos));
        if (matricula == 0) {
            return 0;
        } else {
            if (!ARQ_A_ler_aluno (matricula)) {
                existe_usuario = false;
                ES_bipe ();
                fflush (stdout);
            } else {
                existe_usuario = true;
            }
        }
        ctd++;
    } while ((!existe_usuario) && (ctd < 3));

    ARQ_A_fecha_arq_aluno ();

    if (ctd == 3) {
        printf ("Sua matricula nao esta registrada!\n");
        printf ("Procure o administrador para fazer o registro\n");
        ES_bipe ();
    } else {
        GLB_define_usuario (matricula);
        MNU_dispara_funcao (menu);
    }
    return 0;
}

/**
* \brief Opções para visualização de informações
*
* Apresenta as opções do menu de visualização
* e dispara a função associada à escolha feita
* pelo usuário.
*/
void
menu_listar_informacoes () {
    MNU_opcao menu[] = {
        {'A', 'a', "Alunos",
            VIS_listar_alunos},
        {'P', 'p', "Professores",
         VIS_listar_professores},
        {'D', 'd', "Disciplinas e turmas\n",
         VIS_listar_disciplinas},
        {'O', 'o', "Ofertas de monitoria",
         VIS_listar_ofertas},
        {'S', 's', "Solicitacoes de monitoria",
         VIS_listar_solicitacoes},
        {'M', 'm', "Monitorias\n",
         VIS_listar_selecionadas},
        {CTRLV, CTRLV, "Voltar", NULL},
        {CTRLT, CTRLT, "Terminar", MNU_termina_prog},
        {'*', '*', NULL, NULL}
    };
    GLB_atualiza_smodulo ("LISTAR INFORMACOES");
    GLB_atualiza_funcao (NULL);
    MNU_dispara_funcao (menu);
    GLB_atualiza_smodulo (NULL);
}
