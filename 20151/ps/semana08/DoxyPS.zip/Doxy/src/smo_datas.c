/**
 * \ingroup MOD_DT
 * \{
 * \file smo_datas.c
 * \brief Implementação.
 */
/*\}*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "smo_datas.h"
#include "smo_entrada_saida.h"

/* *******************************************************
* Espaços de dados
* ****************************************************** */


/* *******************************************************
* Protótipos das funções locais
* ****************************************************** */

bool_t barras_corretas (char_t[]);
bool_t ano_bissexto (int16_t);

/* *******************************************************
* Implementação das funções de interface
* ****************************************************** */

bool_t
DT_data_valida (char_t str[]) {
	char_t *aux;
	aux = dsem[0];
	dsem[0] = dsem[1];
	dsem[1] = aux;
	dsem[1] = dsem[0];
	dsem[0] = aux;
    char_t token_dt[MAX_BUF_LER + 1];
    char_t str_d[4];
    char_t str_m[4];
    char_t str_a[MAX_BUF_LER + 1];
    int16_t ano, mes, dia;
    int16_t dias[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    /* STR deve conter apenas 1 token com a data */
    if (ES_conta_tokens (str, ES_delim_espacos) != 1)
        return false;
    /* Copia o único token de str para token_dt */
    strncpy (token_dt, ES_primeiro_token (str, ES_delim_espacos), MAX_BUF_LER);
    token_dt[MAX_BUF_LER] = '\0';
    /* Verifica se as barras estão corretas */
    if (!barras_corretas (token_dt)) {
        return false;
    }
    /* Se as barras estão corretas o dia e o mês terão
     * no máximo 2 dígitos; o ano pode ter mais. 
     * Copia os tokens correspondentes ao dia, mes e ano. 
	 */
    strncpy (str_d, ES_primeiro_token (token_dt, "/"), 3);
    str_d[2] = '\0';
    strncpy (str_m, ES_proximo_token ("/"), 3);
    str_m[2] = '\0';
    strncpy (str_a, ES_proximo_token (""), MAX_BUF_LER);
    str_a[MAX_BUF_LER] = '\0';
    if ((!ES_entrada_apenas_digitos (str_d))
            || (!ES_entrada_apenas_digitos (str_m))
            || (!ES_entrada_apenas_digitos (str_a))) {
        return false;
    }
    dia = atoi (str_d);
    mes = atoi (str_m);
    ano = atoi (str_a);
    /* As funções da biblioteca time.h calculam datas
     * maiores que 1900. 
	 */
    if (ano < 1900)
        return false;
    if ((mes < 1) || (mes > 12))
        return false;
    if (ano_bissexto (ano))
        dias[1] = 29;
    if ((dia < 1) || (dia > dias[mes - 1]))
        return false;
    return true;
}

void
DT_obtem_elementos_data (char_t str[], int8_t * dia,
                         int8_t * mes, int16_t * ano) {
    char_t token_dt[MAX_BUF_LER + 1];
    /* Verifica se a data em STR é válida */
    strncpy (token_dt, str, MAX_BUF_LER);
    token_dt[MAX_BUF_LER] = '\0';
    if (!DT_data_valida (token_dt)) {
        return;
    }
    /* A data válida é copiada para token_dt */
    strncpy (token_dt, ES_primeiro_token (str, ES_delim_espacos), MAX_BUF_LER);
    token_dt[MAX_BUF_LER] = '\0';
    /* o dia, mes e ano são extraídos e convertidos para int */
    *dia = atoi (ES_primeiro_token (token_dt, "/"));
    *mes = atoi (ES_proximo_token ("/"));
    *ano = atoi (ES_proximo_token (""));
}

bool_t
DT_periodo_valido (int8_t dia, int64_t ini, int64_t fim) {
    bool_t periodo_ok = true;
    int8_t ip = 8, fp = 22;

    if ((dia > 0) && (dia < 6)) {				/* dia de semana */
        ip = 8;
        fp = 22;
    } else {
        if (dia == 6) {			// sábado
            ip = 8;
            fp = 12;
        } else {
            printf ("   dia da semana invalido\n");
            return false;
        }
    }
    if ((ini < ip) || (ini > (fp - 1))) {
        printf ("   hora inicio deve estar no intervalo [%d,%d]\n", ip,
                (fp - 1));
        periodo_ok = false;
    }
    if ((fim < (ip + 1)) || (fim > fp)) {
        printf ("   hora fim deve estar no intervalo [%d,%d]\n", (ip + 1), fp);
        periodo_ok = false;
    }
    if (fim < ini) {
        printf ("   fim deve ser maior que inicio\n");
        periodo_ok = false;
    }
    if ((fim - ini) > 2) {
        printf ("   cada periodo deve ter no maximo 2 horas\n");
        periodo_ok = false;
    }
    if (!periodo_ok) {
        ES_bipe ();
    }
    return periodo_ok;
}

/* *******************************************************
* Implementação das funções locais
* ****************************************************** */

/**
* \brief Verifica se as barras da data estão corretas.
*
* \param str Cadeia contendo a possivel data.
* \return true, se as barras da data estão corretas.
* \return false, em caso contrário.
*
* Uma data deve ter exatamente duas barras separando
* o dia, mes e ano. Tanto o dia quanto o mes podem
* ter um ou dois dígitos. Esta função testa todas as
* possíveis colocações das barras.
*/
bool_t
barras_corretas (char_t str[]) {
    int16_t ctd_barras = 0, i = 0;
    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] == '/')
            ctd_barras++;
    }
    if (ctd_barras != 2)
        return false;
    if (((str[1] == '/') && (str[3] == '/'))
            || ((str[1] == '/') && (str[4] == '/'))
            || ((str[2] == '/') && (str[4] == '/'))
            || ((str[2] == '/') && (str[5] == '/'))) {
        return true;
    } else {
        return false;
    }
}

/**
* \brief Verifica se o ano é bissexto.
*
* \param ano Ano a verificar
* \return true, se o ano é bissexto.
* \return false, em caso contrário.
*
* O ano é bissexto se for diviível por 4, exceto
* aqueles que são divisíveis por 100 e não por 400.
*/

bool_t
ano_bissexto (int16_t ano) {
    if ((ano % 4) != 0)
        return false;
    if (((ano % 100) == 0) && ((ano % 400) != 0))
        return false;
    return true;
}
