/**
 * \defgroup MOD_CAD_A "Cadastra alunos"
 * \{
 * \ingroup MOD_CAD
 *
 * \file smo_cadastra_aluno.h
 * \brief Cabeçalho
 */
/*\}*/

#ifndef $$MOD_CAD_A
#define $$MOD_CAD_A
#include "smo_tipos.h"

/**
* \brief Cadastra alunos
*
* Repete o seguinte processo até que seja digitado uma
* matrícula igual a zero:
*
* Lê matrícula do aluno
* - Se aluno não existe
*    - Lê nome, telefone e endereço eletrônico e inclui
*      novo aluno
* - Se aluno existe
*    - Mostra dados do aluno e pergunta se deve ser
*      modificado ou excluído.
*    - Se modificado
*       - Lê novos nome, telefone e endereço eletrônico e
*         altera o aluno
*    - Se excluído
*       - Exclui o aluno
*/
void CAD_A_cadastrar_alunos (void);
#endif
