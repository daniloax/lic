/**
 * \defgroup MOD_TIPOS "Declaração de Tipos"
 * \{
 * \ingroup MOD_GERAL
 *
 * \file smo_tipos.h
 * \brief Cabeçalho
 */
/*\}*/

#ifndef $$MOD_TIPOS
#define $$MOD_TIPOS

/* Define tipo de dados bool. 
 * Geralmente em /usr/include/c++/tr1/ 
 */
#include <stdbool.h>

/* Define limites de valores e tipos inteiros independentes da arquitetura:  
 * typedef unsigned char uint8_t;
 * typedef unsigned short int uint16_t;
 * typedef unsigned int uint32_t;
 * typedef unsigned long int uint64_t;
 * typedef signed char int8_t;
 * typedef signed short int int16_t;
 * typedef signed int int32_t;
 * typedef signed long int int64_t;
 * Geralmente em /usr/include/
 */
#include <stdint.h>

/* Os tipos abaixo estão definidos para uniformizar o padrão de definição */
typedef bool bool_t;
typedef char  char_t;
typedef float float32_t;
typedef double float64_t;
typedef long double float128_t;

#endif
