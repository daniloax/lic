/**
 * \addtogroup MOD_GLB
 * \{
 * \file smo_global.c
 * \brief Implementação
 */
/*\}*/

#include <string.h>
#include <stdlib.h>

#include "smo_global.h"

#define MAX_GLB_NOME (31)

static char_t *GLB_nome_modulo = NULL;
static char_t *GLB_nome_smodulo = NULL;
static char_t *GLB_nome_funcao = NULL;

static int32_t cod_usuario;

void
GLB_define_usuario (int32_t cod) {
    cod_usuario = cod;
}

int32_t
GLB_usuario () {
    return cod_usuario;
}

char_t *
GLB_modulo (void) {
    return GLB_nome_modulo;
}

char_t *
GLB_smodulo (void) {
    return GLB_nome_smodulo;
}

char_t *
GLB_funcao (void) {
    return GLB_nome_funcao;
}

void
GLB_atualiza_modulo (char_t nome[]) {
    if (nome == NULL) {
        if (GLB_nome_modulo != NULL) {
            free (GLB_nome_modulo);
        }
        GLB_nome_modulo = NULL;
    } else {
        if (GLB_nome_modulo == NULL) {
            GLB_nome_modulo = (char_t *) calloc (31, sizeof (char_t));
        }
        strncpy (GLB_nome_modulo, nome, 30);
    }
}

void
GLB_atualiza_smodulo (char_t nome[]) {
    if (nome == NULL) {
        if (GLB_nome_smodulo != NULL) {
            free (GLB_nome_smodulo);
        }
        GLB_nome_smodulo = NULL;
    } else {
        if (GLB_nome_smodulo == NULL) {
            GLB_nome_smodulo = (char_t *) calloc (31, sizeof (char_t));
        }
        strncpy (GLB_nome_smodulo, nome, 30);
    }
}

void
GLB_atualiza_funcao (char_t nome[]) {
    if (nome == NULL) {
        if (GLB_nome_funcao != NULL) {
            free (GLB_nome_funcao);
        }
        GLB_nome_funcao = NULL;
    } else {
        if (GLB_nome_funcao == NULL) {
            GLB_nome_funcao = (char_t *) calloc (31, sizeof (char_t));
        }
        strncpy (GLB_nome_funcao, nome, 30);
    }
}
