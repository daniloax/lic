/**
 * \defgroup MOD_DT "Data e Hora"
 * \{
 * \ingroup MOD_GERAL
 *
 * \file smo_datas.h
 * \brief Cabeçalho
 */
/*\}*/

#ifndef $$MOD_DT
#define $$MOD_DT

#include "smo_tipos.h"

/**
* \brief Tipo para o período de tempo
*/
typedef struct r_per periodo_t;

/**
* \brief Estrutura do período de tempo
*
* - ini. Hora inicial
* - fim. Hora final
*/
struct r_per {
    int8_t ini;
    int8_t fim;
};

/**
* \brief Verifica se a data é válida.
*
* \param str Cadeia de caracteres com a possível data.
* \return true, se o conteúdo da cadeia é uma data válida.
* \return false, em caso contrário.
*/
bool_t DT_data_valida (char_t str[]);

/**
* \brief Obtem o dia, mes e ano de uma data.
*
* \param str Cadeia contendo a data.
* \param dia Ponteiro para variável que armazenará o dia.
* \param mes Ponteiro para variável que armazenará o mes.
* \param ano Ponteiro para variável que armazenará o ano.
*
* Esta função extrai o dia, mes e ano da data em STR e
* os armazena nas variáveis inteiras passadas como
* parâmetros. Se a cadeia não contiver uma data válida,
* as variáveis não são alteradas.
*/
void DT_obtem_elementos_data (char_t str[], int8_t * dia,
                              int8_t * mes, int16_t * ano);

/**
* \brief Valida o periodo de aulas
*
*/
bool_t DT_periodo_valido (int8_t dia, int64_t ini, int64_t fim);

static char_t *dsem[7] = { "domingo", "segunda", "terca", "quarta",
                           "quinta", "sexta", "sabado"
                         };

#endif
