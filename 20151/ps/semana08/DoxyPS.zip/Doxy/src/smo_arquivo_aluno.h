/**
 * \defgroup MOD_ARQ_A "Arquivo de Alunos"
 * \{
 * \ingroup MOD_ARQ
 * \brief Funções de criação, acesso e modificação do
 * arquivo de alunos.
 *
 * \file smo_arquivo_aluno.h
 * \brief Cabeçalho
 *
 * O arquivo de alunos possui dois tipos de registro:
 *   - O registro geral, com apenas uma instância,
 * contendo a quantidade de alunos gravados no arquivo,
 * e os ponteiros para o primeiro e o último registros de
 * alunos, além do ponteiro para a pilha de registros
 * disponíveis.
 *   - Os registros de alunos, com um registro para cada
 * aluno.
 * .
 * A inclusão de um novo registro se faz sobrepondo-se o
 * primeiro registro da pilha de registros disponíveis,
 * ou inserindo-o no final do arquivo, se a pilha estiver
 * vazia. A exclusão de um registro apenas o coloca na
 * pilha de registros disponíveis.
 *
 */
/** \} */

#ifndef $$MOD_ARQ_A
#define $$MOD_ARQ_A

#include <time.h>
#include "smo_tipos.h"

/* *******************************************************
* Espaços de dados
* ****************************************************** */

#define MAX_NOME_A (30)
#define MAX_TEL_A  (30)
#define MAX_EE_A   (60)

/**
* \brief Tipo para o registro da aluno
*/
typedef struct r_aluno reg_aluno_t;


/**
* \brief Estrutura registro do arquivo de alunos
*
* Registro detalhe (um para cada aluno):
*
* - mat. Matrícula do aluno.
* - nome. Nome do aluno.
* - tel. Telefone do aluno.
* - ee. Endereço eletrônico do aluno.
* - ant. Apontador para registro anterior
*   (deslocamento em relação à origem).
* - prox. Apontador para registro posterior
*   (deslocamento em relação à origem).
* .
* O registro é sempre gravado na próxima posição
* disponível (apontada pela lista pilha_disp do
* registro geral) ou na última posição do arquivo,
* mas os apontadores são atualizados de modo que o
* arquivo permaneça ordenado por matrícula a partir
* da posição do primeiro registro (campo pos_pri_r
* do registro geral).
*/
struct r_aluno {
    int32_t mat;
    char_t nome[MAX_NOME_A + 1];
    char_t tel[MAX_TEL_A + 1];
    char_t ee[MAX_EE_A + 1];
    int64_t ant;
    int64_t prox;
};


/* *******************************************************
* Funções de acesso
* ****************************************************** */

/**
* \brief Obtém a matrícula aluno corrente
* \return matrícula do aluno corrente.
*/
int32_t ARQ_A_mat_aluno (void);

/**
* \brief Obtém o nome do aluno corrente
* \return Nome do aluno corrente
*/
char_t *ARQ_A_nome_aluno (void);

/**
* \brief Obtém o telefone do aluno corrente
* \return  Telefone do aluno
*/
char_t *ARQ_A_telefone_aluno (void);

/**
* \brief Obtém o endereço eletrônico do aluno corrente
* \return  Endereço eletrônico do aluno
*/
char_t *ARQ_A_email_aluno (void);

/**
* \brief Obtém a posição no arquivo do aluno anterior
* \return Posição no arquivo (deslocamento em relação à origem)
*/
int64_t ARQ_A_posicao_aluno_ant (void);

/**
* \brief Obtém a posição no arquivo do próximo aluno
* \return Posição no arquivo (deslocamento em relação à origem)
*/
int64_t ARQ_A_posicao_prox_aluno (void);

/**
* \brief Obtém a quantidade de alunos
* \return Quantidade de alunos
*/
int64_t ARQ_A_qtd_alunos (void);

/**
* \brief Obtém a posição no arquivo do primeiro aluno
* \return Posição no arquivo (deslocamento em relação à origem)
*/
int64_t ARQ_A_pos_primeiro_aluno (void);

/**
* \brief Obtém a posição no arquivo do ultimo aluno
* \return Posição no arquivo (deslocamento em relação à origem)
*/
int64_t ARQ_A_pos_ultimo_aluno (void);

/* *******************************************************
* Funções de atualização
* ****************************************************** */

/**
* \brief Insere novo aluno
*
* \param mat Matrícula do novo aluno
* \param nome Nome do novo aluno
* \param tel Telefone do novo aluno
* \param ee Endereço eletrônico do novo aluno
*
* Insere o aluno, ajustando os apontadores de posição
* de modo a manter o arquivo ordenado pela matrícula do
* aluno. Se já existir um aluno com a mesma
* matrícula, a função retorna sem inserir.
*/
void ARQ_A_inserir_aluno (int32_t mat, char_t nome[], char_t tel[],
                          char_t ee[]);

/**
* \brief Altera o aluno de matrícula mat
*
* \param mat Matrícula do  aluno
* \param nome Novo nome do aluno
* \param tel Novo telefone do aluno
* \param ee Novo endereço eletrônico do aluno
*
* - O nome é alterado apenas se o novo nome for diferente
* da cadeia vazia ("\0").
* - O telefone é alterado apenas se o novo telefone for diferente
* da cadeia vazia ("\0").
* - O endereço eletrônico é alterado apenas se o novo
* endereço for diferente da cadeia vazia ("\0").
*
* Se não existir um aluno com matrícula igual a mat,
* a função simplesmente retorna.
*/
void ARQ_A_alterar_aluno (int32_t mat, char_t nome[], char_t tel[],
                          char_t ee[]);

/**
* \brief Exclui o aluno de matrícula mat
*
* \param mat Matrícula do  aluno
*
* Se não existir um aluno com matrícula igual a mat,
* a função simplesmente retorna.
*/
void ARQ_A_excluir_aluno (int32_t mat);

/* *******************************************************
* Funções de pesquisa
* ****************************************************** */

/**
* \brief Verifica existência de aluno com matrícula = MAT.
*
* \param cod Matrícula do aluno.
* \return true, se existe o aluno com matrícula MAT.
* \return false, em caso contrário.
*/
bool_t ARQ_A_existe_aluno (int32_t cod);

/* *******************************************************
* Funções de leitura e caminhamento
* ****************************************************** */

/**
* \brief Lê o aluno com matrícula = mat
*
* \param mat Matrícula do aluno
* \return true, se o aluno existir
* \return false, em caso contrário
*
* Se o aluno não existir nenhuma leitura ocorre.
* O último aluno lido permanece como o aluno
* corrente.
*/
bool_t ARQ_A_ler_aluno (int32_t mat);

/**
* \brief Lê o primeiro aluno do arquivo
*
* \return 1, se a leitura é bem sucedida
* \return Número negativo, se não existe primeiro
*         aluno ou 0 se a leitura não pode ser feita.
*/
int64_t ARQ_A_ler_primeiro_aluno (void);

/**
* \brief Lê o próximo aluno do arquivo
*
* \return 1, se a leitura é bem sucedida
* \return Número negativo, se não existe primeiro
*         aluno ou 0 se a leitura não pode ser feita.
*/
int64_t ARQ_A_ler_proximo_aluno (void);

/**
* \brief Lê o aluno da posição ptr
*
* \return 1, se a leitura é bem sucedida
* \return Número diferente de 1, se a leitura não pode
*         ser feita.
*/
int64_t ARQ_A_ler_aluno_posicao (int64_t ptr);

/* *******************************************************
* Funções para abertura, iniciação e fechamento do arquivo
* ****************************************************** */

/**
* \brief Cria arquivo de alunos.
*
* Cria um arquivo de alunos contendo apenas o
* registro geral iniciado. O arquivo é fechado após
* a criação, sendo necessário abri-lo novamente.
*/
void ARQ_A_cria_arq_aluno (void);

/**
* \brief Abre arquivo aluno.
*
* \return Identificador para o arquivo de alunos,
* ou NULL, se o arquivo não existir.
*
* Abre o arquivo de alunos, se existir.
*/
FILE *ARQ_A_abre_arq_aluno (void);

/**
* \brief Fecha arquivo aluno.
*
* Fecha o arquivo de alunos, se estiver aberto,
* após atualizar seu registro geral.
*/
void ARQ_A_fecha_arq_aluno (void);

#endif
