/**
 * \addtogroup MOD_CAD_A
 * \{
 * \file smo_cadastra_aluno.c
 * \brief Implementação
 */
/*\}*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "smo_global.h"
#include "smo_cadastra_aluno.h"
#include "smo_entrada_saida.h"
#include "smo_arquivo_aluno.h"

/* *******************************************************
* Protótipos das funções locais
* ****************************************************** */

void CAD_A_obtem_dados_inclusao (reg_aluno_t *);
void CAD_A_obtem_dados_alteracao (reg_aluno_t *);

/* *******************************************************
* Implementação das funções de interface
* ****************************************************** */

void
CAD_A_cadastrar_alunos () {
    reg_aluno_t aluno[1];
    char_t ch;
    char_t entrada[MAX_BUF_LER + 1];

    GLB_atualiza_funcao ("ALUNO");
    ARQ_A_abre_arq_aluno ();

    do {
        do {
            ES_imp_cab ();
            printf ("\nMatricula (0 p/terminar): ");
            ES_ler_linha (entrada);
        } while (!ES_entrada_num_int (entrada));
        if (ES_entrada_num_zero (entrada)) {
            GLB_atualiza_funcao (NULL);
            break;
        }
        aluno[0].mat = atoi (ES_primeiro_token (entrada, ES_delim_espacos));
        if (!ARQ_A_existe_aluno (aluno[0].mat)) {
            CAD_A_obtem_dados_inclusao (aluno);
            ES_imp_cab ();
            printf ("Matricula: %d\n", aluno[0].mat);
            printf ("Nome     : %s\n", aluno[0].nome);
            printf ("Telefone : %s\n", aluno[0].tel);
            printf ("E-mail   : %s\n", aluno[0].ee);
            printf ("\nConfirma a inclusao (s/n)? ");
            fflush (stdout);
            if (ES_entrada_sim ()) {
                ARQ_A_inserir_aluno (aluno[0].mat, aluno[0].nome, aluno[0].tel, aluno[0].ee);
            }
        } else {
            ES_imp_cab ();
            ARQ_A_ler_aluno (aluno[0].mat);
            printf ("Matricula: %d\n", aluno[0].mat);
            printf ("Nome     : %s\n", ARQ_A_nome_aluno ());
            printf ("Telefone : %s\n", ARQ_A_telefone_aluno ());
            printf ("E-mail   : %s\n", ARQ_A_email_aluno ());
            printf
            ("\nOpcao: Ctrl-A Alterar,  Ctrl-E Excluir,  Ctrl-V Voltar ");
            fflush (stdout);
            do {
                ch = ES_obtem_char ();
            } while ((ch != CTRLA) && (ch != CTRLE) && (ch != CTRLV));
            switch (ch) {
            case CTRLA:
                CAD_A_obtem_dados_alteracao (aluno);
                ES_imp_cab ();
                printf ("Alterar %d\n", aluno[0].mat);
                printf ("-----\nDe  :\n %-30s (%s)\n %-60s\n",
                        ARQ_A_nome_aluno (),
                        ARQ_A_telefone_aluno (), ARQ_A_email_aluno ());
                printf ("-----\nPara:\n");
                if (aluno[0].nome[0] == '\0')
                    printf (" %-30s ", ARQ_A_nome_aluno ());
                else
                    printf (" %-30s ", aluno[0].nome);
                if (aluno[0].tel[0] == '\0')
                    printf ("(%s)\n", ARQ_A_telefone_aluno ());
                else
                    printf ("(%s)\n", aluno[0].tel);
                if (aluno[0].ee[0] == '\0')
                    printf (" %-60s\n", ARQ_A_email_aluno ());
                else
                    printf (" %-60s\n", aluno[0].ee);
                printf ("\nConfirma a alteracao (s/n)? ");
                fflush (stdout);
                if (ES_entrada_sim ()) {
                    ARQ_A_alterar_aluno (aluno[0].mat, aluno[0].nome, aluno[0].tel, aluno[0].ee);
                }
                break;
            case CTRLE:
                ARQ_A_excluir_aluno (aluno[0].mat);
                break;
            default:
                break;
            }
        }
    } while (true);
    ARQ_A_fecha_arq_aluno ();
    GLB_atualiza_funcao (NULL);
}

/* *******************************************************
* Implementação das funções locais
* ****************************************************** */

/**
* \brief Obtém dados para inclusão do aluno
* \param aluno Estrutura do aluno
*
* Lê dados do teclado e atualiza as variáveis
* paramétricas com os valores lidos.
*/
void
CAD_A_obtem_dados_inclusao (reg_aluno_t *aluno) {
    char_t entrada[MAX_BUF_LER + 1];

    printf ("Nome (max. 30 caracteres)    : ");
    ES_ler_linha (entrada);
    strncpy (aluno[0].nome, entrada, MAX_NOME_A);
    aluno[0].nome[MAX_NOME_A] = '\0';

    printf ("Telefone (max. 30 caracteres): ");
    ES_ler_linha (entrada);
    strncpy (aluno[0].tel, entrada, MAX_TEL_A);
    aluno[0].nome[MAX_TEL_A] = '\0';

    printf ("Email (max. 60 caracteres)   : ");
    ES_ler_linha (entrada);
    strncpy (aluno[0].ee, entrada, MAX_EE_A);
    aluno[0].nome[MAX_EE_A] = '\0';
}

/**
* \brief Obtém dados para alteração do aluno
* \param aluno Estrutura do aluno
*
* Lê dados do teclado e atualiza as
* variáveis paramétricas com os valores lidos.
*/
void
CAD_A_obtem_dados_alteracao (reg_aluno_t *aluno) {
    char_t entrada[MAX_BUF_LER + 1];

    printf ("\nDigite novos dados (<ENTER> para nao modificar)\n\n");
    printf ("Nome (30 caracteres)         : ");
    ES_ler_linha (entrada);
    strncpy (aluno[0].nome, entrada, MAX_NOME_A);
    aluno[0].nome[MAX_NOME_A] = '\0';

    printf ("Telefone (max. 30 caracteres): ");
    ES_ler_linha (entrada);
    strncpy (aluno[0].tel, entrada, MAX_TEL_A);
    aluno[0].tel[MAX_TEL_A] = '\0';

    printf ("Email (max. 60 caracteres)   : ");
    ES_ler_linha (entrada);
    strncpy (aluno[0].ee, entrada, MAX_EE_A);
    aluno[0].ee[MAX_EE_A] = '\0';
}
