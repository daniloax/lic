/**
 * \addtogroup MOD_ARQ_A
 * \{
 * \file smo_arquivo_aluno.c
 * \brief Implementação
 */
/** \} */

#include <stdio.h>
#include <string.h>

#include "smo_arquivo_aluno.h"

/* *******************************************************
* Protótipos das funções locais
* ****************************************************** */

static bool_t pos_aluno (int32_t, int64_t *, int64_t *);

/* *******************************************************
* Espaços de dados
* ****************************************************** */

/**
* \brief Tipo para o registro geral da aluno
*/
typedef struct r_geral_aluno reg_geral_aluno_t;

/**
* \brief Estrutura registro geral do arquivo de alunos.
*
* Contém os seguintes campos para o controle do arquivos
* de alunos:
*
* - qtd_reg. Quantidade de registros (alunos).
* - desloc_ini. Posição imediatamente após o registro geral.
* - pos_pri_r. Posição do primeiro aluno.
* - pos_ult_r. Posição do último aluno.
* - pilha_disp. Posição do primeiro registro da pilha
*   de registros disponíveis no arquivo.
* .
* Existe um único registro para o arquivo.
*/
struct r_geral_aluno {
    int64_t qtd_reg;
    int64_t desloc_ini;
    int64_t pos_pri_r;
    int64_t pos_ult_r;
    int64_t pilha_disp;
};


/**
* \brief Identificador do arquivo aluno.
*/
static FILE *arq_aluno;

static reg_aluno_t reg[1];
/**
* \brief Registro geral do arquivo de alunos
*/
static reg_geral_aluno_t reg_geral_aluno[1];

/**
* \brief Registro detalhe do arquivo aluno.
*/
static reg_aluno_t reg_aluno[1];

/* *******************************************************
* Implementação das funções de interface
* ****************************************************** */

/* *******************************************************
* Funções de acesso
* ****************************************************** */

int32_t
ARQ_A_mat_aluno () {
    return reg_aluno[0].mat;
}
/*@dependent@*/
char_t *
ARQ_A_nome_aluno () {
    return reg_aluno[0].nome;
}
/*@dependent@*/
char_t *
ARQ_A_telefone_aluno () {
    return reg_aluno[0].tel;
}
/*@dependent@*/
char_t *
ARQ_A_email_aluno () {
    return reg_aluno[0].ee;
}

int64_t
ARQ_A_posicao_aluno_ant () {
    return reg_aluno[0].ant;
}

int64_t
ARQ_A_posicao_prox_aluno () {
    return reg_aluno[0].prox;
}

int64_t
ARQ_A_qtd_alunos () {
    return reg_geral_aluno[0].qtd_reg;
}

int64_t
ARQ_A_pos_primeiro_aluno () {
    return reg_geral_aluno[0].pos_pri_r;
}

int64_t
ARQ_A_pos_ultimo_aluno () {
    return reg_geral_aluno[0].pos_ult_r;
}

/* *******************************************************
* Funções de atualização
* ****************************************************** */

void
ARQ_A_inserir_aluno (int32_t mat, char_t nome[], char_t tel[], char_t ee[]) {
    int64_t ptr, ptr_a, pos_grv;
    reg_aluno_t rdisp[1];

    ptr = ptr_a = 0;

    if (pos_aluno (mat, &ptr, &ptr_a) == true) {
        return;
    }

    /* formata registro a ser inserido */
    reg[0].mat = mat;
    strcpy (reg[0].nome, nome);
    strcpy (reg[0].tel, tel);
    strcpy (reg[0].ee, ee);
    reg[0].ant = ptr_a;
    reg[0].prox = ptr;

    /* posiciona no ponto de inserçao e grava */
    pos_grv = reg_geral_aluno[0].pilha_disp;
    if (pos_grv != -1) {
        (void)fseek (arq_aluno, pos_grv, SEEK_SET);
        (void)fread (rdisp, sizeof (reg_aluno_t), 1, arq_aluno);
        reg_geral_aluno[0].pilha_disp = rdisp[0].prox;
        (void)fseek (arq_aluno, pos_grv, SEEK_SET);
    } else {
        (void)fseek (arq_aluno, 0L, SEEK_END);
        pos_grv = ftell (arq_aluno);
    }
    (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);
    (void)fflush (arq_aluno);

    if (ptr_a != -1) {
        /* Existe um aluno anterior, ANT, que deve ser
         * atualizada: ANT.prox = aluno inserida */

        (void)fseek (arq_aluno, ptr_a, SEEK_SET);
        (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        reg[0].prox = pos_grv;
        (void)fseek (arq_aluno, ptr_a, SEEK_SET);
        (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        (void)fflush (arq_aluno);
    }

    if (ptr != -1) {
        /* Existe um aluno posterior, POS, que deve ser
         * atualizada: POS.ant = aluno inserida */

        (void)fseek (arq_aluno, ptr, SEEK_SET);
        (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        reg[0].ant = pos_grv;
        (void)fseek (arq_aluno, ptr, SEEK_SET);
        (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        (void)fflush (arq_aluno);
    }

    /* Atualiza registro geral das aluno */
    (reg_geral_aluno[0].qtd_reg)++;
    if (ptr_a == -1) {
        /* Existe um novo primeiro registro */
        reg_geral_aluno[0].pos_pri_r = pos_grv;
    }
    if (ptr == -1) {
        /* Existe um novo último registro */
        reg_geral_aluno[0].pos_ult_r = pos_grv;
    }
    (void)fseek (arq_aluno, 0L, SEEK_SET);
    (void)fwrite (reg_geral_aluno, sizeof (reg_geral_aluno_t), 1, arq_aluno);
    (void)fflush (arq_aluno);
}

void
ARQ_A_alterar_aluno (int32_t mat, char_t nome[], char_t tel[], char_t ee[]) {
    int64_t ptr, ptr_a;
    reg_aluno_t reg[1];

    ptr = ptr_a = 0;

    if (pos_aluno (mat, &ptr, &ptr_a) == false) {
        return;
    }
    (void)fseek (arq_aluno, ptr, SEEK_SET);
    (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
    if (reg[0].mat == mat) {
        if (nome[0] != '\0') {
            strcpy (reg[0].nome, nome);
        }
        if (tel[0] != '\0') {
            strcpy (reg[0].tel, tel);
        }
        if (ee[0] != '\0') {
            strcpy (reg[0].ee, ee);
        }
        (void)fseek (arq_aluno, ptr, SEEK_SET);
        (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        (void)fflush (arq_aluno);
    }
}

void
ARQ_A_excluir_aluno (int32_t mat) {
    int64_t ptr, ptr_a, ptr_p, ptr_excl;
    reg_aluno_t reg[1];

    ptr = ptr_a = 0;

    if (pos_aluno (mat, &ptr, &ptr_a) == false) {
        return;
    }
    (void)fseek (arq_aluno, ptr, SEEK_SET);
    ptr_excl = ftell (arq_aluno);
    (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
    if (reg[0].mat == mat) {
        ptr_a = reg[0].ant;
        ptr_p = reg[0].prox;
        if (ptr_a != -1) {
            (void)fseek (arq_aluno, ptr_a, SEEK_SET);
            (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
            reg[0].prox = ptr_p;
            (void)fseek (arq_aluno, ptr_a, SEEK_SET);
            (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        }
        if (ptr_p != -1) {
            (void)fseek (arq_aluno, ptr_p, SEEK_SET);
            (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
            reg[0].ant = ptr_a;
            (void)fseek (arq_aluno, ptr_p, SEEK_SET);
            (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        }
        (void)fseek (arq_aluno, ptr_excl, SEEK_SET);
        (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        reg[0].prox = reg_geral_aluno[0].pilha_disp;
        (void)fseek (arq_aluno, ptr_excl, SEEK_SET);
        (void)fwrite (reg, sizeof (reg_aluno_t), 1, arq_aluno);

        (reg_geral_aluno[0].qtd_reg)--;
        reg_geral_aluno[0].pilha_disp = ptr_excl;
        if (ptr_a == -1) {
            reg_geral_aluno[0].pos_pri_r = ptr_p;
        }
        if (ptr_p == -1) {
            reg_geral_aluno[0].pos_ult_r = ptr_a;
        }
        (void)fseek (arq_aluno, 0L, SEEK_SET);
        (void)fwrite (reg_geral_aluno, sizeof (reg_geral_aluno_t), 1, arq_aluno);
        (void)fflush (arq_aluno);
    }

}

/* *******************************************************
* Funções de pesquisa
* ****************************************************** */

bool_t
ARQ_A_existe_aluno (int32_t mat) {
    int64_t ptr;
    reg_aluno_t reg[1];
    if (reg_geral_aluno[0].qtd_reg == 0) {
        return false;
    }
    ptr = reg_geral_aluno[0].pos_pri_r;
    while (fseek (arq_aluno, ptr, SEEK_SET) == 0) {
        (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        if (reg[0].mat == mat) {
            return true;
        } else {
            if (reg[0].mat > mat)
                return false;
        }
        ptr = reg[0].prox;
    }
    return false;
}


/* *******************************************************
* Funções de leitura e caminhamento
* ****************************************************** */

bool_t
ARQ_A_ler_aluno (int32_t mat) {
    int64_t ptr, ptr_a;

    ptr = ptr_a = 0;
    
    if (pos_aluno (mat, &ptr, &ptr_a) == false) {
        return false;
    }
    if (fseek (arq_aluno, ptr, SEEK_SET) != 0) {
        return false;
    } else {
        (void)fread (reg_aluno, sizeof (reg_aluno_t), 1, arq_aluno);
        return true;
    }
}

int64_t
ARQ_A_ler_primeiro_aluno () {
    int64_t pos = reg_geral_aluno[0].pos_pri_r;
    if (pos < 0) {
        return pos;
    }
    (void)fseek (arq_aluno, pos, SEEK_SET);
    return fread (reg_aluno, sizeof (reg_aluno_t), 1, arq_aluno);
}

int64_t
ARQ_A_ler_proximo_aluno () {
    int64_t pos = reg_aluno[0].prox;
    if (pos < 0) {
        return pos;
    }
    (void)fseek (arq_aluno, pos, SEEK_SET);
    return fread (reg_aluno, sizeof (reg_aluno_t), 1, arq_aluno);
}

int64_t
ARQ_A_ler_aluno_posicao (int64_t ptr) {
    (void)fseek (arq_aluno, ptr, SEEK_SET);
    return fread (reg_aluno, sizeof (reg_aluno_t), 1, arq_aluno);
}

/* *******************************************************
* Funções para abertura, iniciação e fechamento do arquivo
* ****************************************************** */

void
ARQ_A_cria_arq_aluno () {
    FILE *arq_aluno_aux;
    reg_geral_aluno[0].qtd_reg = 0;
    reg_geral_aluno[0].desloc_ini = sizeof (reg_geral_aluno_t);
    reg_geral_aluno[0].pos_pri_r = -1;
    reg_geral_aluno[0].pos_ult_r = -1;
    reg_geral_aluno[0].pilha_disp = -1;
    arq_aluno_aux = fopen ("sismon_aluno.smo", "w+b");
    if ( arq_aluno_aux != NULL){
    	arq_aluno = arq_aluno_aux;
        (void)fwrite (reg_geral_aluno, sizeof (reg_geral_aluno_t), 1, arq_aluno);
        (void)fclose (arq_aluno);
    }
}

/*@null@*//*@dependent@*/FILE *
ARQ_A_abre_arq_aluno () {
    FILE *arq_aluno_aux;
    arq_aluno_aux = fopen ("sismon_aluno.smo", "r+b");
    if (arq_aluno_aux != NULL) {
        arq_aluno = arq_aluno_aux;
        (void)fread (reg_geral_aluno, sizeof (reg_geral_aluno_t), 1, arq_aluno);
        return arq_aluno;
    }
    else return NULL;
}

void
ARQ_A_fecha_arq_aluno () {
    (void)fseek (arq_aluno, 0L, SEEK_SET);
    (void)fwrite (reg_geral_aluno, sizeof (reg_geral_aluno_t), 1, arq_aluno);
    (void)fclose (arq_aluno);
}

/* *******************************************************
* Implementação das funções locais
* ****************************************************** */

/**
* \brief Posiciona arquivos para inserção de aluno
*
* \param mat Matrícula do aluno a ser inserido
* \param ptr Apontador para a aluno posterior
* \param ptr_a Apontador para a aluno anterior
* \return true, se existe uma aluno com código = mat
* \return false, em caso contrário.
*
* Os apontadores ptr e ptr_a são sempre atualizados de
* forma que uma aluno de matrícula = mat possa ser
* inserido após o aluno apontado por ptr_a e antes
* do aluno apontado por ptr.
*
* Os valores de ptr e ptr_a são definidos de acordo com
* os casos abaixo:
*
* - Já existe um aluno com matrícula = mat
*     - Então ptr aponta para este aluno.
*
* - Não existe um aluno com matrícula = mat
*     - Existe um aluno com matrícula maior que mat
*          - Então ptr aponta para o aluno de matrícula
*            maior.
*     - Não existe nenhum aluno com matrícula maior
*        que mat
*          - Então ptr recebe o valor -1, indicando
*            que o arquivo não terá alunos
*            posteriores a mat.
* .
* Se ptr_a = -1, o aluno mat será o primeiro do
* arquivo. Se ptr = -1, o aluno mat será o último.
*/
bool_t
pos_aluno (int32_t mat, int64_t * ptr, int64_t * ptr_a) {
    reg_aluno_t reg[1];
    *ptr = reg_geral_aluno[0].pos_pri_r;
    *ptr_a = -1;
    while (fseek (arq_aluno, *ptr, SEEK_SET) == 0) {
        (void)fread (reg, sizeof (reg_aluno_t), 1, arq_aluno);
        if (reg[0].mat == mat) {
            return true;
        }
        if (reg[0].mat > mat) {
            return false;
        }
        *ptr_a = *ptr;
        *ptr = reg[0].prox;
    }
    *ptr = -1;
    return false;
}
