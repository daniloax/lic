/**
 * \addtogroup MOD_GLB "Global"
 * \{
 * \ingroup MOD_GERAL
 *
 * \file smo_global.h
 * \brief Cabeçalho
 */
/*\}*/

#ifndef $$MOD_GLB
#define $$MOD_GLB

#include "smo_tipos.h"

/**
* \brief Define o código do usuário do sistema
*/
void GLB_define_usuario (int32_t cod);

/**
* \brief Obtém o código do usuário do sistema
*/
int32_t GLB_usuario (void);

/**
* \brief Obtém o nome do módulo ativo
*/
char_t *GLB_modulo (void);

/**
* \brief Obtém o nome do sub-módulo ativo
*/
char_t *GLB_smodulo (void);

/**
* \brief Obtém o nome da função ativa
*/
char_t *GLB_funcao (void);

/**
* \brief Atualiza o nome do módulo ativo
*
* O nome do módulo ativo é mostrado nos cabeçalhos
*/
void GLB_atualiza_modulo (char_t nome[]);

/**
* \brief Atualiza o nome do sub-módulo ativo
*
* O nome do sub-módulo ativo é mostrado nos cabeçalhos
*/
void GLB_atualiza_smodulo (char_t nome[]);

/**
* \brief Atualiza o nome da função ativa
*
* O nome da função ativa é mostrada nos cabeçalhos
*/
void GLB_atualiza_funcao (char_t nome[]);

#endif
