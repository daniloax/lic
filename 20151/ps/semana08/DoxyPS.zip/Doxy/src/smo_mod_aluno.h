/**
 * \addtogroup MOD_ALN "Aluno"
 * \{
 * \ingroup MOD_SMO
 * \file smo_mod_aluno.h
 * \brief Cabeçalho
 */
/** \} */

#ifndef $$MOD_ALN
#define $$MOD_ALN

#endif
