var searchData=
[
  ['teste_5fdt_5fproximaletra_5fmaiuscula',['teste_DT_ProximaLetra_Maiuscula',['../Exemplo__teste_8c.html#a75212f227c346a9a32d3ae4b9a8976ee',1,'Exemplo_teste.c']]],
  ['teste_5fdt_5fproximaletra_5fminuscula',['teste_DT_ProximaLetra_Minuscula',['../Exemplo__teste_8c.html#a0bbf81a0c4dcf82c668908fc60af7d0f',1,'Exemplo_teste.c']]],
  ['teste_5fdt_5fproximaletra_5fz',['teste_DT_ProximaLetra_Z',['../Exemplo__teste_8c.html#a045b42d2eac3457e9a53164c4fab954a',1,'Exemplo_teste.c']]],
  ['teste_5fdt_5fverificaparidade_5fimpar',['teste_DT_VerificaParidade_Impar',['../Exemplo__teste_8c.html#aa8b56a1bcb594f5a4c6551ff1494ddd3',1,'Exemplo_teste.c']]],
  ['teste_5fdt_5fverificaparidade_5fpar',['teste_DT_VerificaParidade_Par',['../Exemplo__teste_8c.html#a0c5a54fd61b72889ecf5acc07eafa75c',1,'Exemplo_teste.c']]],
  ['teste_5fdt_5fverificaparidade_5fzero',['teste_DT_VerificaParidade_Zero',['../Exemplo__teste_8c.html#a5c6647725ade1e01d349f49c4e43b22d',1,'Exemplo_teste.c']]]
];
