var searchData=
[
  ['adicionar_5fsuite',['adicionar_suite',['../Exemplo__teste_8c.html#a5c8fa440fd2268f6a72a654567762ddb',1,'Exemplo_teste.c']]]
];
