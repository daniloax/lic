var searchData=
[
  ['verificaparidade',['VerificaParidade',['../Exemplo_8c.html#a227bdd44fa376979513d272fcdbd5e6c',1,'Exemplo.c']]]
];
