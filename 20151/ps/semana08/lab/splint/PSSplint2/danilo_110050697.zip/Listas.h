
typedef struct lista {
	char *c;
	struct lista *prox;
} Lista;

void Insere( Lista**, char*, int*);
void Mostra( Lista*);
