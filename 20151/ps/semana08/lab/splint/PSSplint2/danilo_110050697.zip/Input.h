
char * Get_C(int**);
int Tem_Input(int);
