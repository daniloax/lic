#include <stdio.h>
void show(){
	printf("OI");
}
