#include <stdio.h>
int main(){
	show();
	getchar();
	return 0;
}
