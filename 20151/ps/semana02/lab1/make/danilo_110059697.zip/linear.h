#ifndef LINEAR_H_
#define LINEAR_H_

#include <stdio.h>
#include <stdlib.h>

#include "listas.h"

void PercursoLinear(lista1 *pini);

#endif /* LINEAR_H_ */
