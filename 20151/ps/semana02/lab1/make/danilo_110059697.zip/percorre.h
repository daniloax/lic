#ifndef PERCORRE_H_
#define PERCORRE_H_


#include <stdio.h>
#include <stdlib.h>

#include "listas.h"

void PercorreMalha(lista1 *pini);

#endif /* PERCORRE_H_ */
