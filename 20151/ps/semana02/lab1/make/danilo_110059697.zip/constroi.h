#ifndef CONSTROI_H_
#define CONSTROI_H_

#include <stdio.h>
#include <stdlib.h>

#include "listas.h"

void ConstroiMalha(lista1 **epinicio);

#endif /* CONSTROI_H_ */
