/*
 Função TestaParidade:
 Entrada	Esperado
 0			0
 1			1
 2			0
 3			1
 .			.
 .			.
 .			.
 */
int VerificaParidade(int);

/* Retorna a proxima letra do alfabeto, se for a ultima letra, rertorna para a primeira*/
char ProximaLetra(char);
