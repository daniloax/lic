#include "Exemplo.h"

/* Função retorna 0, caso "a" seja par e 1 caso "a" seja impar */
int VerificaParidade( int a){
	if (a == 0) {
		a++;
	}
	return a%2;
}

/*
 Função TestaParidade:
 Entrada	Esperado
 0			0
 1			1
 2			0
 3			1
 .			.
 .			.
 .			.
 */

/* Retorna a proxima letra do alfabeto, se for a ultima letra, rertorna para a primeira*/
char ProximaLetra( char a){
	a++;
	return a;
}

/*
Função ProximaLetra:
 Entrada	Esperado
 A			B
 B			C
 Z			A
 a			b
 b			c
 z			a
 .			.
 */


