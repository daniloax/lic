#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "Exemplo.h"
/*
 * Função que adiciona ao registro do CUnit os testes paras as funções 
 * presentes no arquivo testes.c
 */
void adicionar_suite(void);



/*Abaixo estão as funções que efetuam os testes para a função VerificaParidade*/
void teste_DT_VerificaParidade_Par(void);
void teste_DT_VerificaParidade_Impar(void);
void teste_DT_VerificaParidade_Zero(void);

/*Abaixo estão as funções que efetuam os testes para a função ProximaLetra*/
void teste_DT_ProximaLetra_Maiuscula(void);
void teste_DT_ProximaLetra_Minuscula(void);
void teste_DT_ProximaLetra_Z(void);


/* Teste numero numero par */
void teste_DT_VerificaParidade_Par(void){
	int resultado;
	resultado = VerificaParidade(2);
	assert(resultado == 0);
}

/* Teste numero impar */
void teste_DT_VerificaParidade_Impar(void){
	int resultado;
	resultado = VerificaParidade(3);
	assert(resultado == 1);
}

/* Teste numero zero, que deve retornar par */
void teste_DT_VerificaParidade_Zero(void){
	int resultado;
	resultado = VerificaParidade(0);
	assert(resultado == 0);
}

/* Teste letra maiuscula */
void teste_DT_ProximaLetra_Maiuscula(void){
	char resultado;
	resultado = ProximaLetra('A');
	assert(resultado == 'B' );
}

/* Teste letra maiuscula */
void teste_DT_ProximaLetra_Minuscula(void){
	char resultado;
	resultado = ProximaLetra('d');
	assert(resultado == 'e' );
}

/* Teste letra maiuscula */
void teste_DT_ProximaLetra_Z(void){
	char resultado;
	resultado = ProximaLetra('Z');
	assert(resultado == 'A' );
}

void  adicionar_Testes(void){
	
	/*Cria uma suite que conterá todos os testes*/
	
	
	/*Adiciona os testes para a função DT_data_valida*/
	teste_DT_VerificaParidade_Par();
	teste_DT_VerificaParidade_Impar();
	teste_DT_VerificaParidade_Zero();
	teste_DT_ProximaLetra_Maiuscula();
	teste_DT_ProximaLetra_Minuscula();
	teste_DT_ProximaLetra_Z();

}
int main(void){
	    
    	/*Chama casos de teste*/ 	
   	adicionar_Testes();

}
