Universidade de Brasília
Departamento de Ciência da Computação
Programação Sistemática
Professora Genaína Nunes Rodrigues

Laboratório:
Testes Automatizados com CUnit

Alunos:
Danilo Alves Xavier
José Siqueira

Observações:
Testes executados em ambiente de 64 bits.
Compilação de testes realizada com arquivo ./CUnit/lcunit_amd64.a
