#include<stdio.h>
#include<math.h>
#define RANGE 10 

void constroi_vetor(int vetor[10]){
	int i;
	for( i = 0; i<10; i++){		
		vetor[i] = random()%i;
	}
}

void ordena_vetor(int vetor[10]){
	int i, troca =1, aux;
	while ( troca ){
		troca=0;
		for ( i =0; i<9; i++){
			troca= 1;
			if( vetor[i] > vetor[i + 1]){
				aux = vetor[i+1];
				vetor[i+1] = vetor[i];
				vetor[i] = aux;
			}
		}
	}
}

void mostra_vetor(int vetor[10]){
	int i;
	printf("\n");
	for (i=0;i<=10;i++){
		printf("%d",vetor[i]);
	}
	printf("\n");
}

int main(){
	int vetor[10];
	constroi_vetor(vetor);
	ordena_vetor(vetor);
	mostra_vetor(vetor);
}
