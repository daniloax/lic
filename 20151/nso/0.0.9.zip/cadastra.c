#include "cadastra.h"

int main(int argc, char *argv[]) {
   
   printf("%s %s %s\n", argv[0], argv[4], argv[5]);
   
   return 0;
   
}
