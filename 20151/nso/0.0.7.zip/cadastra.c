#include "cadastra.h"

int main(int argc, char *argv[]) {
      
   char *pshm;
   int idsem, idshm, key, status, pid;
   
   key = atoi(argv[1]);
   idshm = atoi(argv[2]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      printf("erro ao obter semaforo\n");
      exit(1);
   }
   
   /** vincula memoria */
   pshm = shmat(idshm, (char *) 0, 0);

   if (*pshm == -1) {
      
      printf("erro ao vincular memoria\n");
      exit(1);
   
   }
   
   p_sem(idsem);
   
   /** cria processo filho */
   // pid = fork();
   
   // if (pid == 0) {
      
      while (1) {
      
         v_sem(idsem);
         
         printf("\n%s - obtive o semaforo, vou dormir\n", argv[0]);
         sleep(1);
         printf("%s - dormi\n", argv[0]);
         sleep(1);
         printf("%s - vou ler\n", argv[0]);
         sleep(1);
         printf("%s - li\n", argv[0]);
         sleep(1);
         printf("%s - valor lido = %s\n", argv[0], pshm);
         sleep(1);
         
         p_sem(idsem);
      
      }
      
   // }
   
   // wait(&status);
   
   // printf("\n%d exited, status = %d\n", pid, WEXITSTATUS(status));
   
   /** codigo do pai */
   
   // v_sem(idsem);
   
   /** desvincula memoria */
   if (shmdt(pshm) == -1)
      printf("The shmdt call failed!, error number = %d\n", errno);

   else
      printf("The shmdt call succeeded!\n");
            
   // if (execl("prompt", "prompt", argv[1], argv[2], (char *) 0) < 0)
      // printf("erro no execl = %d\n", errno);
   
   return 0;
   
}
