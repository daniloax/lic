#include "executa.h"

int main(int argc, char *argv[]) {
   
   char *pshm;
   int idsem, idshm, key, status, pid;
   
   printf("./%s", argv[0]);
   
   key = atoi(argv[1]);
   idshm = atoi(argv[2]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      
      printf("erro ao obter semaforo\n");
      exit(1);

   }
   
   /** vincula memoria */
   pshm = shmat(idshm, (char *) 0, 0);
   
   /** codigo do pai */

   while (1) {
      sleep(10);
   }

   /** detach */
   if (shmdt(pshm) == -1)
      printf("The shmdt call failed!, error number = %d\n", errno);

   else
      printf("The shmdt call succeeded!\n");
   
   return 0;
   
}
