#include "prompt.h"

int main(int argc, char *argv[]) {
   
   char *inputs[3], input[64], *inputv, *pshm;
   int idsem, idshm, inputc, key, pid, status;
   
   key = atoi(argv[1]);
   idshm  = atoi(argv[2]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      printf("erro ao obter semaforo\n");
      exit(1);
   }
   
   /** vincula memoria */
   pshm = shmat(idshm, (char *) 0, 0);
   
   if (*pshm == -1) {
      
      printf("erro no attach\n");
      exit(1);
   
   }
   
   // p_sem(idsem);
   
   /** cria processo filho */
   pid = fork();
   
   if (pid == 0) {
      
      v_sem(idsem);
               
      if (execl("cadastra", "cadastra", argv[1], argv[2], (char *) 0) < 0)
         printf("erro no execl = %d\n", errno);
      
   }
   
   /** prompt */
   while (strcmp(input, "termina") != 0) {
      
      v_sem(idsem);
      
      printf("\n%s - obtive o semaforo, vou dormir\n", argv[0]);
      sleep(1);
      printf("%s - dormi\n", argv[0]);
      sleep(1);
      printf("%s - entre com um valor\n", argv[0]);
      sleep(1);
      
      input[0] = "\0";

      printf("\n> ");
      scanf("%[^\n]s", input);
      getchar();
      // printf("%s\n", input);

      inputv = strtok(input, " ");
      inputc = 0;

      while (inputv != NULL) {
         
         inputs[inputc] = inputv;
         
         printf("inputv[%d]: ", inputc);
         printf("%s\n", inputv);
         
         inputv = strtok(NULL, " ");
         inputc++;
      
      }
      
      *pshm = calloc(strlen(input), sizeof(char));
      strcpy(pshm, input);

      p_sem(idsem);
   
   }
   
   v_sem(idsem);
   
   kill(pid, SIGKILL);
   
   p_sem(idsem);
   
   wait(&status);
   
   printf("\n%d exited, status = %d\n", pid, WEXITSTATUS(status));
   
   /** desvincula memoria */
   if (shmdt(pshm) == -1)
      printf("\nThe shmdt call failed!, error number = %d\n", errno);

   else
      printf("\nThe shmdt call succeeded!\n");
      
   return 0;

}
