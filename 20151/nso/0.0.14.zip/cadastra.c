#include "cadastra.h"

int main(int argc, char *argv[]) {
   
   int idmsq, key;
   
   key = atoi(argv[1]);
   
   /** obtem fila */
   if ((idmsq = msgget(key, 0x180)) < 0) {
     
      perror("msgget");
      exit(EXIT_FAILURE);
   
   }
   
   /** produz mensagem */
   mensagem_env.pid = getpid();
   strcpy(mensagem_env.executa, argv[3]);
   strcpy(mensagem_env.parametro, argv[4]);
   
   /** envia mensagem */
   msgsnd(idmsq, &mensagem_env, sizeof(mensagem_env) - sizeof(long), 0);
   
   return 0;
   
}
