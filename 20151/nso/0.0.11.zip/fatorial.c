#include "fatorial.h"
   
void WriteFormatted (FILE * stream, const char * format, ...) {
  
  va_list args;
  va_start (args, format);
  vfprintf (stream, format, args);
  va_end (args);

}

int fatorial(int n) {

   if (n) 
      return n * fatorial(n - 1);
   
   else 
      return 1;

}

int main(int argc, char *argv[]) {
   
   FILE *pFile;
   
   int n;
   
   pFile = fopen("fatorial.txt", "w");

   n = atoi(argv[1]);
   
   WriteFormatted (pFile, "%u ", fatorial(n));
   
   fclose(pFile);
   
   return 0;
   
}
