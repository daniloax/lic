#include "executa.h"

struct mensagem {
   long pid;
   char executa[30];
   char parametro[30]
} mensagem;

int main(int argc, char *argv[]) {
   
   int idmsq, key, pid, estado;
   struct mensagem mensagem_rec;
   
   key = atoi(argv[1]);
   
   /** obtem fila */
   if ((idmsq = msgget(key, 0x180)) < 0) {
     
     printf("The msgget call failed!, error number = %d\n", errno);
     exit(1);
   
   }
   
   while (1) {
      
      if (msgrcv(idmsq, &mensagem_rec, sizeof(mensagem_rec) - sizeof(long), 0, 0) < 0)
         sleep(1);
      
      else {
         
         /** executa comando */
         if ((pid = fork()) < 0) {
           
           printf("\nThe fork call failed!, error number = %d\n", errno);
           exit(1);
         
         }
         
         if (pid == 0) {
                  
            if (execl(mensagem_rec.executa, mensagem_rec.executa, mensagem_rec.parametro, (char *) 0) < 0) {
               
               printf("%s: comando nao encontrado\n", mensagem_rec.executa);
               printf("The execl call failed!, error number = %d\n", errno);
               exit(0);
               
            }
            
         }
            
         wait(&estado);
         // printf("%d exited, status = %d\n", pid, WEXITSTATUS(estado));
         
      }
      
   }
   
   return 0;
   
}
