#include "fibonacci.h"

void WriteFormatted (FILE * stream, const char * format, ...) {
  
  va_list args;
  va_start (args, format);
  vfprintf (stream, format, args);
  va_end (args);

}

int fibonacci(int n) {

   if (n == 0)
      return 0;
   
   else if (n == 1)
      return 1;
   
   else
      return(fibonacci(n - 1) + fibonacci(n - 2));

}

int main(int argc, char *argv[]) {
   
   FILE *pFile;
   
   int c, i, n;
   
   i = 0;
   
   pFile = fopen("fibonacci.txt", "w");

   n = atoi(argv[1]);
   
   for (c = 0; c < n; c++) {
      
      WriteFormatted (pFile, "%u ", fibonacci(i));
      i++;
      
   }
   
   fclose(pFile);
   
   return 0;
   
}
