#include "cadastra.h"

struct mensagem {
   long pid;
   char executa[30];
   char parametro[30]
};

int main(int argc, char *argv[]) {
   
   int idmsq, key;
   struct mensagem mensagem_env;
   
   key = atoi(argv[1]);
   
   /** obtem fila */
   if ((idmsq = msgget(key, 0x180)) < 0) {
     
     printf("The msgget call failed!, error number = %d\n", errno);
     exit(1);
   
   }
   
   mensagem_env.pid = getpid();
   strcpy(mensagem_env.executa, argv[3]);
   strcpy(mensagem_env.parametro, argv[4]);
   msgsnd(idmsq, &mensagem_env, sizeof(mensagem_env) - sizeof(long), 0);
   
   return 0;
   
}
