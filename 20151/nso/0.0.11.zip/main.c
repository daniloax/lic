#include "main.h"

int main() {
   
   struct shmid_ds *shmbuf;
   struct msqid_ds *msqbuf;
   
   char chave[10], shmid[10];
   int executa, idmsq, idsem, idshm, key = 0x68f60b1, prompt, estadoExecuta, estadoPrompt;
   
   shmbuf = NULL;
   msqbuf = NULL;
   
   /** cria semaforo */
   if ((idsem = semget(key, 1, IPC_CREAT|0x180)) < 0) {
      
      printf("The semget call failed!, error number = %d\n", errno);
      exit(1);
   
   }
   
   /** cria memoria */
   if ((idshm = shmget(key, sizeof(int), IPC_CREAT|0x180)) < 0) {
      
      printf("The shmget call failed!, error number = %d\n", errno);
      exit(1);
      
   }
   
   /** cria fila */
   if ((idmsq = msgget(key, IPC_CREAT|0x180)) < 0) {
     
     printf("The msgget call failed!, error number = %d\n", errno);
     exit(1);
   
   }
   
   sprintf(chave, "%d", key);
   sprintf(shmid, "%d", idshm);
   
   /** cria executa */
   if ((executa = fork()) < 0) {
     
     printf("The fork call failed!, error number = %d\n", errno);
     exit(1);
   
   }
   
   if (executa == 0) {
      
     /** processa executa */
      if (execl("executa", "executa", chave, shmid, (char *) 0) < 0) {
         
         printf("%s: comando nao encontrado\n", "executa");
         printf("The execl call failed!, error number = %d\n", errno);
         exit(0);
      
      }
      
   }
   
   /** cria prompt */
   if ((prompt = fork()) < 0) {
     
     printf("erro no fork\n");
     exit(1);
   
   }
   
   if (prompt == 0) {
      
      /** processa prompt */
      if (execl("prompt", "prompt", chave, shmid, (char *) 0) < 0) {
         
         printf("%s: comando nao encontrado\n", "prompt");
         printf("The execl call failed!, error number = %d\n", errno);
         exit(0);
         
      }
      
   }
   
   /** aguarda prompt */
   wait(&estadoPrompt);
   
   /** finaliza executa */
   kill(executa, SIGKILL);
   
   /** aguarda executa */
   wait(&estadoExecuta);
   
   /** saida prompt */
   printf("\n%d exited, status = %d\n", executa, WEXITSTATUS(estadoExecuta));
   
   /** saida executa */
   printf("%d exited, status = %d\n\n", prompt, WEXITSTATUS(estadoPrompt));
   
   /** remove memoria */
   if ((shmctl(idshm, IPC_RMID, shmbuf)) == -1)
		printf("\nThe shmctl call failed!, error number = %d\n", errno);
   
   /** remove semaforo */
   if (semctl(idsem, 0, IPC_RMID, arg) == -1)
      printf("\nThe semctl call failed!, error number = %d\n", errno);
      
   /** remove fila */
   if (msgctl(idmsq, IPC_RMID, msqbuf) == -1)
      printf("\nThe semctl call failed!, error number = %d\n", errno);
   
	return 0;
   
}
