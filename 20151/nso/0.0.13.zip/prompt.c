#include "prompt.h"

int main(int argc, char *argv[]) {
   
   char *inputs[3], input[64], *inputv;
   int idsem, inputc, key, cadastra, estadoCadastra;
   
   key = atoi(argv[1]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      
      printf("The semget call failed!, error number = %d\n", errno);
      exit(1);
   
   }
   
   /** exibe prompt */
   while (strcmp(input, "termina") != 0) {
      
      v_sem(idsem);
      
      strcpy(input, "\0");

      printf("\n> ");
      scanf("%[^\n]s", input);
      getchar();

      inputv = strtok(input, " ");
      inputc = 0;

      while (inputv != NULL) {
         
         inputs[inputc] = inputv;
         inputv = strtok(NULL, " ");
         inputc++;
      
      }

      /** cria processo */
      if ((cadastra = fork()) < 0) {
        
        printf("\nThe fork call failed!, error number = %d\n", errno);
        exit(1);
      
      }
      
      /** cadastra programa */
      if ((cadastra == 0) && (strcmp(inputs[0], "termina") != 0)) {
                  
         if (execl(inputs[0], inputs[0], argv[1], argv[2], inputs[1], inputs[2], (char *) 0) < 0) {
            
            printf("%s: comando nao encontrado\n", inputs[0]);
            printf("The execl call failed!, error number = %d\n", errno);
            exit(0);
            
         }
         
      } else if ((cadastra == 0) && (strcmp(inputs[0], "termina") == 0)) {
         
         exit(0);
         
      }
         
      wait(&estadoCadastra);
      // printf("%d exited, status = %d\n", cadastra, WEXITSTATUS(estadoCadastra));
      
      p_sem(idsem);

   }
      
   return 0;

}
