#include "cadastra.h"

int main(int argc, char *argv[]) {
      
   char *pshm;
   int idsem, idshm, key, status, pid;
   
   idshm = atoi(argv[2]);
   key = atoi(argv[1]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      printf("erro ao obter semaforo\n");
      exit(1);
   }
   
   /** vincula memoria compartilhada */
   pshm = shmat(idshm, (char *) 0, 0);

   if (*pshm == -1) {
      
      printf("erro ao vincular memoria\n");
      exit(1);
   
   }   
   
   p_sem(idsem);
   
   /** codigo do pai */

   while (1) {
   
      v_sem(idsem);
      
      printf("\n%s - obtive o semaforo, vou dormir\n", argv[0]);
      sleep(1);
      printf("%s - dormi\n", argv[0]);
      sleep(1);
      printf("%s - vou ler\n", argv[0]);
      sleep(1);
      printf("%s - li\n", argv[0]);
      sleep(1);
      printf("%s - valor lido = %s\n", argv[0], pshm);
      sleep(1);
      
      p_sem(idsem);
   
   }
   
   /** detach */
   if (shmdt(pshm) == -1)
      printf("The shmdt call failed!, error number = %d\n", errno);

   else
      printf("The shmdt call succeeded!\n");
   
   return 0;
   
}
