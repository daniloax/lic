#include "main.h"

int main() {
   
   struct shmid_ds *buf;
   
   char chave[10], shmid[10];
   int idsem, idshm, key = 0x68f60b1, pid, status;
   
   /** cria semaforo */
   if ((idsem = semget(key, 1, IPC_CREAT|0x180)) < 0) {
      
      printf("erro na criacao do semaforo\n");
      exit(1);
   
   }
   
   /** cria memoria */
   if ((idshm = shmget(key, sizeof(int), IPC_CREAT|0x180)) < 0) {
      
      printf("erro na criacao da memoria\n");
      exit(1);
      
   }
   
   sprintf(chave, "%d", key);
   sprintf(shmid, "%d", idshm);
   
   /** cria processo */
   if ((pid = fork()) < 0) {
     
     printf("erro no fork\n");
     exit(1);
   
   }
   
   if (pid == 0) {
      
      /** executa prompt */
      if (execl("prompt", "prompt", chave, shmid, (char *) 0) < 0)
         printf("erro no execl = %d\n", errno);
      
   }
   
   /** aguarda prompt */
   wait(&status);
   
   /** imprime estado */
   printf("\n%d exited, status = %d\n", pid, WEXITSTATUS(status));
   
   /** remove memoria compartilhada */
   if ((shmctl(idshm, IPC_RMID, buf)) == -1)
		printf("The shmctl call failed!, error number = %d\n", errno);
   
   else
      printf("The shmctl call succeeded!\n");
   
   /** remove semaforo */
   if (semctl(idsem, 0, IPC_RMID, arg) == -1)
      printf("The semctl call failed!, error number = %d\n", errno);
   
   else
      printf("The semctl call succeeded!\n");
   
	return 0;
   
}
