#include "prompt.h"

int main(int argc, char *argv[]) {
   
   char *inputs[3], input[64], *inputv, *pshm;
   int idsem, idshm, inputc, key, pid, status;
   
   idshm = atoi(argv[2]);
   key = atoi(argv[1]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      printf("erro ao obter semaforo\n");
      exit(1);
   }
   
   /** vincula memoria compartilhada */
   pshm = shmat(idshm, (char *) 0, 0);

   if (*pshm == -1) {
      
      printf("erro ao vincular memoria\n");
      exit(1);
   
   }   
   
   /** cria processo filho */
   if ((pid = fork()) < 0) {
     
     printf("erro no fork\n");
     exit(1);
   
   }
   
   if (pid == 0) {
      
      v_sem(idsem);
               
      if (execl("cadastra", "cadastra", argv[1], argv[2], (char *) 0) < 0)
         printf("erro no execl = %d\n", errno);
      
   }
   
   /** codigo do pai */
   
   while (strcmp(input, "termina") != 0) {
      
      v_sem(idsem);
      
      printf("\n%s - obtive o semaforo, vou dormir\n", argv[0]);
      sleep(1);
      printf("%s - dormi\n", argv[0]);
      sleep(1);
      printf("%s - vou ler\n", argv[0]);
      sleep(1);
      printf("%s - li\n", argv[0]);
      sleep(1);
      printf("%s - valor lido = %s\n", argv[0], pshm);
      sleep(1);
      printf("%s - entre com um valor\n", argv[0]);
      sleep(1);
      
      input[0] = "\0";

      printf("\n> ");
      scanf("%[^\n]s", input);
      getchar();
      // printf("%s\n", input);

      inputv = strtok(input, " ");
      inputc = 0;

      while (inputv != NULL) {
         
         inputs[inputc] = inputv;
         
         printf("inputv[%d]: ", inputc);
         printf("%s\n", inputv);
         
         inputv = strtok(NULL, " ");
         inputc++;
      
      }
      
      *pshm = calloc(strlen(input), sizeof(char));
      strcpy(pshm, input);
      
      // if (execl(args[0], args[0], args[1], args[2], (char *) 0) < 0)
      //   printf("erro no execl = %d\n", errno);
      
      p_sem(idsem);
         
   }
   
   v_sem(idsem);
   
   kill(pid, SIGKILL);
   
   p_sem(idsem);
   
   wait(&status);
   
   printf("\n%d exited, status = %d\n", pid, WEXITSTATUS(status));
   
   /** desvincula memoria compartilhada */
	if (shmdt(pshm) == -1)
		printf("\nThe shmdt call failed!, error number = %d\n", errno);

	else
		printf("The shmdt call succeeded!\n");
      
   return 0;

}
