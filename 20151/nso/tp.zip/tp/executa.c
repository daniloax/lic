#include "executa.h"

int main(int argc, char *argv[]) {
   
   char chave[10], *pshm;
   int idsem, idshm, key , pid, status;
   
   // printf("./%s\n", argv[0]);

   key = atoi(argv[1]);
   sprintf(idshm, "%d", argv[2]);
   
   printf("key: %d\nshmid: %d\n", key, idshm);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      printf("erro ao obter semaforo\n");
      exit(1);
   }
   
   /** cria processo filho */
   /* pid = fork();
   
   if (pid == 0) {
      
      v_sem(idsem);
      
      printf("filho - obtive o semaforo, vou dormir\n");
      sleep(1);
      printf("filho - dormi\n");
      
      p_sem(idsem);
      
      exit(0);
      
   } */
   
   /** codigo do pai */
	
	while (1) {

		v_sem(idsem);

		pshm = shmat(idshm, (char *) 0, 0);
		printf("pai - numero lido = %s\n", *pshm);
		
		p_sem(idsem);
		
	}
   
   // wait(&status);
   
   return 0;
   
}
