#include "cadastra.h"

struct mensagem {
   long pid;
   char msg[30];
};

int main(int argc, char *argv[]) {
   
   int idmsq, key;
   struct mensagem mensagem_env;
   
   key = atoi(argv[1]);
   
   /** obtem fila */
   if ((idmsq = msgget(key, 0x180)) < 0) {
     
     printf("The msgget call failed!, error number = %d\n", errno);
     exit(1);
   
   }
   
   printf("%s %s %s\n", argv[0], argv[3], argv[4]);
   
   mensagem_env.pid = getpid();
   strcpy(mensagem_env.msg, argv[3]);
   msgsnd(idmsq, &mensagem_env, sizeof(mensagem_env) - sizeof(long), 0);
   
   return 0;
   
}
