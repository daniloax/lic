#include "executa.h"

struct mensagem {
   long pid;
   char msg[30];
};

int main(int argc, char *argv[]) {
   
   int idmsq, key;
   struct mensagem mensagem_rec;
   
   key = atoi(argv[1]);
   
   /** obtem fila */
   if ((idmsq = msgget(key, 0x180)) < 0) {
     
     printf("The msgget call failed!, error number = %d\n", errno);
     exit(1);
   
   }
   
   while (1) {
      
      if (msgrcv(idmsq, &mensagem_rec, sizeof(mensagem_rec) - sizeof(long), 0, 0) < 0)
         sleep(1);
      
      else
         printf("mensagem recebida = %u %s\n", mensagem_rec.pid, mensagem_rec.msg);
      
   }
   
   return 0;
   
}
