#include "executa.h"

int main(int argc, char *argv[]) {
   
   int idsem, key, status, pid;
   
   // sprintf(idsem, "%d", argv[1]);
   
   key = atoi(argv[1]);
   
   /** obtem semaforo */
   if ((idsem = semget(key, 1, 0)) < 0) {
      
      printf("erro ao obter semaforo\n");
      exit(1);

   }
   
   // printf("./%s\n", argv[0]);
   // printf("%s\n", argv[1]);
   // printf("%d\n", idsem);
   
   /** cria processo filho */
   /* pid = fork();
   
   if (pid == 0) {
      
      v_sem(idsem);
      
      printf("filho - obtive o semaforo, vou dormir\n");
      sleep(1);
      printf("filho - dormi\n");
      
      p_sem(idsem);
      
      exit(0);
      
   } */
   
   p_sem(idsem);
   
   /** codigo do pai */

   while (1) {
   
      v_sem(idsem);
      
      printf("\n%s - obtive o semaforo, vou dormir\n", argv[0]);
      sleep(1);
      printf("%s - dormi\n", argv[0]);
      
      p_sem(idsem);
   
   }
   // wait(&status);
   
   return 0;
   
}
