#include <stdio.h>
#include <stdlib.h>

typedef struct element {

	char data;
	struct element *next;

} fifolifo;

typedef struct var {

	char name;
	float value;
	struct var *next;
	
} variable;

void initialize(fifolifo **afl) {

	*afl = NULL;

}

void initializeVar(variable **av) {

	*av = NULL;

}

int isEmpty(fifolifo *afl) {

	return (afl == NULL);

}

void insertFIFO(fifolifo **af, char newdata) {

	fifolifo *f1, *f2;
	f1 = malloc (sizeof (fifolifo));
	f1->data = newdata;
	f1->next = NULL;
	
	if (*af == NULL)
		*af = f1;
	
	else {
		
		f2 = *af;

		while (f2->next != NULL)
			f2 = f2->next;
		
		f2->next = f1;

	}

}

void insertLIFO(fifolifo **al, char newdata) {

	fifolifo *l1;
	l1 = malloc (sizeof (fifolifo));
	l1->data = newdata;
	l1->next = *al;
	*al = l1;

}

char removeElement(fifolifo **afl) {
	
	fifolifo *f1;
	char c;
	f1 = *afl;
	*afl = f1->next;
	c = f1->data;
	free (f1);
	return c;

}

char displayElement(fifolifo *afl) {

	return afl->data;

}

void displayElements(fifolifo **afl) {

	fifolifo *aux;
	char c;
	
	if (isEmpty(*afl))
		printf("empty FIFO\n");
		
	else {

		initialize(&aux);
		
		while (!isEmpty(*afl)) {
		
			printf("ELEMENT: %c\n", displayElement(*afl));
			insertFIFO(&aux, removeElement(afl));
			
		}
		
		while (!isEmpty(aux))
			insertFIFO(afl, removeElement(&aux));

	}

}
	
void calculate(fifolifo **al1, fifolifo **al2) {

	char op, cx, cy, aux;
	int x, y;

	if (isEmpty(*al1)) {

		if (isEmpty(*al1)) {

			aux = 0 + '0';              
			insertLIFO(al1, 0 + '0');

		}

	} else {
		
		op = removeElement(al2);
		cx = removeElement(al1);
		cy = removeElement(al1);
		x = cx - '0';
		y = cy - '0';
		
		switch (op) {

			case '+' : insertLIFO(al1, y + x + '0'); break;
			case '-' : insertLIFO(al1, y - x + '0'); break;
			case '*' : insertLIFO(al1, y * x + '0'); break;
			case '/' : insertLIFO(al1, y % x + '0'); break;

		}

	}

}

void evaluate(fifolifo **al1, fifolifo **al2) {

	FILE *f;
	char c, fileName[10];
	int i;
	variable *list;

	initializeVar(&list);
	
	do {
	
		printf("FILENAME: ");
		scanf("%[^\n]s", fileName);
		getchar();
		
		f = fopen(fileName, "r");
		
		if (!f)
			printf("'%s' not exist\n", fileName);
	
	} while (!f);
	
	while ((c = getc(f)) != '\n');

	while (!feof(f)) {
		
		if (fscanf(f, "%d", &i))
			printf("%d", i);
			
		else {
			
			fscanf(f, "%c", &c);
 			printf("%c", c);
		
		}
		
	}
	
	printf("\n");
	
	rewind(f);

	while (((c = getc(f)) != EOF) && (c != '\n')) {

		if (c != ' ')
			if ((c >= '0') && ( c <= '9'))
				insertLIFO(al1, c);
		
			else
				if (c == ')')
					calculate(al1, al2);
		
				else
					if (c != '(')
						insertLIFO (al2, c);

	}
	
	fclose (f);

}

int main() {

	fifolifo *lifo1, *lifo2;
	
	initialize(&lifo1);
	initialize(&lifo2);
	evaluate(&lifo1, &lifo2);
	printf("%d\n", removeElement(&lifo1) - '0');
	system("pause");
	
	return 0;

}
