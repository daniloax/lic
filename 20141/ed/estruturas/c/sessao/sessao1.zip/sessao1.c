/*
Sess�o 1 de Laborat�rio - ED - II/2011

S�o dadas abaixo duas fun��es, uma para construir e outra para percorrer 
listas abertas com encadeamento duplo. Antes de mais nada, teste essas fun��es
com um arquivo *.txt contendo alguns caracteres.

Fa�a um programa que leia dois arquivos distintos e monte duas listas desse 
tipo em mem�ria. Em cada um dos arquivos n�o deve haver elementos repetidos.
Use as fun��es dadas para se certificar de que as listas est�o
sendo montadas corretamente.

Construa uma fun��o que, a partir das duas listas dadas, escreva na tela
os elementos que estejam presentes nas duas listas (conjunto interse��o dos
elementos das duas listas.

Altere a fun��o para construir uma terceira lista do mesmo tipo das listas dadas,
contendo o conjunto interse��o dos elementos das duas listas dadas. 

*/

#include <stdio.h>
#include <stdlib.h>

typedef struct elemento {
  char dado;
  struct elemento *prox, *ant;
} listaD;

FILE *arq;

//--------------------------------------------
void ConstroiListaAD(listaD **epinicio) {
  listaD *p1, *p2;
  char c;
  
  *epinicio = NULL;
  while (((c = getc (arq)) != EOF) && (c != '\n')) {
    p1 = malloc (sizeof (listaD));
    p1->dado = c;
    p1->prox = NULL;
    if (*epinicio == NULL) {
      *epinicio = p1;
      p1->ant = NULL;
    }
    else {
      p2->prox = p1;
      p1->ant = p2;
    }
  p2 = p1;
  }
}

//--------------------------------------------
void PercorreListaAD(listaD *pinicio) {
  listaD *p1;

  if (pinicio == NULL)
    printf ("lista vazia \n");
  else {          
    p1 = pinicio;     
    while (p1 != NULL) {
      printf("elemento:  %c \n", p1->dado);
      p1 = p1->prox;
    } 
    p1 = pinicio;     
    while (p1->prox != NULL)
      p1 = p1->prox; 
    while (p1 != NULL) {
      printf("elemento (para tras):  %c \n", p1->dado);
      p1 = p1->ant;     
    }
  }     
}


//--------------------------------------------
main () {
  listaD *pini1, *pini2;

  arq = fopen ("a1.txt", "r");
  ConstroiListaAD(&pini1);
  fclose (arq);
  PercorreListaAD (pini1);

  arq = fopen ("a2.txt", "r");
  ConstroiListaAD(&pini2);
  fclose (arq);
  PercorreListaAD (pini2);

// coloque aqui a chamada para sua fun��o
  
  system("pause");
}
     
     
     
     
     
     
     
     
     
