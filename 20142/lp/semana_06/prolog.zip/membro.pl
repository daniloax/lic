membro(X,[X|Xs]).  			% fato
membro(X,[Y|Xs]) :- membro(X,Xs).  	% regra
