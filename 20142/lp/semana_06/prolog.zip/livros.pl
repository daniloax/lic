livro(autor('Fernando A.'), titulo('Orientacao a Objetos')). 
livro(autor('Pedro Rezende'), titulo('Criptografia em Redes')). 
livro(autor('Luiz Frota'), titulo('Seguranca em BD')). 
livro(autor('Marcelo Ladeira'), titulo('Redes Bayesianas')).
livro(autor('Fernando A.'), titulo('Redes de Computadores')).
livro(autor('Maria Emilia'), titulo('Genoma Humano')). 
livro(autor('Wagner Teixeira'), titulo('Funcoes de Crenca')). 
livro(autor('Aluizio Arcela'), titulo('Computacao Sonica')).
livro(autor('Homero Picolo'), titulo('Computacao Grafica')). 
livro(autor('Maria de Fatima'), titulo('IA na Educacao')).
livro(autor('Marco Aurelio'), titulo('IA na Educacao de Adultos')). 
livro(autor('Li Weigang'), titulo('Redes Neurais e o Tempo')). 
livro(autor('Francisco Cartaxo'), titulo('Especificacoes Formais')).
artigo(autor('Fernando A.'), titulo('quem usa Orientacao a Objetos')).  
artigo(autor(�Wagner Teixeira'), titulo('soma ortogonal')). 
artigo(autor('Antonio Nuno'), titulo('filtro Grafico')). 