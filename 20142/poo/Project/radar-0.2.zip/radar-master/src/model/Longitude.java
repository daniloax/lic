package model;

public class Longitude extends Coordinate {

	public Longitude() {
		
	}
	
	public Longitude(double value) {
		super(value);
	}
	

}
