package model;

public class RadarCaseStudy {

	public static void main(String[] args) {
		Radar radar = new Radar();
		radar.run();
	}

}
