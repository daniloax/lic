package model;

import java.io.Serializable;

public class Latitude extends Coordinate {

	public Latitude() {

	}
	
	public Latitude(double value) {
		super(value);
	}
	

}
