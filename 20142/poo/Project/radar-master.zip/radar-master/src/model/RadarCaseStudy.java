/*
 * RadarCaseStudy
 * ---------------------------------
 *  version: 0.0.0
 *  date: Nov 16, 2014
 *  author: ska
 *  list of changes: (none) 
 */

package model;

/**
 * Programa de driver para o estudo de caso do Radar
 * 
 * 
 * @author ska
 */
public class RadarCaseStudy {

	/**	
	 * método principal cria e executa o Radar
	 *
	 * @param args
	 */
	
	public static void main(String[] args) {
		Radar radar = new Radar();
		radar.run();
	}

}
