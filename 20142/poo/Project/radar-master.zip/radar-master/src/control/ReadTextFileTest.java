package control;

public class ReadTextFileTest {
	public static void main( String[] args ) {

		ReadTextFile application = new ReadTextFile();
		application.readAccounts("account.txt");

	}
}