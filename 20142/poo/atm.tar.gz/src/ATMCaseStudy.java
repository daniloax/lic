

public class ATMCaseStudy {
	
	// método main cria e executa o ATM
	public static void main(String[] args) {
		ATM theATM = new ATM();
		theATM.run();
	}
	
}
